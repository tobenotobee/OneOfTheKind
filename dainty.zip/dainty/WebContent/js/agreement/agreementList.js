//新增初始化
var editor;
KindEditor.ready(function(K) {
	editor = K.create('textarea[id="add_agr_context"]', {
		resizeType : 0,
		allowPreviewEmoticons : false,
		allowImageUpload : true,
		// 初始化参数工具栏
		items : [ 'source', '|', 'undo', 'redo', '|', 'preview', 'print', 'code', 'cut', 'copy', 'paste', 'plainpaste', '|', 'justifyleft',
				'justifycenter', 'justifyright', 'justifyfull', 'insertorderedlist', 'insertunorderedlist', 'indent', 'outdent', 'subscript',
				'superscript', 'clearhtml', 'quickformat', 'selectall', '|', '/', 'formatblock', 'fontname', 'fontsize', '|', 'forecolor',
				'hilitecolor', 'bold', 'italic', 'underline', 'strikethrough', 'lineheight', 'removeformat', '|', 'link', 'unlink', ],
	});
});

var editorContent;
KindEditor.ready(function(K) {
	editorContent = K.create('textarea[id="update_agr_context"]', {
		resizeType : 0,
		allowPreviewEmoticons : false,
		allowImageUpload : true,
		// 初始化参数工具栏
		items : [ 'source', '|', 'undo', 'redo', '|', 'preview', 'print', 'code', 'cut', 'copy', 'paste', 'plainpaste', '|', 'justifyleft',
				'justifycenter', 'justifyright', 'justifyfull', 'insertorderedlist', 'insertunorderedlist', 'indent', 'outdent', 'subscript',
				'superscript', 'clearhtml', 'quickformat', 'selectall', '|', '/', 'formatblock', 'fontname', 'fontsize', '|', 'forecolor',
				'hilitecolor', 'bold', 'italic', 'underline', 'strikethrough', 'lineheight', 'removeformat', '|', 'link', 'unlink', ],
	});
});

/**
 * 初始化页面
 */
function initPage() {

	showTableList();
	initWins();

}

/**
 * 展示用户列表信息
 */
function showTableList() {

	$("#table_list").datagrid({
		height : $("#body").height() - $('#search_area').height() - 5,
		width : $("#body").width(),
		method : 'post',
		idField : 'id',
		url : appPath + "/admin/agreement/getAgreementList.htm",
		singleSelect : true,
		nowrap : true,
		fitColumns : true,
		rownumbers : true,
		showPageList : true,
		toolbar : '#tt_btn',
		pagination : true,
		pageSize : 10,
		pageList : [ 5, 10, 20, 30, 50 ],
		queryParams : getQueryParams(),
		columns : [ [ {
			field : 'agrName',
			title : '协议名称',
			width : 80,
			halign : "center",
			align : "center"
		}, {
			field : 'agrContext',
			title : '协议内容摘要',
			width : 240,
			halign : "center",
			align : "center"
		}, {
			field : 'isUseStr',
			title : '状态',
			width : 40,
			halign : "center",
			align : "center"
		}, {
			field : 'isUse',
			title : '状态ID',
			width : 50,
			halign : "center",
			align : "center",
			hidden : true
		}, {
			field : 'id',
			title : 'ID',
			width : 50,
			halign : "center",
			align : "center",
			hidden : true
		}, {
			field : 'operation',
			title : '操作',
			width : 60,
			halign : "center",
			align : "center",
			formatter : function(value, row, index) {
				var operStr = $('#row_operation').html();
				return operStr.replace(/rowIndex/gm, index);
			}
		} ] ]

	});
}

/**
 * 初始化操作窗口
 */
function initWins() {

	// 初始化新增窗口
	$('#win_add_agreement').window({
		width : 800,
		height : 500,
		modal : true,
		title : '新增用户协议',
		collapsible : false,
		minimizable : false,
		maximizable : false,
		resizable : false,
		iconCls : 'icon-save'
	});
	$('#win_add_agreement').window('close');

	// 初始化修改窗口
	$('#win_update_agreement').window({
		width : 800,
		height : 500,
		modal : true,
		title : '修改用户协议',
		collapsible : false,
		minimizable : false,
		maximizable : false,
		resizable : false,
		iconCls : 'icon-edit'
	});
	$('#win_update_agreement').window('close');

}

/**
 * 获取查询用户协议信息参数
 */
function getQueryParams() {

	var agrName = $('#txt_agr_name').val();
	var queryParams = {
		'agrName' : agrName
	};
	return queryParams;

}

/**
 * 根据条件查询用户协议
 */
function doSearch() {

	$('#table_list').datagrid('load', getQueryParams());

}

/**
 * 查询条件重置
 */
function doReset() {

	$("#txt_agr_name").val("");

}

/**
 * 新增用户协议
 */
function append() {

	$('#addAgreementForm').form('clear');
	$('#win_add_agreement').window('open');
	$('#add_isuse_disable').attr('checked', true);
	KindEditor.html('#add_agr_context', '');

}
/**
 * 新增用户协议表单提交
 */
function subAdd() {

	if ($('#add_isuse_enable').attr('checked')) {
		$.messager.confirm('确认', '您确认想要添加并启用这个用户协议？', function(r) {
			if (r) {
				confirmAdd();
			}
		});
	} else {
		confirmAdd();
	}

}

function confirmAdd() {

	$.messager.progress();
	$('#addAgreementForm').form('submit', {
		url : appPath + '/admin/agreement/addAgreement.htm',
		onSubmit : function() {
			addAgreementForm.agrContext.value = editor.html();
			var isValid = $(this).form('validate');
			if (!isValid) {
				$.messager.progress('close');
			}
			return isValid;

		},
		success : function(data) {

			var dataObj = eval("(" + data + ")");
			if (dataObj.status == 1) {
				$.messager.progress('close');
				$('#win_add_agreement').window('close');
				doReset();
				doSearch();
				slide('提示', '新增用户协议成功！', 3000);
			} else {
				$.messager.progress('close');
				slide('警告', '系统错误！' + dataObj.error, 3000);
			}
		}
	});
}

/**
 * 修改用户协议弹出窗口
 */
function update(currentIndex) {

	$('#updateAgreementForm').form('clear');
	var currentRow = $('#table_list').datagrid('getRows')[currentIndex];
	$('#update_id').val(currentRow.id);
	$('#update_agr_name').val(currentRow.agrName);
	KindEditor.html('#update_agr_context', currentRow.agrContext);
	$('#update_agr_context').val(currentRow.agrContext);
	$('input[name=isUse][value=' + currentRow.isUse + ']').attr("checked", true);
	$('#updateAgreementForm').form('validate');
	$('#win_update_agreement').window('open');

}

/**
 * 提交用户协议修改信息
 */
function subUpdate() {

	if ($('#update_isuse_enable').attr('checked')) {
		$.messager.confirm('确认', '您确认想要修改并启用这个用户协议？', function(r) {
			if (r) {
				comfirmUpdate();
			}
		});
	} else {
		comfirmUpdate();
	}

}

function comfirmUpdate() {

	$.messager.progress();
	$('#updateAgreementForm').form('submit', {
		url : appPath + '/admin/agreement/updateAgreement.htm',
		onSubmit : function() {
			updateAgreementForm.agrContext.value = editorContent.html();
			var isValid = $(this).form('validate');
			if (!isValid) {
				$.messager.progress('close');
			}
			return isValid;

		},
		success : function(data) {

			var dataObj = eval("(" + data + ")");
			if (dataObj.status == 1) {
				$.messager.progress('close');
				$('#win_update_agreement').window('close');
				doReset();
				doSearch();
				slide('提示', '修改用户协议成功！', 3000);
			} else {
				$.messager.progress('close');
				slide('警告', '系统错误！' + dataObj.error, 3000);
			}

		}
	});
}

/**
 * 删除用户协议
 */
function dele(currentIndex) {

	$.messager.confirm('确认', '您确认想要删除这个用户协议？', function(r) {
		if (r) {

			var currentRow = $('#table_list').datagrid('getRows')[currentIndex];
			$.messager.progress();
			$.ajax({
				type : 'POST',
				url : appPath + '/admin/agreement/deleteAgreement.htm',
				data : 'id=' + currentRow.id,
				success : function(data) {

					var dataObj = eval("(" + data + ")");
					if (dataObj.status == 1) {
						$.messager.progress('close');
						doReset();
						doSearch();
						slide('提示', '删除用户协议成功！', 3000);
					} else {
						$.messager.progress('close');
						slide('警告', '系统错误！' + dataObj.error, 3000);
					}

				}

			});
		}
	});

}
