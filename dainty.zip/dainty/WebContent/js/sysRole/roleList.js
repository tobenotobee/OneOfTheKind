
/**
 * 初始化页面
 */
function initPage(){
		
	showTableList();
	initWins();
}

/**
 * 展示角色列表信息
 */
function showTableList(){
	
	$("#table_list").datagrid({
		height:$("#body").height()-$('#search_area').height()-5,
		width:$("#body").width(),
		method:'post',
		idField:'roleId',
		url:appPath+"/admin/sysRole/getRoleList.htm",  
		singleSelect:true,
		nowrap:true,
		fitColumns:true,
		rownumbers:true,
		showPageList:true,
		toolbar:'#tt_btn',  
        pagination:true,
        pageSize:10,
        pageList:[5,10,20,30,50],
        queryParams:getQueryParams(),
		columns:[[
			{field:'roleName',title:'角色名称',width:55,halign:"center", align:"center"},
			{field:'roleDesc',title:'角色描述',width:160,halign:"center", align:"center"},
			{field:'isAdmin',title:'超级管理员',width:30,halign:"center", align:"center",
				formatter: function(value,row,index){
					if(value==1){
						return "是";
					}else{
						return "否";
					}
				}
				
			},
			{field:'operation',title:'操作',width:90,halign:"center", align:"center",
				formatter: function(value,row,index){
					var operStr = $('#row_operation').html();
					return operStr.replace(/rowIndex/gm,index);
				}
			}
		]]
	
	});
	
}

/**
 * 初始化操作窗口
 */
function initWins(){
	//初始化新增窗口
	$('#win_add_role').window({    
		width:420,    
		height:300,    
		modal:true,
		title:'新增角色',
		collapsible:false,
		minimizable:false,
		maximizable:false,
		resizable:false,
		iconCls:'icon-save'
	});
	$('#win_add_role').window('close');
	//初始化修改窗口
	$('#win_update_role').window({    
		width:420,    
		height:300,    
		modal:true,
		title:'修改角色',
		collapsible:false,
		minimizable:false,
		maximizable:false,
		resizable:false,
		iconCls:'icon-edit'
	});
	$('#win_update_role').window('close');
	//初始化设置权限窗口
	$('#win_set_auth').window({    
		width:300,    
		height:400,    
		modal:true,
		title:'设置权限',
		collapsible:false,
		minimizable:false,
		maximizable:false,
		resizable:false,
		iconCls:'icon-edit'
	});
	$('#win_set_auth').window('close');
	
}

/**
 * 根据条件查询角色
 */
function doSearch(){
	
	$('#table_list').datagrid('load',getQueryParams());
	
}

/**
 * 查询条件重置
 */
function doReset(){
	
	 $("#txt_role_name").val("");
}

/**
 * 获取查询角色参数
 */
function getQueryParams(){
	
	var roleName = $('#txt_role_name').val();
	var queryParams = {'roleName':roleName};
	return queryParams;
	
}

/**
 * 新增角色
 */
function append(){
	
	$('#addRoleForm').form('clear');
	$("#add_is_admin_no").attr("checked","checked");
	$('#win_add_role').window('open');
	
}

/**
 * 新增角色表单提交
 */
function subAdd(){
		
	$.messager.progress();
	$('#addRoleForm').form('submit', {    
		url:appPath+'/admin/sysRole/addRole.htm',    
		onSubmit: function(){    
		    	
		    var isValid = $(this).form('validate');
		    if(!isValid){
		    	$.messager.progress('close');
		    }
		    return isValid;

		},    
		success:function(data){    
		        
		    var dataObj=eval("("+data+")");
		    if(dataObj.status==1){
		    	$.messager.progress('close');
		    	$('#win_add_role').window('close');
		    	doReset();
		    	doSearch();
		    	slide('提示','新增角色成功！',3000);
		    }else{
		    	$.messager.progress('close');
		    	slide('警告','系统错误！'+dataObj.error,3000);
		    }
		    	
		    	
		}    
	});  
		
}

/**
 * 修改角色弹出窗口
 */
function update(currentIndex){
	
	$('#updateRoleForm').form('clear');
	
	var currentRow = $('#table_list').datagrid('getRows')[currentIndex];
	$('#update_role_id').val(currentRow.roleId);
	$('#update_role_name').val(currentRow.roleName);
	$('#update_role_desc').val(currentRow.roleDesc);
	$('#updateRoleForm').form('validate');
	//$("input[name=isAdmin]").val(currentRow.isAdmin);
	$('input[name=isAdmin][value='+currentRow.isAdmin+']').attr('checked',true);
	$('#win_update_role').window('open');
	
}

/**
 * 提交角色修改信息
 */
function subUpdate(){
	
	$.messager.progress();
	$('#updateRoleForm').form('submit', {    
		url:appPath+'/admin/sysRole/updateRole.htm',    
		onSubmit: function(){    
		    	
		    var isValid = $(this).form('validate');
		    if(!isValid){
		    	$.messager.progress('close');
		    }
		    return isValid;

		},    
		success:function(data){    
		        
		    var dataObj=eval("("+data+")");
		    if(dataObj.status==1){
		    	$.messager.progress('close');
		    	$('#win_update_role').window('close');
		    	doReset();
		    	doSearch();
		    	slide('提示','修改角色成功！',3000);
		    }else{
		    	$.messager.progress('close');
		    	slide('警告','系统错误！'+dataObj.error,3000);
		    }
		    	
		    	
		}    
	});
	
}

/**
 * 删除角色
 */
function dele(currentIndex){
	
	$.messager.confirm('确认','您确认想要删除这个角色？',function(r){    
	    if (r){    
	    	
	    	var currentRow = $('#table_list').datagrid('getRows')[currentIndex];
	    	if(currentRow.isAdmin==1){
	    		$.messager.alert("警告","超级管理员角色不能删除！","warning");
	    		return;
	    	}
	    	$.messager.progress();
	    	$.ajax({  
	    		type : 'POST',    
	    		url : appPath+'/admin/sysRole/deleteRole.htm',
	    		data: 'roleId='+currentRow.roleId,
	    		success : function(data) {
	    		
	    			var dataObj = eval("("+data+")");
	    			if(dataObj.status==1){
	    		    	$.messager.progress('close');
	    		    	doReset();
	    		    	doSearch();
	    		    	slide('提示','删除角色成功！',3000);
	    		    }else{
	    		    	$.messager.progress('close');
	    		    	slide('警告','系统错误！'+dataObj.error,3000);
	    		    }
	    			
	    		}
	    	
	    	});
	    }    
	});
	
}

/**
 * 设置权限
 */
function setAuth(currentIndex){
	
	var currentRow = $('#table_list').datagrid('getRows')[currentIndex];
	
	$('#ul_auth_tree').tree({    
	    url:appPath+'/admin/sysRole/getRoleAuth.htm?roleId='+currentRow.roleId,
	    method:'post',
	    checkbox:true
	});
	$('#set_auth_role').val(currentRow.roleId);
	$('#win_set_auth').window('open');
	
}

/**
 * 提交角色权限设置
 */
function subSetAuth(){
	
	var nodes = $('#ul_auth_tree').tree('getChecked', ['checked']);	
	var checkIds = '';
	for(var i=0;i<nodes.length;i++){
		
		checkIds = checkIds + nodes[i].id+",";
		//alert(nodes[i].text);
	}
	if(checkIds!=''){
		checkIds = checkIds.substring(0,checkIds.length-1);
	}
	$('#set_auth_check').val(checkIds);
	
	nodes = $('#ul_auth_tree').tree('getChecked', ['indeterminate']);
	var indeIds = '';
	for(var i=0;i<nodes.length;i++){
		
		indeIds = indeIds + nodes[i].id+",";
		//alert(nodes[i].text);
	}
	if(indeIds!=''){
		indeIds = indeIds.substring(0,indeIds.length-1);
	}
	$('#set_auth_inde').val(indeIds);
	
	$.messager.progress();
	$('#setAuthForm').form('submit', {    
		url:appPath+'/admin/sysRole/setRoleAuth.htm',    
		success:function(data){    
		        
		    var dataObj=eval("("+data+")");
		    if(dataObj.status==1){
		    	$.messager.progress('close');
		    	$('#win_set_auth').window('close');
		    	doReset();
		    	doSearch();
		    	slide('提示','权限设置成功！',3000);
		    }else{
		    	$.messager.progress('close');
		    	slide('警告','系统错误！'+dataObj.error,3000);
		    }
		    	
		}    
	});
	
	
}