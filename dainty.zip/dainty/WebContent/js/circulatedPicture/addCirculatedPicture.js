/**
 * 初始化页面
 */
function initPage() {

	$('#type').combobox({
		url : appPath + '/admin/sysCode/getSysCode.htm',
		valueField : "codeValue",
		textField : "codeLabel",
		method : "post",
		width : 200,
		required : true,
		editable : false,

		onSelect : function(data) {
			loadRef(data.codeValue);
		},

		onBeforeLoad : function(param) {
			param.code = 'LBTLX';
		},

		onLoadSuccess : function() {
			$('#type').combobox("setValue", '1');
			loadRef('1');
			$.messager.progress('close');
		},

		onLoadError : function() {
			$.messager.progress('close');
			slide('警告', '图片分类列表加载失败', 3000);
		}
	});

	$.messager.progress();
	$.ajax({
		type : 'POST',
		url : appPath + '/admin/circulatedPicture/getCirculatedPictureSort.htm',
		success : function(data) {
			var dataObj = eval("(" + data + ")");
			if (dataObj.status == 1) {
				$('#add_sort').numberbox("setValue", dataObj.sort);
				$('#addCirculatedPictureForm').form("validate");
				$.messager.progress('close');

			} else {
				$.messager.progress('close');
				slide('警告', '系统错误！' + dataObj.error, 3000);
			}
		}
	});

}

function loadRef(type) {
	switch (type) {
	case '1':
		$('#td_refid').html('活动:');
		$('#div_refId').html('<input id="crefId" name="refId" />');
		$('#crefId').combobox();
		$('#crefId').combobox({
			url : appPath + '/admin/activity/getActivityComboboxList.htm',
			valueField : "ID",
			textField : "ACTNAME",
			method : "post",
			width : 200,
			required : false,
			editable : false,
			onLoadError : function() {
				slide('警告', '活动列表加载失败', 3000);
			},
			onLoadSuccess : function() {
				var data = $('#crefId').combobox("getData");
				if (data.length > 0)
					$('#crefId').combobox("select", data[0].ID);
			},
		});
		break;
	case '2':
		$('#td_refid').html('攻略:');
		$('#div_refId').html('<input id="crefId" name="refId" />');
		$('#crefId').combobox();
		$('#crefId').combobox({
			url : appPath + '/admin/tip/getTipComboboxList.htm',
			valueField : "ID",
			textField : "TIPNAME",
			method : "post",
			width : 199,
			required : false,
			editable : false,
			onLoadError : function() {
				slide('警告', '活动列表加载失败', 3000);
			},
			onLoadSuccess : function() {
				var data = $('#crefId').combobox("getData");
				if (data.length > 0)
					$('#crefId').combobox("select", data[0].ID);
			},

		});
		break;
	case '3':
		$('#td_refid').html('外链:');
		$('#div_refId').html('<input id="crefId" name="refId" style="width: 199px" class="easyui-validatebox" />');
		break;

	default:
		break;
	}
}

/**
 * 新增轮播图表单提交
 */
function subAdd() {
	$.messager.progress();
	$('#addCirculatedPictureForm').form('submit', {
		url : appPath + '/admin/circulatedPicture/addCirculatedPicture.htm',
		onSubmit : function() {

			var isValid = $(this).form('validate');
			if (!isValid) {
				$.messager.progress('close');
			}

			var file1 = $("#add_circulated_picture").val().toLowerCase();
			if (file1.length != 0) {
				if (!/.(gif|jpg|jpeg|png|gif|jpg|png)$/.test(file1)) {
					slide("图片类型必须是.gif,jpeg,jpg,png中的一种")
					return false;
				}
			}
			return isValid;
		},
		success : function(data) {

			var dataObj = eval("(" + data + ")");
			if (dataObj.status == 1) {
				$.messager.progress('close');
				parent.reloadTabGrid("轮播图列表");
				parent.$('#tabs').tabs('close', '新增轮播图');
				slide('提示', '新增轮播图成功！', 3000);
			} else {
				$.messager.progress('close');
				slide('警告', '系统错误！' + dataObj.error, 3000);
			}

		}

	});

}

/**
 * 上传图片
 */
function uploadFile() {

	var formData = new FormData($("#addCirculatedPictureForm")[0]);
	$.ajax({
		type : 'POST',
		url : appPath + "/uploadFile/preUploadImage.htm",
		data : formData,
		async : false,
		cache : false,
		contentType : false,
		processData : false,
		error : function(returndata) {
			slide('提示', '上传轮播图失败！', 3000);
		},

		success : function(data) {

			var dataObj = eval("(" + data + ")");
			if (dataObj.status == 1) {
				$('#filePath').val(dataObj.filePath);
				$('#fileName').val(dataObj.fileName);
				$('#img_preview').attr('height', 200);
				$('#img_preview').attr('width', 400);
				$('#img_preview').attr('src', dataObj.url);
			}
		}
	});
}