/**
 * 初始化页面
 */
function initPage() {

	showTableList();
}

/**
 * 展示轮播图列表信息
 */
function showTableList() {

	$("#table_list").datagrid({
		height : $("#body").height() - $('#search_area').height() - 5,
		width : $("#body").width(),
		method : 'post',
		idField : 'id',
		url : appPath + "/admin/circulatedPicture/getCirculatedPictureList.htm",
		singleSelect : true,
		nowrap : true,
		fitColumns : true,
		rownumbers : true,
		showPageList : true,
		toolbar : '#tt_btn',
		pagination : true,
		pageSize : 5,
		pageList : [ 5, 10, 20, 30, 50 ],
		queryParams : getQueryParams(),
		columns : [ [ {
			field : 'imgUrl',
			title : '图片预览',
			width : 80,
			halign : "center",
			align : "center",
			formatter : function(value) {
				if (value != "" || value != null) {
					return "<img style=\"height: 80px;width: 150px;\" src=\"" + value + "\"/>";
				}
			}
		}, {
			field : 'title',
			title : '标题',
			width : 100,
			halign : "center",
			align : "center"
		}, {
			field : 'typeStr',
			title : '类型',
			width : 40,
			halign : "center",
			align : "center"
		}, {
			field : 'sort',
			title : '排序',
			width : 30,
			halign : "center",
			align : "center"
		}, {
			field : 'stateStr',
			title : '状态',
			width : 30,
			halign : "center",
			align : "center"
		}, {
			field : 'creatorStr',
			title : '发布人',
			width : 30,
			halign : "center",
			align : "center"
		}, {
			field : 'remark',
			title : '备注',
			width : 80,
			halign : "center",
			align : "center"
		}, {
			field : 'createTimeStr',
			title : '创建日期',
			width : 60,
			halign : "center",
			align : "center"
		}, {
			field : 'id',
			title : 'ID',
			width : 80,
			halign : "center",
			align : "center",
			hidden : true
		}, {
			field : 'operation',
			title : '操作',
			width : 60,
			halign : "center",
			align : "center",
			formatter : function(value, row, index) {
				var operStr = $('#row_operation').html();
				var op_type = row.state == 1 ? '禁用' : '开启';
				return operStr.replace(/row_id/gm, row.id).replace(/rowIndex/gm, index).replace(/设置/gm, op_type);
			}
		} ] ]
	});
}

/**
 * 获取查询轮播图信息参数
 */
function getQueryParams() {

	var remark = $('#txt_remark').val();
	var state = $('#cp_state').combobox('getValue');
	var queryParams = {
		'remark' : remark,
		'state' : state
	};
	return queryParams;

}

/**
 * 根据条件查询轮播图
 */
function doSearch() {

	$('#table_list').datagrid('load', getQueryParams());

}

/**
 * 查询条件重置
 */
function doReset() {

	$('#txt_remark').val('');
	$('#cp_state').combobox('setValue', '');

}

/**
 * 编辑轮播图弹出窗口
 */
function set(currentIndex) {

	var currentRow = $('#table_list').datagrid('getRows')[currentIndex];
	var op_type = currentRow.state == 1 ? '禁用' : '开启';
	$.messager.confirm('确认', '您确认想要' + op_type + '这个轮播图？', function(r) {
		if (r) {
			$.messager.progress();
			$.ajax({
				type : 'POST',
				url : appPath + '/admin/circulatedPicture/setCirculatedPicture.htm',
				data : 'id=' + currentRow.id + '&state=' + currentRow.state,
				success : function(data) {

					var dataObj = eval("(" + data + ")");
					if (dataObj.status == 1) {
						$.messager.progress('close');
						doReset();
						doSearch();
						slide('提示', op_type + '轮播图成功！', 3000);
					} else {
						$.messager.progress('close');
						slide('警告', '系统错误！' + dataObj.error, 3000);
					}
				}

			});
		}
	});
}

/**
 * 删除轮播图
 */
function dele(currentIndex) {

	$.messager.confirm('确认', '您确认想要删除这个轮播图？', function(r) {
		if (r) {

			var currentRow = $('#table_list').datagrid('getRows')[currentIndex];
			$.messager.progress();
			$.ajax({
				type : 'POST',
				url : appPath + '/admin/circulatedPicture/deleteCirculatedPicture.htm',
				data : 'id=' + currentRow.id,
				success : function(data) {

					var dataObj = eval("(" + data + ")");
					if (dataObj.status == 1) {
						$.messager.progress('close');
						doReset();
						doSearch();
						slide('提示', '删除轮播图成功！', 3000);
					} else {
						$.messager.progress('close');
						slide('警告', '系统错误！' + dataObj.error, 3000);
					}
				}

			});
		}
	});

}

window.top["reload_datagrid"] = function() {
	$('#table_list').datagrid('load', getQueryParams());
};