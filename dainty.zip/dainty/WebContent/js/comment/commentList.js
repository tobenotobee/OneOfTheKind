/**
 * 
 */

function initPage() {

	$('#tabs').tabs({
		border : true,
		fit : true,
		onSelect : function(title, index) {
			if (index == 0) {
				showTableList_guide();
			} else {
				showTableList_pro();
			}
		}
	});
	showTableList_guide();
}

function showTableList_guide() {

	$('#td_name').html('导游：');
	$.messager.progress();
	$('#g_rating').combobox({
		url : appPath + '/admin/sysCode/getSysCode.htm',
		valueField : 'codeValue',
		textField : 'codeLabel',
		method : 'post',
		width : 100,
		editable : false,

		onBeforeLoad : function(param) {
			param.code = 'RATING'
		},
		onLoadSuccess : function() {
			$.messager.progress('close');
		},
		onLoadError : function() {
			$.messager.progress('close');
			slide('警告', '版本类型列表加载失败', 3000);
		}

	});

	$('#guide_table_list').datagrid({
		height : $('#body').height() - $('#guide_search_area').height() - 40,
		width : $('#body').width() - 20,
		methdo : 'post',
		idField : 'id',
		url : appPath + '/admin/comment/getCommentList.htm',
		singleSelect : true,
		nowrap : true,
		fitColumns : true,
		rownumbers : true,
		showPageList : true,
		pagination : true,
		pageSize : 10,
		pageList : [ 5, 10, 20, 30, 50 ],
		queryParams : getQueryParams(1),
		columns : [ [ {
			field : 'id',
			title : 'ID',
			width : 80,
			halign : 'center',
			align : 'center',
			hidden : true
		}, {
			field : 'guideName',
			title : '导游',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'proName',
			title : '产品',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'rating',
			title : '星级',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'commenter',
			title : '评论人',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'createTimeStr',
			title : '评论时间',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'content',
			title : '评论内容',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'isUseStr',
			title : '状态',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'operation',
			title : '操作',
			width : 160,
			halign : "center",
			align : "center",
			formatter : function(value, row, index) {
				var operStr = $('#row_operation1').html();
				return operStr.replace(/rowIndex/gm, index);
			}
		} ] ]
	});
}

function showTableList_pro() {

	$('#td_name').html('产品：');

	$('#p_rating').combobox({
		url : appPath + '/admin/sysCode/getSysCode.htm',
		valueField : 'codeValue',
		textField : 'codeLabel',
		method : 'post',
		width : 100,
		editable : false,

		onBeforeLoad : function(param) {
			param.code = 'RATING'
		},
		onLoadSuccess : function() {
			$.messager.progress('close');
		},
		onLoadError : function() {
			$.messager.progress('close');
			slide('警告', '版本类型列表加载失败', 3000);
		}

	});

	$('#pro_table_list').datagrid({
		height : $('#body').height() - $('#pro_search_area').height() - 40,
		width : $('#body').width() - 20,
		methdo : 'post',
		idField : 'id',
		url : appPath + '/admin/comment/getCommentList.htm',
		singleSelect : true,
		nowrap : true,
		fitColumns : true,
		rownumbers : true,
		showPageList : true,
		pagination : true,
		pageSize : 10,
		pageList : [ 5, 10, 20, 30, 50 ],
		queryParams : getQueryParams(2),
		columns : [ [ {
			field : 'id',
			title : 'ID',
			width : 80,
			halign : 'center',
			align : 'center',
			hidden : true
		}, {
			field : 'proName',
			title : '产品',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'guideName',
			title : '导游',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'rating',
			title : '星级',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'commenter',
			title : '评论人',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'createTimeStr',
			title : '评论时间',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'content',
			title : '评论内容',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'isUseStr',
			title : '状态',
			width : 80,
			halign : 'center',
			align : 'center'
		}, {
			field : 'operation',
			title : '操作',
			width : 160,
			halign : "center",
			align : "center",
			formatter : function(value, row, index) {
				var operStr = $('#row_operation2').html();
				return operStr.replace(/rowIndex/gm, index);
			}
		} ] ]
	});
}

function getQueryParams(index) {

	var guideName = $('#g_guide_name').val();
	var rating = $('#g_rating').combobox('getValue');
	var createTime = $('#g_create_time').datebox('getValue');
	var content = $('#g_context').val();

	var queryParams = {
		'guideName' : guideName,
		'rating' : rating,
		'createTime' : createTime,
		'content' : content,
		'type' : index
	};
}

function doSearch(index) {
	if (index == 1) {
		$('#guide_table_list').datagrid('load', getQueryParams(index));
	} else {
		$('#pro_table_list').datagrid('load', getQueryParams(index));
	}
}

function doReset(index) {

	$('#g_guide_name').val('');
	$('#g_rating').combobox('setValue', '');
	$('#g_create_time').datebox('setValue', '');
	$('#g_content').val('');
}

function shield(currentIndex, index) {

	$.messager.confirm('确认', '您确认要屏蔽这条评论吗', function(r) {
		var currentRow;
		if (r) {
			if (index == 1) {
				currentRow = $('#g_table_list').datagrid('getRows')[currentIndex];
			} else {
				currentRow = $('#p_table_list').datagrid('getRows')[currentIndex];
			}
			$.messager.progress();
			$.ajax({
				type : 'POST',
				url : appPath + '/admin/comment/shieldComment.htm',
				data : 'id=' + currentRow.id,
				success : function(data) {

					var dataObj = eval("(" + data + ")");
					if (dataObj.status == 1) {
						$.messager.progress('close');
						doSearch();
						slide('提示', '屏蔽评论成功！', 3000);
					} else {
						$.messager.progress('close');
						slide('警告', '系统错误！' + dataObj.error, 3000);
					}

				}
			});

		}

	});

}