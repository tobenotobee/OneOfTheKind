/**
 * 初始化页面
 */
function initPage() {

	showTableList();

	initWins();
}

/**
 * 展示会员列表信息
 */
function showTableList() {

	$("#table_list").datagrid({
		height : $("#body").height() - $('#search_member').height() - 5,
		width : $("#body").width(),
		method : 'post',
		idField : 'id',
		url : appPath + "/admin/member/getMemberList.htm",
		singleSelect : true,
		nowrap : true,
		fitColumns : true,
		rownumbers : true,
		showPageList : true,
		toolbar : '#tt_btn',
		pagination : true,
		pageSize : 10,
		pageList : [ 5, 10, 20, 30, 50 ],
		queryParams : getQueryParams(),
		columns : [ [ {
			field : 'memberName',
			title : '会员名称',
			width : 160,
			halign : "center",
			align : "center"
		}, {
			field : 'createTimeStr',
			title : '创建日期',
			width : 60,
			halign : "center",
			align : "center"
		}, {
			field : 'id',
			title : 'id',
			width : 80,
			halign : "center",
			align : "center",
			hidden : true
		}, {
			field : 'operation',
			title : '操作',
			width : 160,
			halign : "center",
			align : "center",
			formatter : function(value, row, index) {
				var operStr = $('#row_operation').html();
				return operStr.replace(/row_id/gm, row.id).replace(/rowIndex/gm, index);
			}
		} ] ]
	});
}

/**
 * 初始化操作窗口
 */
function initWins() {

	// 初始化新增窗口
	$('#win_add_member').window({
		width : 400,
		height : 160,
		modal : true,
		title : '新增区域',
		collapsible : false,
		minimizable : false,
		maximizable : false,
		resizable : false,
		iconCls : 'icon-save'
	});
	$('#win_add_member').window('close');

}

/**
 * 获取查询会员信息参数
 */
function getQueryParams() {

	var memberName = $('#txt_member_name').val();
	var queryParams = {
		'memberName' : memberName,
	};
	return queryParams;

}

/**
 * 根据条件查询会员
 */
function doSearch() {

	$('#table_list').datagrid('load', getQueryParams());

}

/**
 * 查询条件重置
 */
function doReset() {

	$('#txt_member_name').val('');

}

/**
 * 删除会员
 */
function dele(currentIndex) {

	$.messager.confirm('确认', '您确认想要删除这个会员吗？', function(r) {
		if (r) {

			var currentRow = $('#table_list').datagrid('getRows')[currentIndex];
			$.messager.progress();
			$.ajax({
				type : 'POST',
				url : appPath + '/admin/member/deleteMember.htm',
				data : 'id=' + currentRow.id,
				success : function(data) {

					var dataObj = eval("(" + data + ")");
					if (dataObj.status == 1) {
						$.messager.progress('close');
						doReset();
						doSearch();
						slide('提示', '删除会员成功！', 3000);
					} else {
						$.messager.progress('close');
						slide('警告', '系统错误！' + dataObj.error, 3000);
					}
				}

			});
		}
	});

}



function loadCity(provinceId) {

	$('#cmb_city').combobox({
		url : appPath + '/admin/member/getCityList.htm',
		valueField : "name",
		textField : "name",
		method : "post",
		width : 100,
		required : true,
		editable : false,

		onBeforeLoad : function(param) {
			param.id = provinceId;
		},

		onLoadSuccess : function() {
			var data = $('#cmb_city').combobox("getData");
			if (data.length > 0) {
				$('#cmb_city').combobox("select", data[0].name);
			}
			$.messager.progress('close');
		},

		onLoadError : function() {
			$.messager.progress('close');
			slide('警告', '城市列表加载失败', 3000);
		}
	});
}

