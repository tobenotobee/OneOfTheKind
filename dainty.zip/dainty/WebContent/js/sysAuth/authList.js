

/**
 * 初始化页面
 */
function initPage(){
	showAuthTree('');
	initWins();
}

function initWins(){
	//初始化新增窗口
	$('#win_add_auth').window({    
		width:500,    
		height:300,    
		modal:true,
		title:'新增权限',
		collapsible:false,
		minimizable:false,
		maximizable:false,
		resizable:false,
		iconCls:'icon-save'
	});
	$('#win_add_auth').window('close');
	//初始化修改窗口
	$('#win_update_auth').window({    
		width:500,    
		height:300,    
		modal:true,
		title:'修改权限',
		collapsible:false,
		minimizable:false,
		maximizable:false,
		resizable:false,
		iconCls:'icon-edit'
	});
	$('#win_update_auth').window('close');
	
}

/**
 * 展示权限树
 */
function showAuthTree(openNodeId){
		
	$.ajax({  
		type : 'POST',    
		url : appPath+'/admin/sysAuth/authTree.htm?openNodeId='+openNodeId,
		success : function(data) {
			var dataObj=eval("("+data+")");
		    var arrayObj = new Array();
		    arrayObj.push(dataObj);
		    //$.messager.alert('提示',dataObj);  
		    $('#auth_list').treegrid({    
		    	data:arrayObj,    
		    	idField:'authId',    
		    	treeField:'authName',
		    	method: 'post',
		    	fitColumns: true,
		    	fit:true,
		    	onContextMenu: onContextMenu,
		    	columns:[[    
		    	          {field:'authName',title:'权限名称',width:180},    
		    		      {field:'authType',title:'权限类型',width:80,align:'center'},    
		    		      {field:'authResource',title:'权限URL',width:160,align:'center'},
		    		      {field:'sort',title:'排序',width:60,align:'center'}
		    		    ]]    
		    });  
		},  
		error : function(XMLHttpRequest, textStatus, errorThrown) {  
			//$.messager.alert('警告','系统错误！'+errorThrown);
			slide('警告','系统错误！'+errorThrown,3000);
		}  
	});  
		
}

/**
 * 权限树菜单绑定
 * @param e
 * @param row
 */
function onContextMenu(e,row){
	e.preventDefault();
	var nodeId = row.authId;
	//alert(nodeId);
	$(this).treegrid('select', nodeId);
	var editAuth = $('#auth_menu').menu('findItem', '修改权限');
	var deleAuth = $('#auth_menu').menu('findItem', '删除权限');
	//判断如果是权限树根节点不能进行删除和修改
	if(nodeId==0){
		
		if(editAuth!=null){
			$('#auth_menu').menu('disableItem', editAuth.target);
		}
		if(deleAuth!=null){
			$('#auth_menu').menu('disableItem', deleAuth.target);
		}
		
	}else{
		
		if(editAuth!=null){
			$('#auth_menu').menu('enableItem', editAuth.target);
		}
		if(deleAuth!=null){
			$('#auth_menu').menu('enableItem', deleAuth.target);
		}
		
	}
	$('#auth_menu').menu('show',{
		left: e.pageX,
		top: e.pageY
	});
}

/**
 * 新增权限弹出窗口
 */
function append(){
		
	$('#addAuthForm').form('clear');
	$('#sel_auth_type').combobox('setValue','menu');
	
	$('#win_add_auth').window('open');
	var selected = $('#auth_list').treegrid('getSelected');
	//alert(selected.authId+" "+selected.authName);
	$('#add_parent_id').val(selected.authId);
		
}

/**
 * 新增权限表单提交
 */
function subAdd(){
		
	$.messager.progress();
	$('#addAuthForm').form('submit', {    
		url:appPath+'/admin/sysAuth/addAuth.htm',    
		onSubmit: function(){    
		    	
		    var isValid = $(this).form('validate');
		    if(!isValid){
		    	$.messager.progress('close');
		    }
		    return isValid;

		},    
		success:function(data){    
		        
		    var dataObj=eval("("+data+")");
		    if(dataObj.status==1){
		    	$.messager.progress('close');
		    	$('#win_add_auth').window('close');
		    	showAuthTree(getOpenNodeIdStr($('#add_parent_id').val()));
		    	slide('提示','新增权限成功！',3000);
		    }else{
		    	$.messager.progress('close');
		    	slide('警告','系统错误！'+dataObj.error,3000);
		    }
		    	
		    	
		}    
	});  
		
}

/**
 * 获取当前nodeID的所有父ID
 */
function getOpenNodeIdStr(openNodeId){
	
	var parentIds = openNodeId+",";

	while(true){
		
		var parent = $('#auth_list').treegrid('getParent',openNodeId);
		if(parent==null){
			break;
		}
		parentIds = parentIds+parent.authId+",";
		//alert(parentIds);
		openNodeId = parent.authId;
	}
	
	//alert(parentIds.substring(0,parentIds.length-1));
	return parentIds.substring(0,parentIds.length-1);
	
}

/**
 * 修改权限弹出窗口
 */
function update(){
		
	$('#updateAuthForm').form('clear'); 

	$('#win_update_auth').window('open');
	
	var selected = $('#auth_list').treegrid('getSelected');
	var parent = $('#auth_list').treegrid('getParent',selected.authId);
	if(parent==null){
		$('#update_parent_id').val(0);
	}else{
		$('#update_parent_id').val(parent.authId);
	}
	$('#update_auth_id').val(selected.authId);
	$('#up_auth_name').val(selected.authName);
	$('#up_auth_type').combobox('setValue',selected.authType);
	$('#up_auth_resource').val(selected.authResource);
	$('#up_sort').numberbox('setValue', selected.sort);
	$('#updateAuthForm').form('validate');
	
	//slide('提示','上级权限：'+parent.authName,6000);
	
}

/**
 * 提交修改权限信息
 */
function subUpdate(){
	
	$.messager.progress();
	$('#updateAuthForm').form('submit', {    
		url:appPath+'/admin/sysAuth/updateAuth.htm',    
		onSubmit: function(){    
		    	
		    var isValid = $(this).form('validate');
		    if(!isValid){
		    	$.messager.progress('close');
		    }
		    return isValid;

		},    
		success:function(data){    
		        
		    var dataObj=eval("("+data+")");
		    if(dataObj.status==1){
		    	$.messager.progress('close');
		    	$('#win_update_auth').window('close');
		    	showAuthTree(getOpenNodeIdStr($('#update_parent_id').val()));
		    	slide('提示','修改权限成功！',3000);
		    }else{
		    	$.messager.progress('close');
		    	slide('警告','系统错误！'+dataObj.error,3000);
		    }
		    	
		    	
		} 
	});
	
}

/**
 * 删除权限
 */
function removeAuth(){
	
	$.messager.confirm('确认','您确认想要删除这个权限以及它的所有子权限？',function(r){    
	    if (r){    
	    	
	    	var selected = $('#auth_list').treegrid('getSelected');
	    	var deleteIds = selected.authId;
	    	var child = $('#auth_list').treegrid('getChildren',selected.authId);
	    	for(var i=0;i<child.length;i++){
	    		
	    		deleteIds = deleteIds + ","+child[i].authId;
	    		//alert(child[i].authName+":"+child[i].authId);
	    	}
	    	//alert(deleteIds);
	    	subRemove(deleteIds,selected.authId);
	    }    
	});
}

/**
 * 异步删除权限以及对应所有子权限
 */
function subRemove(deleteIds,currentId){
	
	$.messager.progress();
	$.ajax({  
		type : 'POST',    
		url : appPath+'/admin/sysAuth/deleteAuth.htm',
		data: 'deleteIds='+deleteIds,
		success : function(data) {
		
			var dataObj = eval("("+data+")");
			if(dataObj.status==1){
		    	$.messager.progress('close');
		    	showAuthTree(getOpenNodeIdStr(currentId));
		    	slide('提示','删除权限成功！',3000);
		    }else{
		    	$.messager.progress('close');
		    	slide('警告','系统错误！'+dataObj.error,3000);
		    }
			
		}
	
	});	
	
}