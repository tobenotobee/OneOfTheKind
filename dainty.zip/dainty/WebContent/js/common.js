$.extend($.fn.validatebox.defaults.rules, {    
	    equVal: {
	    	
	        validator: function(value,param){
	            return value == $(param[0]).val();    
	        },    
	        message: '{1}'
	        
	    },
	    reVal: {
	    	
	        validator: function(value,param){
	        	alert($(param[0]).val()!="");
	        	alert(value=="");
	        	if($(param[0]).val()!=""&&value==""){
	        		return false;
	        	}else{
	        		return true;
	        	}
	                
	        },    
	        message: '{1}'
	        
	    },
	    remoteValiUser: {
	    	
	    	validator:function(value,param){
	    		
	    		var result = false;
	    		$.ajax({  
		    		type : param[1],    
		    		url : param[0],
		    		data: 'userName='+value,
		    		async:false,
		    		success : function(data) {
		    		
		    			var dataObj = eval("("+data+")");
		    			result = dataObj.resbool;
		    			
		    		}
		    	
		    	});
	    		return result;
	    		
	    	},
	    	message: '用户名已经存在'
	    	
	    },
	    remoteValiSort: {
	    	
	    	validator:function(value,param){
	    		
	    		var result = false;
	    		$.ajax({  
		    		type : param[1],    
		    		url : param[0],
		    		data: 'sort='+value,
		    		async:false,
		    		success : function(data) {
		    		
		    			var dataObj = eval("("+data+")");
		    			result = dataObj.resbool;
		    		}
		    	
		    	});
	    		return result;
	    		
	    	},
	    	message: '排序号已经存在'
	    },
	    englishOrNum : {
            validator : function(value) {
                return /^[a-zA-Z0-9_]{1,}$/.test(value);
            },
            message : '请输入英文、数字或者下划线'
        }
});

/**
 * 系统信息提示弹出框
 * @param title
 * @param msg
 * @param timeout
 */
function slide(title,msg,timeout){
	$.messager.show({
		title:title,
		msg:msg,
		timeout:timeout,
		showType:'slide'
	});
}

/**
 * 关闭窗口
 * @param winName
 */
function closeWin(winName){
	
	$('#'+winName).window('close');
	
}


/**
 * 截取时间为时间戳(去除.0)
 * @param delSubTime subTime
 */
function delSubTime(subTime){
	if(subTime!=undefined){
		return subTime.substring(0,19);
	}
	
}

/**
 * 截取时间为日期(去除.0)
 * @param delSubDate subTime
 */
function delSubDate(subTime){
	if(subTime!=undefined){
		return subTime.substring(0,10);
	}
	
}

//砍掉时间字符串后两位".0"
function dateStrCut(value) {
	if(value != null && value != undefined && value.length > 2) {
		return value.substr(0,value.length-2);
	} else {
		return "";
	}	
}

//跨IFrame增加Tabs
function addIFrameTabs(title,url) {
	if(parent.$('#tabs').tabs('exists', title)) {
		parent.$('#tabs').tabs('close', title);
	}
	parent.$('#tabs').tabs('add',{  
		title:title,  
		content:'<iframe src="'+url+'" frameBorder="0" border="0" scrolling="no" style="width: 100%; height: 100%;"/>',  
		closable:true
	});
}