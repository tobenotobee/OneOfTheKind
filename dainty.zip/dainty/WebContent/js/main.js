function initPage() {

	initWin();

	$('#tabs').tabs({
		border : true,
		fit : true,
		tools : '#tab-tools',
		onSelect : function(title, index) {

		}
	});
	$('#a_quit_sys').bind('click', function() {

		$.messager.confirm('确认', '您确认想要退出系统？', function(r) {
			if (r) {
				location.href = appPath + "/j_spring_security_logout";
			}
		});

	});

	$('#a_edit_password').bind('click', function() {

		changePwd();

	});
}

function addTabs(title, url) {
	if (!$('#tabs').tabs('exists', title)) {
		$('#tabs').tabs('add', {
			title : title,
			content : '<iframe src="' + url + '" frameBorder="0" border="0" scrolling="no" style="width: 100%; height: 100%;"/>',
			closable : true
		});
	} else {

		$('#tabs').tabs('select', title);
	}
}

function reloadTab() {

	var tab = $('#tabs').tabs('getSelected'); // 获取选择的面板
	// alert(tab);
	if (tab != null) {
		tab.panel('refresh');
	}

}

function initWin() {
	// 初始化修改密码窗口
	$('#win_change_pwd').window({
		width : 400,
		height : 260,
		modal : true,
		title : '修改密码',
		collapsible : false,
		minimizable : false,
		maximizable : false,
		resizable : false,
		iconCls : 'icon-edit'
	});
	$('#win_change_pwd').window('close');

}

function changePwd() {

	$('#changePwdForm').form('clear');
	$('#win_change_pwd').window('open');
}

function subUpdate() {

	$.messager.progress();
	$('#changePwdForm').form('submit', {
		url : appPath + '/admin/sysUser/changePwd.htm',
		onSubmit : function() {

			var isValid = $(this).form('validate');
			if (!isValid) {
				$.messager.progress('close');
			}
			return isValid;

		},
		success : function(data) {

			var dataObj = eval("(" + data + ")");
			if (dataObj.status == 1) {
				$.messager.progress('close');
				$('#win_change_pwd').window('close');
				slide('提示', '密码修改成功！', 3000);
			} else {
				$.messager.progress('close');
				slide('警告', '系统错误！' + dataObj.error, 3000);
			}

		}
	});

}

function reloadTabGrid(title) {
	if ($("#tabs").tabs('exists', title)) {
		$('#tabs').tabs('select', title);
		window.top.reload_datagrid.call();
	}
}