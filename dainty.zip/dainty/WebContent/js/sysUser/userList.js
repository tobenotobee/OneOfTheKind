
/**
 * 初始化页面
 */
function initPage(){
	
	$('#new_pwd_one').bind('change',function(){
		
		if($('#new_pwd_one').val()!=""){
			$('#new_pwd_two').validatebox('enableValidation');
		}else{
			$('#new_pwd_two').validatebox('disableValidation');
			$('#new_pwd_two').val('');
		}
		
	});
	showTableList();
	initWins();
	
}

/**
 * 展示用户列表信息
 */
function showTableList(){
	
	$("#table_list").datagrid({
		height:$("#body").height()-$('#search_area').height()-5,
		width:$("#body").width(),
		method:'post',
		idField:'userId',
		url:appPath+"/admin/sysUser/getUserList.htm",  
		singleSelect:true,
		nowrap:true,
		fitColumns:true,
		rownumbers:true,
		showPageList:true,
		toolbar:'#tt_btn',  
        pagination:true,
        pageSize:10,
        pageList:[5,10,20,30,50],
        queryParams:getQueryParams(),
		columns:[[
			{field:'userName',title:'用户名',width:80,halign:"center", align:"center"},
			{field:'realName',title:'真实姓名',width:80,halign:"center", align:"center"},
			{field:'statusStr',title:'状态',width:50,halign:"center", align:"center"},
			{field:'status',title:'状态ID',width:50,halign:"center", align:"center",hidden:true},
			{field:'roleName',title:'所属角色',width:100,halign:"center", align:"center"},
			{field:'roleId',title:'角色ID',width:50,halign:"center", align:"center",hidden:true},
			{field:'isAdmin',title:'是否超级',width:50,halign:"center", align:"center",hidden:true},
			{field:'lastLoginDateStr',title:'最近登录时间',width:160,halign:"center", align:"center"},
			{field:'operation',title:'操作',width:160,halign:"center", align:"center",
				formatter: function(value,row,index){
					var operStr = $('#row_operation').html();
					return operStr.replace(/rowIndex/gm,index);
				}
			}
		]]
	
	});
}

/**
 * 初始化操作窗口
 */
function initWins(){
	
	//初始化新增窗口
	$('#win_add_user').window({    
		width:400,    
		height:360,    
		modal:true,
		title:'新增用户',
		collapsible:false,
		minimizable:false,
		maximizable:false,
		resizable:false,
		iconCls:'icon-save'
	});
	$('#win_add_user').window('close');
	
	//初始化修改窗口
	$('#win_update_user').window({    
		width:400,    
		height:360,    
		modal:true,
		title:'修改用户',
		collapsible:false,
		minimizable:false,
		maximizable:false,
		resizable:false,
		iconCls:'icon-edit'
	});
	$('#win_update_user').window('close');
	
}

/**
 * 获取查询用户信息参数
 */
function getQueryParams(){
	
	var userName = $('#txt_user_name').val();
	var realName = $('#txt_real_name').val();
	var queryParams = {'userName':userName,'realName':realName};
	return queryParams;
	
}

/**
 * 根据条件查询用户
 */
function doSearch(){
	
	$('#table_list').datagrid('load',getQueryParams());
	
}

/**
 * 查询条件重置
 */
function doReset(){
	
	 $("#txt_user_name").val("");
	 $("#txt_real_name").val("");
	 
}

/**
 * 新增用户
 */
function append(){
	
	$('#addUserForm').form('clear');
	$('#win_add_user').window('open');
	$('#add_user_status').combobox('setValue','0');
	$.messager.progress();
	$('#add_role_id').combobox({    
	    url:appPath+'/admin/sysRole/getAllRole.htm',    
	    valueField:'roleId',    
	    textField:'roleName',
	    method:'post',
	    width:199,
	    required:true,
	    editable:false,
	    onLoadSuccess:function(){
	    	
	    	$.messager.progress('close');
	    	
	    },
	    onLoadError:function(){
	    	
	    	$.messager.progress('close');
	    	slide('警告','加载角色信息出错！请重新登陆！',3000);
	    	//location.href=appPath+"/j_spring_security_logout";
	    }
	});
	
}
/**
 * 新增用户表单提交
 */
function subAdd(){
		
	$.messager.progress();
	$('#addUserForm').form('submit', {    
		url:appPath+'/admin/sysUser/addUser.htm',    
		onSubmit: function(){    
		    	
		    var isValid = $(this).form('validate');
		    if(!isValid){
		    	$.messager.progress('close');
		    }
		    return isValid;

		},    
		success:function(data){    
		        
		    var dataObj=eval("("+data+")");
		    if(dataObj.status==1){
		    	$.messager.progress('close');
		    	$('#win_add_user').window('close');
		    	doReset();
		    	doSearch();
		    	slide('提示','新增用户成功！',3000);
		    }else{
		    	$.messager.progress('close');
		    	slide('警告','系统错误！'+dataObj.error,3000);
		    }
		    	
		    	
		}    
	});  
		
}

/**
 * 修改用户弹出窗口
 */
function update(currentIndex){
	
	$('#updateUserForm').form('clear');
	
	var currentRow = $('#table_list').datagrid('getRows')[currentIndex];
	$('#hid_user_id').val(currentRow.userId);
	$('#hid_user_name').val(currentRow.userName);
	$('#la_user_name').html(currentRow.userName);
	$('#update_real_name').val(currentRow.realName);
	$('#update_user_status').combobox('setValue',currentRow.status);
	$.messager.progress();
	$('#update_role_id').combobox({    
	    url:appPath+'/admin/sysRole/getAllRole.htm',    
	    valueField:'roleId',    
	    textField:'roleName',
	    method:'post',
	    width:199,
	    required:true,
	    editable:false,
	    onLoadSuccess:function(){
	    	
	    	$.messager.progress('close');
	    	$('#update_role_id').combobox('setValue',currentRow.roleId);
	    	
	    },
	    onLoadError:function(){
	    	
	    	$.messager.progress('close');
	    	slide('警告','加载角色信息出错！请重新登陆！',3000);
	    	//location.href=appPath+"/j_spring_security_logout";
	    }
	});
	
	$('#new_pwd_two').validatebox('disableValidation');
	$('#updateUserForm').form('validate');
	
	$('#win_update_user').window('open');
	
}

/**
 * 提交用户修改信息
 */
function subUpdate(){
	
	$.messager.progress();
	$('#updateUserForm').form('submit', {    
		url:appPath+'/admin/sysUser/updateUser.htm',    
		onSubmit: function(){    
		    	
		    var isValid = $(this).form('validate');
		    if(!isValid){
		    	$.messager.progress('close');
		    }
		    return isValid;

		},    
		success:function(data){    
		        
		    var dataObj=eval("("+data+")");
		    if(dataObj.status==1){
		    	$.messager.progress('close');
		    	$('#win_update_user').window('close');
		    	doReset();
		    	doSearch();
		    	slide('提示','修改用户成功！',3000);
		    }else{
		    	$.messager.progress('close');
		    	slide('警告','系统错误！'+dataObj.error,3000);
		    }
		    	
		    	
		}    
	});
	
}

/**
 * 删除用户
 */
function dele(currentIndex){
	
	$.messager.confirm('确认','您确认想要删除这个用户？',function(r){    
	    if (r){    
	    	
	    	var currentRow = $('#table_list').datagrid('getRows')[currentIndex];
	    	if(currentRow.isAdmin==1){
	    		$.messager.alert("警告","超级管理员不能删除！","warning");
	    		return;
	    	}
	    	$.messager.progress();
	    	$.ajax({  
	    		type : 'POST',    
	    		url : appPath+'/admin/sysUser/deleteUser.htm',
	    		data: 'userId='+currentRow.userId,
	    		success : function(data) {
	    		
	    			var dataObj = eval("("+data+")");
	    			if(dataObj.status==1){
	    		    	$.messager.progress('close');
	    		    	doReset();
	    		    	doSearch();
	    		    	slide('提示','删除用户成功！',3000);
	    		    }else{
	    		    	$.messager.progress('close');
	    		    	slide('警告','系统错误！'+dataObj.error,3000);
	    		    }
	    			
	    		}
	    	
	    	});
	    }    
	});
	
}
