/**
 *此框架 将管理部分及实时部分综合为一体，将不再采用拆分工程的方式
 *此框架需要进行完善或补充，后续添加请进行申请并说明；
 *适用于来吧旅游网；
 *其他项目使用请提前说明方便进行完善；
 *若存在bug或不合理请进行反馈;
 *songss v1.0 2015-9-29
**/
   
   使用技术构成说明：
   		1、spring-mvc-3.x; mybatis-3.2; springJdbc;Maven;
   		2、flexsdk3.5; blazeds3.x;flexsockt;
   		3、jquery1.x,easui;

   src 包结构说明：
		1、cn.bluemobi           		包为所有包的前缀
		2、cn.bluemobi.admin.constant	包为项目中常量存放包
		3、cn.bluemobi.admin.controller	包为页面请求地址
		4、cn.bluemobi.admin.dao			包为数据交互层
		5、cn.bluemobi.admin.dao.mybatis	包为系统管理模块交互层、如果因个人原因使用mybatis的话在这里操作。
		6、cn.bluemobi.admin.model		包为实体类
		7、cn.bluemobi.admin.security	包为安全策略方面的拦截器等
		8、cn.bluemobi.admin.service		包为全部的Sevice层的实现
		9、cn.bluemobi.admin.util		包为公共包名 存放公共使用的类
		10、cn.bluemobi.admin.vo			包为公共使用的实体对象类
		
   配置文件结构说明：
   		1、jdbc.properties     	为数据库配置文件
   		2、log4j.properties		为log4j日志文件配置
   		3、mybatis				为mybatis配置文件
   		4、spring-context.xml	为数据库连接池
   		5、spring-mvc.xml		为springMVC配置文件
   		6、spring-security.xml	为过滤器安全配置文件
   		
  WebContent 文件夹说明：

		1、css		为css资源	
		2、images	为图片资源		
		3、js		为模块对应js		
		4、resource	为第三方插件	
		5、WEB-INF-page   为模块页面		
		6...... 功能模块命名规则说明 需要项目经理进行制定
		请严重按照此说明进行 包、文件夹、实现文件的添加
		
---------------数据库规则
各个表有自己的命名规则如下：
1、
	表：t_
	视图：v_
	函数方法：f_
2、表规则：
	表主键：表明+id由32位随机uuid生成，在数据库新建函数getUUID();去掉'-',转大写返回值。非特殊情况请勿使用自增。
	除过各别表都应存在：ID主键，creater-创建人，createDate-创建日期，lastupdater-最后修改人，lastupdatedate-最后修改时间，
	is_use-是否启用(根据情况是否添加)，sort-排序(根据情况是否添加)。
3、表明、表列名必须在数据库填写描述。如果是类型必须声明类型说明。非0即1
4、过程、函数创建时必须声明该函数的用途注释。
5、数据库建立码表，存放常用信息。
		
---------------spp接口
1、app以json数据传输，如果有加密请注明加密。如果客户没有提供https平常的接口使用aes加密，下单、支付等重要接口使用rsa加密。
2、app登录时候记录登录人的信息并且生成token，每次验证token是否是当前登录人。
3、接口请求参数，返回值有规定格式请参考word。
4、返回值有规定格式请参考word。





V 1.0
轮播图
