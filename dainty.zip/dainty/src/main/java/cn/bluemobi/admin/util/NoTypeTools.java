package cn.bluemobi.admin.util;

/**
 * 无法分类的公共工具
 * @author weit
 */
public class NoTypeTools {
	
	private static String[] str = {"1","2","3","4","5","6","7","8","9","0"};
	
	/**
	 * 生成六位随机数验证码
	 * @return
	 */
	public static String getIdentCode(){
		StringBuffer identCode = new StringBuffer("");
		for(int i = 0; i < 6; i++){
			identCode.append((int) (Math.random() * 10));
		}
		return identCode.toString();
	}
}
