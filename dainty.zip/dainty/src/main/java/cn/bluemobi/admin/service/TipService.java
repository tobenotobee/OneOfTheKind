/**    
 * @Title: TipService.java  
 * @Package: cn.bluemobi.admin.service  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月16日 下午6:34:07  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.Tip;

/**
 * @ClassName: TipService
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月16日 下午6:34:07
 * 
 */
public interface TipService {

	/**
	 * 
	 * @Description: 获取攻略列表+分页
	 * @param paramap
	 * @return
	 * @throws
	 */
	public List<Tip> getTipsForPage(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 新增攻略
	 * @param tip
	 * @throws
	 */
	public void insertTip(Tip tip);

	/**
	 * 
	 * @Description:修改攻略
	 * @param tip
	 * @throws
	 */
	public void updateTip(Tip tip);

	/**
	 * 
	 * @Description: 删除攻略
	 * @param id
	 * @throws
	 */
	public void deleteTip(String id);

	/**
	 * 
	 * @Description: 获取攻略下拉列表
	 * @return
	 * @throws
	 */
	public List<Map<String, String>> getTipCombobox();

	/******************************** APP *******************************/
	/**
	 * 
	 * @Description: 获取攻略列表
	 * @param paramap
	 * @return
	 * @throws
	 */
	public List<Map<String, Object>> getTipList(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取攻略详情
	 * @param id
	 * @return
	 * @throws
	 */
	public Map<String, Object> getTip(String id);

}
