package cn.bluemobi.admin.util;

public class ValidateTools {
	
	/**
	 * 判断是否为空
	 * @param data
	 * @return
	 */
	public static boolean isEmpty(String data){
		return data != null && !"".equals(data);
	}
}
