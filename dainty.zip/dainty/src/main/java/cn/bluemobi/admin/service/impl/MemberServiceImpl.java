/**    
 * @Title: MemberServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月17日 下午8:17:01  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.MemberDetailMapper;
import cn.bluemobi.admin.model.MemberDetail;
import cn.bluemobi.admin.service.MemberService;

/**
 * @ClassName: MemberServiceImpl
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月17日 下午8:17:01
 * 
 */
@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberDetailMapper memberDetailMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.MemberService#getMemberList(java.util.Map)
	 */
	@Override
	public List<MemberDetail> getMemberList(Map<String, Object> paramap) {
		return memberDetailMapper.getMemberList(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.MemberService#getMembersCount(java.util
	 * .Map)
	 */
	@Override
	public long getMembersCount(Map<String, Object> paramap) {
		return memberDetailMapper.getMembersCount(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.MemberService#deleteMemberDetail(java.lang
	 * .String)
	 */
	@Override
	public void deleteMemberDetail(String id) {
		memberDetailMapper.deleteMemberDetail(id);
	}

}
