package cn.bluemobi.admin.service;

public interface TestService {
	java.util.Collection<?> query();
}