package cn.bluemobi.admin.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.google.code.kaptcha.Constants;

public class ValidCodeAuthenticationFilter extends
		UsernamePasswordAuthenticationFilter {
	
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException {
		String username = obtainUsername(request);
		String password = obtainPassword(request);
		String validcode = request.getParameter("validcode");
		if(username==null||username.trim().equals("")||username.equals("输入账号")){
			throw new AuthenticationServiceException("帐号不能为空");
		}
		if(password==null||password.equals("")){
			throw new AuthenticationServiceException("密码不能为空");
		}
		if(validcode==null||validcode.trim().equals("")||validcode.equals("输入验证码")){
			throw new AuthenticationServiceException("验证码不能为空");
		}
		
		Object kaptchaCode = request.getSession().getAttribute(Constants.KAPTCHA_SESSION_KEY);
		if(kaptchaCode==null){
			throw new AuthenticationServiceException("验证码超时");
		}
		
		if(!validcode.equalsIgnoreCase(kaptchaCode.toString())){
			throw new AuthenticationServiceException("验证码错误");
		}
		return super.attemptAuthentication(request, response);
	}

}
