package cn.bluemobi.admin.controller;

import static cn.bluemobi.admin.constant.AdminConstant.RETURN_STATUS_FAIL;
import static cn.bluemobi.admin.constant.AdminConstant.RETURN_STATUS_SUCCESS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bluemobi.admin.model.SysUser;
import cn.bluemobi.admin.service.SysUserService;
import cn.bluemobi.admin.util.PageUtil;

import com.alibaba.fastjson.JSON;

/***
 * 后台用户管理controller
 * 
 * @author hug
 *
 */
@Controller
@RequestMapping("/admin/sysUser")
public class SysUserController {

	@Autowired
	private SysUserService sysUserService;  // 用户管理service

	/**
	 * 用户管理主页面
	 * 
	 * @return
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String userList() {

		return "sysUser/userList";

	}

	/**
	 * 查询用户信息列表
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param userName
	 * @param realName
	 * @return
	 */
	@RequestMapping(value = "/getUserList", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getUserList(@RequestParam("page") int pageNo, @RequestParam("rows") int pageSize,
					String userName, String realName) {
		Map<String, Object> resMap = new HashMap<String, Object>();
		Map<String, Object> paramap = PageUtil.getQueryMapForPage(pageNo, pageSize);
		if (null != userName && !"".equals(userName)) {

			paramap.put("userName", userName);

		}
		if (null != realName && !"".equals(realName)) {

			paramap.put("realName", realName);

		}
		List<SysUser> userList = sysUserService.getSysUsersByPage(paramap);
		long totalCount = sysUserService.getSysUsersCount(paramap);
		if (userList == null) {
			resMap.put("total", 0);
			resMap.put("rows", new ArrayList<SysUser>());
		} else {
			resMap.put("total", totalCount);
			resMap.put("rows", userList);
		}
		String res = JSON.toJSONString(resMap);

		return res;
	}

	/**
	 * 新增用户信息
	 * 
	 * @return
	 */
	@RequestMapping(value = "/addUser", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String addUser(SysUser sysUser) {
		Map<String, Object> resMap = new HashMap<String, Object>();
		try {

			sysUserService.insertSysUser(sysUser);
			resMap.put("status", RETURN_STATUS_SUCCESS);

		} catch (Exception e) {
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resMap);
	}

	/**
	 * 修改用户信息
	 * 
	 * @return
	 */
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String updateUser(SysUser sysUser) {
		Map<String, Object> resMap = new HashMap<String, Object>();
		try {

			sysUserService.updateSysUser(sysUser);
			resMap.put("status", RETURN_STATUS_SUCCESS);

		} catch (Exception e) {
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resMap);
	}

	/**
	 * 判断用户名是否已经存在
	 * 
	 * @param userName
	 * @return
	 */
	@RequestMapping(value = "/userExist", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String userExist(String userName) {

		SysUser sysUser = sysUserService.getSysUserByName(userName);
		Map<String, Object> resMap = new HashMap<String, Object>();
		if (sysUser != null && sysUser.getUserId() != null) {
			resMap.put("resbool", false);
		} else {
			resMap.put("resbool", true);
		}
		return JSON.toJSONString(resMap);
	}

	/**
	 * 删除用户信息
	 * 
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/deleteUser", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String deleteUser(String userId) {

		Map<String, Object> resMap = new HashMap<String, Object>();
		try {

			sysUserService.deleteSysUser(userId);
			resMap.put("status", RETURN_STATUS_SUCCESS);

		} catch (Exception e) {
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
		}

		return JSON.toJSONString(resMap);

	}

	/**
	 * 修改当前用户密码
	 * 
	 * @param oldPwd
	 * @param newPwd
	 * @return
	 */
	@RequestMapping(value = "/changePwd", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String changePwd(String oldPwd, String newPwd) {

		Map<String, Object> resMap = new HashMap<String, Object>();
		try {

			Object user = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (user == null) {
				resMap.put("status", RETURN_STATUS_FAIL);
				resMap.put("error", "会话失效，请重新登录！");
			} else {
				String userName = ((UserDetails) user).getUsername();
				if (sysUserService.equalsUserNameAndPassword(userName, oldPwd)) {

					SysUser sysUser = new SysUser();
					sysUser.setUserName(userName);
					sysUser.setPassword(newPwd);
					sysUserService.updateSysUserByUserName(sysUser);
					resMap.put("status", RETURN_STATUS_SUCCESS);

				} else {

					resMap.put("status", RETURN_STATUS_FAIL);
					resMap.put("error", "原密码错误！");

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
		}

		return JSON.toJSONString(resMap);
	}


}
