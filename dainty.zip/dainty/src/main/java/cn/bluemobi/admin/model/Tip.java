/**
 * 
 */

package cn.bluemobi.admin.model;

import java.util.Date;

/**
 * 
 * @ClassName: Tip
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月16日 下午5:30:49
 *
 */
public class Tip {
	private String id;

	private String tipName;

	private Short sort;

	private String areaId;

	private String creator;

	private Date createTime;

	private String lastModUser;

	private Date lastModTime;

	private String tipContent;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id == null ? null : id.trim();
	}

	public String getTipName() {
		return tipName;
	}

	public void setTipName(String tipName) {
		this.tipName = tipName == null ? null : tipName.trim();
	}

	public Short getSort() {
		return sort;
	}

	public void setSort(Short sort) {
		this.sort = sort;
	}

	public String getAreaId() {
		return areaId;
	}

	public void setAreaId(String areaId) {
		this.areaId = areaId == null ? null : areaId.trim();
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator == null ? null : creator.trim();
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastModUser() {
		return lastModUser;
	}

	public void setLastModUser(String lastModUser) {
		this.lastModUser = lastModUser == null ? null : lastModUser.trim();
	}

	public Date getLastModTime() {
		return lastModTime;
	}

	public void setLastModTime(Date lastModTime) {
		this.lastModTime = lastModTime;
	}

	public String getTipContent() {
		return tipContent;
	}

	public void setTipContent(String tipContent) {
		this.tipContent = tipContent == null ? null : tipContent.trim();
	}
}