/**    
 * @Title: AreaMapper.java  
 * @Package: cn.bluemobi.admin.dao.mybatis  
 * @Description: 区域Mapper类
 * @Author: huh
 * @Date: 2015年11月17日 下午5:13:13  
 * @Version V1.0    
 */

package cn.bluemobi.admin.dao.mybatis;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.Area;

/**
 * @ClassName: AreaMapper
 * @Description: 区域Mapper
 * @author huh
 * @date 2015年11月17日 下午5:13:13
 * 
 */
public interface AreaMapper {

	/**
	 * 
	 * @Description: 新增区域
	 * @param area
	 * @throws
	 */
	public void insertArea(Area area);

	/**
	 * 
	 * @Description:获取区域列表+分页
	 * @param paramap
	 * @return
	 * @throws
	 */
	public List<Area> getAreasForPage(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取区域总记录数
	 * @param paramap
	 * @return
	 * @throws
	 */
	public long getAreasCount(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 删除区域
	 * @param id
	 * @throws
	 */
	public void deleteArea(String id);

	/**
	 * 
	 * @Description: 获取当前最大排序号
	 * @return
	 * @throws
	 */
	public Integer getMaxSort();

}
