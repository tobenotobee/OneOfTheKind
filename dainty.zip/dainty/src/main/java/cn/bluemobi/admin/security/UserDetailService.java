package cn.bluemobi.admin.security;

import static cn.bluemobi.admin.constant.AdminConstant.*;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.model.SysUser;
import cn.bluemobi.admin.service.SysUserService;

/***
 * 认证用户信息service
 * @author hug
 *
 */
@Service("sysUserDetailService")
public class UserDetailService implements UserDetailsService {

	//日志记录
	private static final Logger log = Logger.getLogger(UserDetailService.class);
	
	@Autowired
	private SysUserService sysUserService;  //用户管理service
	
	@Override
	public UserDetails loadUserByUsername(String userName)
			throws UsernameNotFoundException {
		
		if(log.isDebugEnabled()){
			log.debug("【spring-security】UserDetailService loadUserByUsername start ");
		}
		Collection<GrantedAuthority> grantedAuths = new ArrayList<GrantedAuthority>();
		SysUser sysUser = sysUserService.getSysUserByName(userName);
		if(sysUser==null||sysUser.getUserId()==null){
			
			String message = "用户<"+userName+">不存在！";
			throw new UsernameNotFoundException(message);

		}
		SimpleGrantedAuthority grantedAuthority = 
				new SimpleGrantedAuthority(sysUser.getRoleCode());
		grantedAuths.add(grantedAuthority);
		boolean enable = true;  
        boolean accountNonExpired = true;  
        boolean credentialsNonExpired = true;  
        boolean accountNonLocked = true;
        if(sysUser.getStatus()==SYS_USER_ENABLE_NO){
        	enable = false;
        }
        User userdetail = new User(sysUser.getUserName(),sysUser.getPassword(),enable,
        		accountNonExpired,credentialsNonExpired,accountNonLocked,grantedAuths);
        
        if(log.isDebugEnabled()){
			log.debug("【spring-security】UserDetailService loadUserByUsername end ");
		}
		return userdetail;
	}

}
