/**    
 * @Title: AgreementService.java  
 * @Package: cn.bluemobi.admin.service  
 * @Description: 用户协议service接口类
 * @Author: huh
 * @Date: 2015年10月20日 下午2:47:09  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.Agreement;

/**
 * @ClassName: AgreementService
 * @Description: 用户协议service接口
 * @author huh
 * @date 2015年10月20日 下午2:47:09
 * 
 */
public interface AgreementService {

	/**
	 * 
	 * @Description: 获取用户协议列表
	 * @param @param paramap
	 * @param @return
	 * @return
	 * @throws
	 */
	public List<Agreement> getAgreementsForPage(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 修改用户协议内容
	 * @param @param agreement
	 * @return
	 * @throws
	 */
	public void updateAgreement(Agreement agreement);

	/**
	 * 
	 * @Description: 新增用户协议
	 * @param @param agreement
	 * @return
	 * @throws
	 */
	public void addAgreement(Agreement agreement);

	/**
	 * 
	 * @Description: 删除用户协议
	 * @param @param id
	 * @return
	 * @throws
	 */
	public void deleteAgreement(String id);

	/**
	 * 
	 * @Description: 获取用户协议数量
	 * @param @param paramap
	 * @return
	 * @throws
	 */
	public long getAgreementsCount(Map<String, Object> paramap);
	
	
	/**
	 * 
	* @Description: 获取用户协议
	* @param paramap
	* @return       
	* @throws
	 */
	public Agreement getAgreement(Map<String, Object> paramap);
	

}
