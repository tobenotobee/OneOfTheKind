/**    
 * @Title: Comment.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: 评价类
 * @Author: huh
 * @Date: 2015年10月20日 下午4:24:34  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

/**
 * @ClassName: Comment
 * @Description: 评价
 * @author huh
 * @date 2015年10月20日 下午4:24:34
 * 
 */
public class Comment {

}
