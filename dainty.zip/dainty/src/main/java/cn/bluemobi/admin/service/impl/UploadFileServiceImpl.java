/**    
 * @Title: UploadFileServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl
 * @Description: 文件上传service接口实现类
 * @Author: huh
 * @Date: 2015年10月9日 下午4:07:16  
 * @Version V1.0    
 */
package cn.bluemobi.admin.service.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Positions;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import cn.bluemobi.admin.service.UploadFileService;

/**
 * 
 * @ClassName: UploadFileServiceImpl
 * @Description: 文件上传service接口实现
 * @author huh
 * @date 2015年10月9日 下午4:28:36
 *
 */
public class UploadFileServiceImpl implements UploadFileService {

	private String fileSavePath; // 文件保存路径

	private String fileHttpPath; // 文件http访问路径

	public String getFileSavePath() {
		return fileSavePath;
	}

	public void setFileSavePath(String fileSavePath) {
		this.fileSavePath = fileSavePath;
	}

	public String getFileHttpPath() {
		return fileHttpPath;
	}

	public void setFileHttpPath(String fileHttpPath) {
		this.fileHttpPath = fileHttpPath;
	}

	@Override
	public void uploadFile(byte[] file, String filePath, String fileName) throws Exception {

		String fullPath = fileSavePath;
		if (!StringUtils.isEmpty(filePath)) {
			fullPath = fullPath + filePath;
		}
		// fullPath = fullPath + fileName;

		File createFile = new File(fullPath);
		if (!createFile.exists()) {
			createFile.mkdirs();
		}
		File saveFile = new File(fullPath + fileName);
		FileCopyUtils.copy(file, saveFile);

	}

	@Override
	public void uploadFile(File file, String filePath, String fileName) throws Exception {
		String fullPath = fileSavePath;
		if (!StringUtils.isEmpty(filePath)) {
			fullPath = fullPath + filePath;
		}
		// fullPath = fullPath + fileName;

		File createFile = new File(fullPath);
		if (!createFile.exists()) {
			createFile.mkdirs();
		}

		File saveFile = new File(fullPath + fileName);
		FileCopyUtils.copy(file, saveFile);

	}

	@Override
	public void deleteUploadFile(String[] filePaths) {

		if (filePaths != null) {

			for (String filePath : filePaths) {

				File file = new File(fileSavePath + filePath);
				file.delete();

				// 删除带下划线的原图
				String filePath_ = filePath.substring(0, filePath.lastIndexOf('.')) + "_"
								+ filePath.substring(filePath.lastIndexOf('.'));
				File file_ = new File(fileSavePath + filePath_);
				if (file_.exists()) {
					file_.delete();
				}
			}
		}

	}

	@Override
	public void deleteUploadFile(List<String> filePaths) {

		if (filePaths != null) {

			for (String filePath : filePaths) {
				// 删除缩略图
				File file = new File(fileSavePath + filePath);
				if (file.exists()) {
					file.delete();
				}

				// 删除带下划线的原图
				String filePath_ = filePath.substring(0, filePath.lastIndexOf('.')) + "_"
								+ filePath.substring(filePath.lastIndexOf('.'));
				File file_ = new File(fileSavePath + filePath_);
				if (file_.exists()) {
					file_.delete();
				}
			}
		}

	}

	@Override
	public void uploadFile(InputStream fileInputStream, byte[] file, String filePath, String fileName, int fileCount)
					throws Exception {
		String fullPath = fileSavePath;
		if (!StringUtils.isEmpty(filePath)) {
			fullPath = fullPath + filePath;
		}

		File createFile = new File(fullPath);
		if (!createFile.exists()) {
			createFile.mkdirs();
		}

		// 真图
		File saveFile = new File(fullPath + fileName);
		if (saveFile.exists() == false) {
			saveFile.createNewFile();
		}
		FileCopyUtils.copy(file, saveFile);

		// 缩略图
		String smallPicName = fileName.substring(0, fileName.lastIndexOf('.')) + "_"
						+ fileName.substring(fileName.lastIndexOf('.'));
		try {
			/*
			 * BufferedImage bImage =
			 * Thumbnails.of(saveFile).scale(1F).asBufferedImage();
			 * 
			 * int width = bImage.getWidth();//上传图片的宽度 int height =
			 * bImage.getHeight();//上传图片的高度
			 * 
			 * //如果是多张图，我裁剪成正方形 if(fileCount > 0) { //裁图规则 如果是大图
			 * if(width > 800 && height > 800) {
			 * Thumbnails.of(saveFile
			 * ).sourceRegion(Positions.CENTER, 800,800).size(240,
			 * 240
			 * ).keepAspectRatio(false).toFile(fullPath+smallPicName
			 * ); } else { Thumbnails.of(saveFile).size(240,
			 * 240).toFile(fullPath+smallPicName); } } else {
			 * Thumbnails.of(saveFile).size(240,
			 * 240).toFile(fullPath+smallPicName); }
			 */

			Thumbnails.of(fileInputStream).size(1242, 2208).toFile(fullPath + smallPicName);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {

		try {
			Thumbnails.of("d:\\x.jpg").sourceRegion(Positions.CENTER, 600, 600).size(240, 240)
							.keepAspectRatio(false).toFile("d:\\xx.jpg");
			Thumbnails.of("d:\\x.jpg").size(240, 240).toFile("d:\\xxx.jpg");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
