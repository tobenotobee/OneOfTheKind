/**    
 * @Title: SysBaseCode.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: 数据字典编码类
 * @Author: huh
 * @Date: 2015年10月16日 上午11:13:13  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

/**
 * @ClassName: SysBaseCode
 * @Description: 数据字典编码
 * @author huh
 * @date 2015年10月16日 上午11:13:13
 * 
 */
public class SysBaseCode {
	private Integer id;
	private String code;
	private String codeName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCodeName() {
		return codeName;
	}

	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}

}
