/**    
 * @Title: CityServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description: 城市service接口实现类
 * @Author: huh
 * @Date: 2015年11月17日 下午5:32:45  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.CityMapper;
import cn.bluemobi.admin.model.City;
import cn.bluemobi.admin.service.CityService;

/**
 * @ClassName: CityServiceImpl
 * @Description: 城市service接口实现
 * @author huh
 * @date 2015年11月17日 下午5:32:45
 * 
 */
@Service("cityService")
public class CityServiceImpl implements CityService {

	@Autowired
	private CityMapper cityMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.CityService#getProvinceList()
	 */
	@Override
	public List<City> getProvinceList() {
		return cityMapper.getProvinceList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.CityService#getCityListByProvince(java.
	 * lang.String)
	 */
	@Override
	public List<City> getCityListByProvince(String provinceId) {
		return cityMapper.getCityListByProvince(provinceId);
	}

}
