package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.SysRole;

/***
 * 角色信息管理服务接口
 * @author hug
 *
 */
public interface SysRoleService {

	/**
	 * 新增用户角色
	 * @param sysRole
	 * @return
	 */
	public void insertSysRole(SysRole sysRole);
	
	/**
	 * 修改用户角色
	 * @param sysRole
	 * @return
	 */
	public void updateSysRole(SysRole sysRole);
	
	/**
	 * 根据角色ID获得角色信息
	 * @param roleId
	 * @return
	 */
	public SysRole getSysRole(long roleId);
	
	/**
	 * 根据角色ID删除角色信息
	 * @param roleId
	 * @return
	 */
	public void deleteSysRole(long roleId);
	
	/**
	 * 分页查询角色信息
	 * @param paramap
	 * @return
	 */
	public List<SysRole> getSysRoleForPage(Map<String,Object> paramap);
	
	/**
	 * 分页查询角色信息记录数统计
	 * @param paramap
	 * @return
	 */
	public long getSysRoleCount(Map<String,Object> paramap);
	
	/**
	 * 设置角色权限
	 * @param roleId
	 * @param checkIds
	 * @param indeIds
	 */
	public void setRoleAuth(long roleId,String checkIds,String indeIds);
	
	/**
	 * 得到所有角色信息
	 * @return
	 */
	public List<SysRole> getAllRole();
	
}
