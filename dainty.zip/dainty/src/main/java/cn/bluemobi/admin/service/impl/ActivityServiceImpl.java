/**    
 * @Title: ActivityServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月16日 下午5:36:40  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.ActivityMapper;
import cn.bluemobi.admin.model.Activity;
import cn.bluemobi.admin.service.ActivityService;

/**
 * @ClassName: ActivityServiceImpl
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月16日 下午5:36:40
 * 
 */
@Service("activityService")
public class ActivityServiceImpl implements ActivityService {

	@Autowired
	private ActivityMapper activityMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.ActivityService#getActivitysForPage(java
	 * .util.Map)
	 */
	@Override
	public List<Activity> getActivitysForPage(Map<String, Object> paramap) {
		return activityMapper.getActivitysForPage(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.ActivityService#getActivitysCount(java.
	 * util.Map)
	 */
	@Override
	public long getActivitysCount(Map<String, Object> paramap) {
		return activityMapper.getActivitysCount(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.ActivityService#updateActivity(cn.bluemobi
	 * .admin.model.Activity)
	 */
	@Override
	public void updateActivity(Activity activity) {
		activityMapper.updateActivity(activity);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.ActivityService#getActivityForCombobox()
	 */
	@Override
	public List<Map<String, String>> getActivityForCombobox() {
		return activityMapper.getActivityForCombobox();
	}

}
