package cn.bluemobi.admin.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import cn.bluemobi.admin.service.TestService;
import cn.bluemobi.admin.util.CalendarUtil;


@Controller
@RequestMapping("/admin/auth")
public class LoginController {
	
	@Autowired
	private TestService test;  
	
	//角色管理service	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String login(){
		System.out.println(test.query());
		return "login";
	}
	
	@RequestMapping(value="/main",method=RequestMethod.GET)
	public ModelAndView showMain(){
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("main");
		Date date = new Date();
		
		mav.addObject("sysTime",CalendarUtil.formatDate(date,"yyyy年MM月dd日") );
		mav.addObject("sysWeek", CalendarUtil.getWeekString(date));
		return mav;
		
	}

}
