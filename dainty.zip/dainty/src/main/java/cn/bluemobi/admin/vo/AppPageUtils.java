package cn.bluemobi.admin.vo;

public class AppPageUtils {
	
	/**
	 * 给分页 的JSON返回Page对象
	 * 
     *   "page": {
	        "pageCount": 1,
	        "pageNo": 1,
	        "pageSize": 10
	        }
	 * @param pageNo 当前页 1++
	 * @param pageSize 每页显示条数
	 * @param rowsCount  数据库数据总条数
	 * @return
	 */
	public static Page getPage(Integer pageNo,Integer pageSize,Integer rowsCount) {
		Integer pageCount = getPageCount(pageSize, rowsCount);
		Page page = new Page();
		page.setPageNo(pageNo);
		page.setPageSize(pageSize);
		page.setPageCount(pageCount);
		return page;
	}
	
	private static Integer getPageCount(Integer pageSize,Integer rowsCount) {
		Integer pageCount = null;
		if(rowsCount == null || rowsCount == 0) {
			pageCount = 1;
		} else {
			pageCount = rowsCount/pageSize;
			if(rowsCount%pageSize != 0) {
				pageCount = pageCount+1;
			}
		}
		return pageCount;
	}
}
