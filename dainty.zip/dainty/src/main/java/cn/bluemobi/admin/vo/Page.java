package cn.bluemobi.admin.vo;


/***
 * 分页数据
 * @author hug
 *
 */
public class Page {

	private Integer pageSize = null; //每页显示的记录数
	
	private Integer pageNo = null;  //当前页码
	
	private Integer pageCount = null; //总的页数

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageCount() {
		return pageCount;
	}

	public void setPageCount(Integer pageCount) {
		this.pageCount = pageCount;
	}

}
