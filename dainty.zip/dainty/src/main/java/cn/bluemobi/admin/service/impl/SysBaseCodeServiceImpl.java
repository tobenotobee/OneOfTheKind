/**    
 * @Title: SysBaseCodeServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description: 数据字典编码service接口实现类
 * @Author: huh
 * @Date: 2015年10月16日 上午11:18:50  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.SysBaseCodeMapper;
import cn.bluemobi.admin.model.SysBaseCode;
import cn.bluemobi.admin.service.SysBaseCodeService;

/**
 * @ClassName: SysBaseCodeServiceImpl
 * @Description:数据字典编码service接口实现
 * @author huh
 * @date 2015年10月16日 上午11:18:50
 * 
 */
@Service("sysBaseCodeService")
public class SysBaseCodeServiceImpl implements SysBaseCodeService {

	@Autowired
	private SysBaseCodeMapper sysBaseCodeMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.SysBaseCodeService#getAllBaseCode()
	 */
	@Override
	public List<SysBaseCode> getAllBaseCode() {
		return sysBaseCodeMapper.getAllBaseCode();
	}

}
