package cn.bluemobi.admin.dao;

import java.util.Map;

/**
 * 登录日志
 * @author songss
 *
 */
public interface LoginLogDao {
	/**
	 * 新增登录日志
	 * @param map
	 * @return
	 */
	int insertLoginLog(Map<String, Object> map);
}
