package cn.bluemobi.admin.service.impl;

import static cn.bluemobi.admin.constant.AdminConstant.TREE_CHECK_TYPE_CHECKED;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.SysRoleAuthMapper;
import cn.bluemobi.admin.model.SysRoleAuth;
import cn.bluemobi.admin.service.SysRoleAuthService;
import cn.bluemobi.admin.vo.SysTreeJson;

/***
 * 角色权限关系服务实现
 * @author hug
 *
 */
@Service
public class SysRoleAuthServiceImpl implements SysRoleAuthService {

	@Autowired
	private SysRoleAuthMapper sysRoleAuthMapper; //角色权限关系数据操作
	
	@Override
	public void insertSysRoleAuth(SysRoleAuth sysRoleAuth) {
		
		sysRoleAuthMapper.insertSysRoleAuth(sysRoleAuth);
	}

	@Override
	public void insertSysRoleAuthList(List<SysRoleAuth> sysRoleAuthList) {
		
		sysRoleAuthMapper.insertSysRoleAuthList(sysRoleAuthList);
	}

	@Override
	public void deleteByRoleId(long roleId) {
		
		sysRoleAuthMapper.deleteByRoleId(roleId);
	}

	@Override
	public List<SysRoleAuth> selectRoleAuth(long roleId,long authId) {
		Map<String,Object> paramap = new HashMap<String, Object>();
		paramap.put("roleId", roleId);
		paramap.put("authId", authId);
		return sysRoleAuthMapper.selectRoleAuth(paramap);
	}
	
	@Override
	public List<SysTreeJson> getAuthTreeJson(List<SysRoleAuth> roleAuthList,long roleId){
		
		List<SysTreeJson> treeList =  null;
		if(roleAuthList!=null){
			
			treeList = new ArrayList<SysTreeJson>();
			for (SysRoleAuth roleAuth : roleAuthList) {
				
				SysTreeJson treeJson = new SysTreeJson();
				treeJson.setId(roleAuth.getAuthId());
				treeJson.setText(roleAuth.getAuthName());
				if(roleAuth.getRoleId()!=null&&roleAuth.getRoleId()==roleId){
					if(roleAuth.getCheckType()==TREE_CHECK_TYPE_CHECKED){
						treeJson.setChecked(true);
					}
				}
				List<SysRoleAuth> childList = selectRoleAuth(roleId,roleAuth.getAuthId());
				if(childList!=null&&childList.size()>0){
					treeJson.setChildren(getAuthTreeJson(childList,roleId));
					treeJson.setState("closed");
				}
				
				treeList.add(treeJson);
				
			}
			
		}
		return treeList;
		
	}

}
