/**    
 * @Title: AgreementServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description: 用户协议service接口实现类
 * @Author: huh
 * @Date: 2015年10月20日 下午2:47:44  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.constant.AdminConstant;
import cn.bluemobi.admin.dao.mybatis.AgreementMapper;
import cn.bluemobi.admin.model.Agreement;
import cn.bluemobi.admin.service.AgreementService;
import cn.bluemobi.admin.util.TimeHelper;

/**
 * @ClassName: AgreementServiceImpl
 * @Description: 用户协议service接口实现
 * @author huh
 * @date 2015年10月20日 下午2:47:44
 * 
 */
@Service("agreementService")
public class AgreementServiceImpl implements AgreementService {

	@Autowired
	private AgreementMapper agreementMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.AgreementService#getAgreementsForPage(java
	 * .util.Map)
	 */
	@Override
	public List<Agreement> getAgreementsForPage(Map<String, Object> paramap) {
		return agreementMapper.getAgreementsForPage(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.AgreementService#updateAgreement(cn.bluemobi
	 * .admin.model.Agreement)
	 */
	@Override
	public void updateAgreement(Agreement agreement) {
		agreement.setLastUpdateTime(TimeHelper.getCurrentLocalTime());
		if (agreement.getIsUse() == AdminConstant.STATUS_ENABLE) {
			agreement.setLastUpdater(agreement.getLastUpdater());
			agreement.setLastUpdateTime(TimeHelper.getCurrentLocalTime());
			agreementMapper.updateAgreementState(agreement);
		}
		agreementMapper.updateAgreement(agreement);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.AgreementService#addAgreement(cn.bluemobi
	 * .admin.model.Agreement)
	 */
	@Override
	public void addAgreement(Agreement agreement) {
		agreement.setCreateTime(TimeHelper.getCurrentLocalTime());
		agreementMapper.addAgreement(agreement);
		if (agreement.getIsUse() == AdminConstant.STATUS_ENABLE) {
			agreement.setLastUpdater(agreement.getCreater());
			agreement.setLastUpdateTime(TimeHelper.getCurrentLocalTime());
			agreementMapper.updateAgreementState(agreement);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.AgreementService#deleteAgreement(java.lang
	 * .String)
	 */
	@Override
	public void deleteAgreement(String id) {
		agreementMapper.deleteAgreement(id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.AgreementService#getAgreementsCount(java
	 * .util.Map)
	 */
	@Override
	public long getAgreementsCount(Map<String, Object> paramap) {
		return agreementMapper.getAgreementsCount(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.AgreementService#getAgreement(java.util
	 * .Map)
	 */
	@Override
	public Agreement getAgreement(Map<String, Object> paramap) {
		return agreementMapper.getAgreement(paramap);
	}

}
