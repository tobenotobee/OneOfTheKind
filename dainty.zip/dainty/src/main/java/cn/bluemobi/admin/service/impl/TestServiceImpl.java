package cn.bluemobi.admin.service.impl;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.TestDao;
import cn.bluemobi.admin.service.TestService;

@Service
public class TestServiceImpl implements TestService{
	
	@Autowired
	private TestDao testDao;

	@Override
	public Collection<?> query() {
        return testDao.query();
	}

}
