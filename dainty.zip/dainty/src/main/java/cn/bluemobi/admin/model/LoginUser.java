/**    
 * @Title: LoginUser.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月17日 下午7:28:55  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

import java.util.Date;

import cn.bluemobi.admin.util.CalendarUtil;

/**
 * @ClassName: LoginUser
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月17日 下午7:28:55
 * 
 */
public class LoginUser {

	private String id;
	private String loginName;
	private String loginPwd;
	private Byte loginType;
	private String tpName;
	private Date registeredTime;
	private Date lastActiveTime;
	private String registeredTimeStr;
	private MemberDetail memberDetail;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getLoginPwd() {
		return loginPwd;
	}

	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}

	public Byte getLoginType() {
		return loginType;
	}

	public void setLoginType(Byte loginType) {
		this.loginType = loginType;
	}

	public String getTpName() {
		return tpName;
	}

	public void setTpName(String tpName) {
		this.tpName = tpName;
	}

	public Date getRegisteredTime() {
		return registeredTime;
	}

	public void setRegisteredTime(Date registeredTime) {
		this.registeredTime = registeredTime;
	}

	public Date getLastActiveTime() {
		return lastActiveTime;
	}

	public void setLastActiveTime(Date lastActiveTime) {
		this.lastActiveTime = lastActiveTime;
	}

	public String getRegisteredTimeStr() {
		if (registeredTime != null)
			return CalendarUtil.formatDate(registeredTime);
		else
			return registeredTimeStr;
	}

	public void setRegisteredTimeStr(String registeredTimeStr) {
		this.registeredTimeStr = registeredTimeStr;
	}

	public MemberDetail getMemberDetail() {
		return memberDetail;
	}

	public void setMemberDetail(MemberDetail memberDetail) {
		this.memberDetail = memberDetail;
	}

}
