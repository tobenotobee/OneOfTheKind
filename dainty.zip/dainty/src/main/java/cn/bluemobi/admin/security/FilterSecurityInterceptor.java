package cn.bluemobi.admin.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;
import org.springframework.security.access.SecurityMetadataSource;
import org.springframework.security.access.intercept.AbstractSecurityInterceptor;
import org.springframework.security.access.intercept.InterceptorStatusToken;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;

/***
 * 自定义认证授权过滤器
 * @author hug
 *
 */
public class FilterSecurityInterceptor extends AbstractSecurityInterceptor
		implements Filter {

	//日志
	private static final Logger log = Logger.getLogger(FilterSecurityInterceptor.class);
	
	private FilterInvocationSecurityMetadataSource securityMetadataSource;
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if(log.isDebugEnabled()){
			log.debug("【spring-security】FilterSecurityInterceptor doFilter start");
		}
		FilterInvocation fi = new FilterInvocation(request, response, chain);
		invoke(fi);
		if(log.isDebugEnabled()){
			log.debug("【spring-security】FilterSecurityInterceptor doFilter end");
		}

	}
	
	public void invoke(FilterInvocation fi) throws IOException, ServletException {  
        InterceptorStatusToken token = super.beforeInvocation(fi);  
        try {  
            fi.getChain().doFilter(fi.getRequest(), fi.getResponse());  
        } finally {  
            super.afterInvocation(token, null);  
        }  
    }
	
	@Override
	public Class<?> getSecureObjectClass() {
		return FilterInvocation.class;
	}

	@Override
	public SecurityMetadataSource obtainSecurityMetadataSource() {
		return securityMetadataSource;
	}
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}
	
	@Override
	public void destroy() {
	}

	public void setSecurityMetadataSource(
			FilterInvocationSecurityMetadataSource securityMetadataSource) {
		this.securityMetadataSource = securityMetadataSource;
	}
	
}
