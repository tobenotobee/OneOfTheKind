package cn.bluemobi.admin.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import cn.bluemobi.admin.model.SysAuth;
import cn.bluemobi.admin.model.SysRole;
import cn.bluemobi.admin.service.SysAuthService;
import cn.bluemobi.admin.service.SysRoleService;

/***
 * 权限访问决策的MetadataSource
 * @author hug
 *
 */
public class SecurityMetadataSourceService implements
		FilterInvocationSecurityMetadataSource {

	//日志
	private static final Logger log = Logger.getLogger(SecurityMetadataSourceService.class);
	
	private static Map<String, Collection<ConfigAttribute>> roleAuthMap = null; //角色权限关系MAP
	
	private final PathMatcher pathMatcher = new AntPathMatcher();
	
	private SysRoleService sysRoleService;  //角色管理service
	
	private SysAuthService sysAuthService; //权限管理service
	
	/**
	 * 初始化系统权限角色信息
	 */
	public void loadRoleAuthInfo(){
		
		if(log.isDebugEnabled()){
			log.debug("【spring-security】SecurityMetadataSourceService loadRoleAuthInfo start");
		}
		if(roleAuthMap==null){
			roleAuthMap = new HashMap<String, Collection<ConfigAttribute>>();
		}else{
			
			Iterator<Map.Entry<String, Collection<ConfigAttribute>>> iterator = 
					roleAuthMap.entrySet().iterator();
			while(iterator.hasNext()){
				Map.Entry<String, Collection<ConfigAttribute>> entry = iterator.next();
				if(entry!=null){
					iterator.remove();	
				}	
			}
		}
		
		List<SysRole> roleList = sysRoleService.getAllRole();
		for (SysRole sysRole : roleList) {
			
			 ConfigAttribute confAttr = new SecurityConfig(sysRole.getRoleCode());
			 
			 List<SysAuth> authList = sysAuthService.getAuthByRoleId(sysRole.getRoleId());
			 for (SysAuth sysAuth : authList) {
				
				 if (roleAuthMap.containsKey(sysAuth.getAuthResource())) {
					 Collection<ConfigAttribute> confAttrList = roleAuthMap.get(sysAuth.getAuthResource());
					 confAttrList.add(confAttr);
					 roleAuthMap.put(sysAuth.getAuthResource(), confAttrList);
					 
				 }else{
					 Collection<ConfigAttribute> confAttrList = new ArrayList<ConfigAttribute>();
					 confAttrList.add(confAttr);
					 roleAuthMap.put(sysAuth.getAuthResource(), confAttrList);
				 }
				 
				 
			 }
			 
		}
		if(log.isDebugEnabled()){
			log.debug("【spring-security】SecurityMetadataSourceService loadRoleAuthInfo end");
		}
		
	}
	
	@Override
	public Collection<ConfigAttribute> getAllConfigAttributes() {
		return null;
	}

	@Override
	public Collection<ConfigAttribute> getAttributes(Object object)
			throws IllegalArgumentException {
		if(log.isDebugEnabled()){
			log.debug("【spring-security】SecurityMetadataSourceService getAttributes start");
		}
		Collection<ConfigAttribute> returnCollection = null;
		String reqUrl = ((FilterInvocation) object).getRequestUrl();
		Set<String> keySet = roleAuthMap.keySet();
		for (String resUrl : keySet) {
			if(resUrl==null||"".equals(resUrl)){
				continue;
			}
			if(pathMatcher.match(resUrl, reqUrl)){				
				returnCollection = roleAuthMap.get(resUrl);
				if(log.isDebugEnabled()){
					log.debug("【spring-security】SecurityMetadataSourceService getAttributes resUrl: "+resUrl);
					log.debug("【spring-security】SecurityMetadataSourceService getAttributes end");
				}
				return returnCollection;
			}
		}
		if(log.isDebugEnabled()){
			log.debug("【spring-security】SecurityMetadataSourceService getAttributes end");
		}
		
		return null;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		return true;
	}

	public void setSysRoleService(SysRoleService sysRoleService) {
		this.sysRoleService = sysRoleService;
	}

	public void setSysAuthService(SysAuthService sysAuthService) {
		this.sysAuthService = sysAuthService;
	}
	
}
