package cn.bluemobi.admin.vo;

/***
 * 客户端数据封装VO
 * @author hug
 *
 */
public class AppData {

	public static final int RETURN_SUCCESS = 1;  //操作成功
	
	public static final int RETURN_FAIL = 0;  //操作失败
	
	public static final int RETURN_PROMPTS = 2;  //提示状态
	
	private Integer status = 0;  //返回标识 1 成功 0失败

	private Object msg;  //错误信息

	private Object data;  //返回数据
	
	private String url; //url

	private Page page;  //分页对象

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Object getMsg() {
		return msg;
	}

	public void setMsg(Object msg) {
		this.msg = msg;
	}

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
