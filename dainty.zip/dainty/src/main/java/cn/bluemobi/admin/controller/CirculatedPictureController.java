/**    
 * @Title: CirculatedPictureController.java  
 * @Package: cn.bluemobi.admin.controller  
 * @Description: 轮播图controller类
 * @Author: huh
 * @Date: 2015年10月14日 上午9:50:23  
 * @Version V1.0    
 */

package cn.bluemobi.admin.controller;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.fastjson.JSON;
import cn.bluemobi.admin.constant.AdminConstant;
import cn.bluemobi.admin.model.CirculatedPicture;
import cn.bluemobi.admin.model.ImageFile;
import cn.bluemobi.admin.model.SysUser;
import cn.bluemobi.admin.service.CirculatedPictureService;
import cn.bluemobi.admin.service.ImageFileService;
import cn.bluemobi.admin.service.UploadFileService;
import cn.bluemobi.admin.util.PageUtil;

/**
 * @ClassName: CirculatedPictureController
 * @Description: 轮播图controller
 * @author huh
 * @date 2015年10月14日 上午9:50:23
 * 
 */
@Controller
@RequestMapping(value = "/admin/circulatedPicture")
public class CirculatedPictureController {

	@Autowired
	private CirculatedPictureService circulatedPictureService; // 轮播图service

	@Autowired
	private ImageFileService imageFileService;  // 图片文件service

	@Autowired
	private UploadFileService uploadFileService;// 图片上传service

	@Autowired
	private HttpServletRequest request;   // HttpServletRequest

	/**
	 * 
	 * @Description: 跳转到轮播图首页
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/jump2list", method = RequestMethod.GET)
	public String list() {

		return "circulatedPicture/circulatedPictureList";
	}

	/**
	 * 
	 * @Description: 跳转到轮播图编辑
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/jump2edit", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	public String jump2edit(Map<String, Object> map, String cpId) {

		Map<String, Object> paramap = new HashMap<String, Object>();
		paramap.put("http", uploadFileService.getFileHttpPath());
		paramap.put("id", cpId);
		CirculatedPicture circulatedPicture = circulatedPictureService.getCirculatedPictureById(paramap);
		map.put("circulatedPicture", circulatedPicture);
		return "circulatedPicture/editCirculatedPicture";
	}

	/**
	 * 
	 * @Description: 跳转到新增轮播图
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/jump2add", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	public String addCirculatedPicture(Map<String, Object> map) {
		return "circulatedPicture/addCirculatedPicture";
	}

	/**
	 * 
	 * @Description: 获取轮播图列表
	 * @param @param pageNo
	 * @param @param pageSize
	 * @param @param imgName
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getCirculatedPictureList", method = RequestMethod.POST,
					produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getCirculatedPictureList(@RequestParam("page") int pageNo,
					@RequestParam("rows") int pageSize, String remark, String state) {
		// 组装页面查询条件参数
		Map<String, Object> paramap = PageUtil.getQueryMapForPage(pageNo, pageSize);
		Map<String, Object> resmap = new HashMap<String, Object>();
		if (remark != null && !"".equals(remark)) {
			paramap.put("remark", remark);
		}
		if (state != null && !"".equals(state)) {
			paramap.put("state", state);
		}
		paramap.put("http", uploadFileService.getFileHttpPath());
		List<CirculatedPicture> cpList = circulatedPictureService.getCirculatedPictureByNameForPage(paramap);
		long totalcnt = circulatedPictureService.getCirculatedPictureCount(paramap);
		resmap.put("total", totalcnt);
		resmap.put("rows", cpList);
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 轮播图详情
	 * @param @param picId
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getCirculatedPicture", method = RequestMethod.POST,
					produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getCirculatedPicture(String id) {
		Map<String, Object> paramap = new HashMap<String, Object>();
		paramap.put("id", id);
		CirculatedPicture circulatedPicture = circulatedPictureService.getCirculatedPictureById(paramap);
		if (circulatedPictureService == null) {
			return "{\"status\":" + AdminConstant.RETURN_STATUS_FAIL + ",\"error\":\"轮播图信息不存在\"}";
		}
		return JSON.toJSONString(circulatedPicture);
	}

	/**
	 * 
	 * @Description: 提交新增轮播图
	 * @param @param circulatedPicture
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/addCirculatedPicture", method = RequestMethod.POST,
					produces = "text/plain;charset=UTF-8")
	public @ResponseBody String addCirculatedPicture(CirculatedPicture circulatedPicture, String filePath,
					String fileName) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			// 从session中获取登录用户名称，用来查询用户信息
			SysUser sysUser = (SysUser) request.getSession().getAttribute("userBean");
			if (sysUser == null) {
				resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
				resmap.put("error", "操作用户不存在");
				return JSON.toJSONString(resmap);
			}
			circulatedPicture.setState(AdminConstant.STATUS_ENABLE);
			circulatedPicture.setCreator(sysUser.getUserId());

			// 图片相对保存目录--数据库保存使用
			String destPath = "upload" + File.separatorChar + AdminConstant.IMGFILE__CIRCULATED_PICTURE_DIR
							+ File.separatorChar;
			String destFileName = destPath + fileName;

			int res = saveImageFile(filePath, fileName, destPath);
			if (res == 1) {

				circulatedPictureService.insertCirculatedPicture(circulatedPicture);

				ImageFile imageFile = new ImageFile(circulatedPicture.getId(),
								AdminConstant.IMGTYPE__CIRCULATED_PICTURE,
								circulatedPicture.getTitle(), destFileName.replace(
												"\\", "/"), 1);
				imageFileService.addImageFile(imageFile);
				resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);
			} else {
				resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
				resmap.put("error", "轮播图保存失败");
			}
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 将临时图片保存到正式目录中
	 * @param request
	 * @param circulatedPicture
	 * @throws
	 */
	public int saveImageFile(String filePath, String fileName, String destPath) {
		try {
			String fileAbsPath = uploadFileService.getFileSavePath();
			if (filePath != null && !"".equals(filePath)) {
				String fullPath = fileAbsPath + filePath;
				File fileDir = new File(fullPath);
				if (!fileDir.exists()) {
					fileDir.mkdir();
				}
				// 缩略图
				String _fileName = fileName.substring(0, fileName.lastIndexOf(".")) + "_"
								+ fileName.substring(fileName.lastIndexOf("."));

				File file = new File(fullPath + fileName);
				File _file = new File(fullPath + _fileName);

				// 原图
				File destFile = new File(fileAbsPath + destPath);
				File _destFile = new File(fileAbsPath + destPath);
				if (file.exists() && _file.exists()) {
					FileUtils.copyFileToDirectory(file, destFile);
					file.delete();
					FileUtils.copyFileToDirectory(_file, _destFile);
					_file.delete();
				} else {
					return -1;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
		return 1;
	}

	/**
	 * 
	 * @Description: 删除轮播图
	 * @param @param picId
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/deleteCirculatedPicture", method = RequestMethod.POST,
					produces = "text/plain;charset=UTF-8")
	public @ResponseBody String deleteCirculatedPicture(String id) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			Map<String, Object> paramap = new HashMap<String, Object>();
			paramap.put("id", id);
			CirculatedPicture circulatedPicture = circulatedPictureService
							.getCirculatedPictureById(paramap);
			if (circulatedPicture == null) {
				resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
				resmap.put("error", "轮播图信息不存在");
			}
			// 删除数据库几率
			circulatedPictureService.deleteCirculatedPicture(id);

			paramap.put("refId", circulatedPicture.getId());
			paramap.put("imgType", AdminConstant.IMGTYPE__CIRCULATED_PICTURE);
			List<ImageFile> imgList = imageFileService.getImageFile(paramap);

			ImageFile oldImageFile = (imgList != null && imgList.size() > 0) ? imgList.get(0) : null;
			// 删除服务器的图片文件
			if (oldImageFile != null) {
				uploadFileService.deleteUploadFile(new String[] { oldImageFile.getImgUrl() });
				imageFileService.deleteImageFile(paramap);
			}

			resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 删除轮播图
	 * @param @param picId
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/setCirculatedPicture", method = RequestMethod.POST,
					produces = "text/plain;charset=UTF-8")
	public @ResponseBody String setCirculatedPicture(String id, Integer state, HttpServletRequest request) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			CirculatedPicture circulatedPicture = new CirculatedPicture();
			if (id == null || "".equals(id)) {
				resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
				resmap.put("error", "轮播图信息不存在");
			}
			if (state == null || "".equals(state)) {
				resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
				resmap.put("error", "轮播图信息不存在");
			}

			circulatedPicture.setId(id);
			// 从session中获取登录用户名称，用来查询用户信息
			SysUser sysUser = (SysUser) request.getSession().getAttribute("userBean");
			if (sysUser == null) {
				resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
				resmap.put("error", "操作用户不存在");
				return JSON.toJSONString(resmap);
			}
			circulatedPicture.setLastModUser(sysUser.getUserId());
			circulatedPicture.setState((state == AdminConstant.STATUS_ENABLE ? AdminConstant.STATUS_ENABLE - 1
							: AdminConstant.STATUS_ENABLE));
			circulatedPictureService.updateCirculatedPicture(circulatedPicture);
			resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}

	/**
	 *
	 * @Description: 修改轮播图信息
	 * @param @param circulatedPicture
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/updateCirculatedPicture", method = RequestMethod.POST,
					produces = "text/plain;charset=UTF-8")
	public @ResponseBody String updateCirculatedPicture(CirculatedPicture circulatedPicture, String filePath,
					String fileName, Integer isModified) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			// 从session中获取登录用户名称，用来查询用户信息
			SysUser sysUser = (SysUser) request.getSession().getAttribute("userBean");
			if (sysUser == null) {
				resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
				resmap.put("error", "操作用户不存在");
				return JSON.toJSONString(resmap);
			}
			circulatedPicture.setLastModUser(sysUser.getUserId());

			// 判断图片是否修改
			if (isModified != null && isModified == 1) {
				// 如果修改了图片
				// 重新上传新图片 ，删除就图片

				// 图片相对保存目录--数据库保存使用
				String destPath = "upload" + File.separatorChar
								+ AdminConstant.IMGFILE__CIRCULATED_PICTURE_DIR
								+ File.separatorChar;
				String destFileName = destPath + fileName;
				// 保存新图片
				int res = saveImageFile(filePath, fileName, destPath);
				if (res == 1) {
					Map<String, Object> paramap = new HashMap<String, Object>();
					paramap.put("refId", circulatedPicture.getId());
					paramap.put("imgType", AdminConstant.IMGTYPE__CIRCULATED_PICTURE);
					List<ImageFile> imgList = imageFileService.getImageFile(paramap);

					ImageFile oldImageFile = (imgList != null && imgList.size() > 0) ? imgList
									.get(0) : null;
					// 物理保存成功后，将记录插入数据库图片表中
					ImageFile imageFile = new ImageFile(circulatedPicture.getId(),
									AdminConstant.IMGTYPE__CIRCULATED_PICTURE,
									circulatedPicture.getTitle(),
									destFileName.replace("\\", "/"), 1);
					paramap.put("imgUrl", destFileName.replace("\\", "/"));
					imageFileService.updateImageFile(paramap);
					// 新图添加成功后，删除旧图
					if (oldImageFile != null) {
						uploadFileService.deleteUploadFile(new String[] { oldImageFile
										.getImgUrl() });
					}

				} else {
					resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
					resmap.put("error", "轮播图保存失败");
				}
			}

			circulatedPictureService.updateCirculatedPicture(circulatedPicture);
			resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);

		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 获取新增排序号
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getCirculatedPictureSort", method = RequestMethod.POST,
					produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getCirculatedPictureSort() {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			// 获取最新排序号
			int sort = circulatedPictureService.getNextSort();
			resmap.put("sort", sort);
			resmap.put("status", 1);
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 判断排序好是否已存在
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/existCirculatedPictureSort", method = RequestMethod.POST,
					produces = "text/plain;charset=UTF-8")
	public @ResponseBody String existCirculatedPictureSort(int sort) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			// 判断轮播图是否存在
			boolean e = circulatedPictureService.existCirculatedPictureBySort(sort);
			resmap.put("resbool", e);
			resmap.put("status", 1);
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}
}
