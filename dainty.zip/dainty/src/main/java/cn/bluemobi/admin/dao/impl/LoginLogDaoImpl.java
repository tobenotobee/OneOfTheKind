package cn.bluemobi.admin.dao.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.LoginLogDao;
import cn.bluemobi.admin.service.LoginLogService;

/**
 * 登录日志
 * @author songss
 *
 */
@Service
public class LoginLogDaoImpl implements LoginLogDao{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int insertLoginLog(Map<String, Object> map) {
		String sql = "INSERT INTO t_login_log(id,user_id,loginip,logintime) "
				+ "VALUES (f_getUUID(),?,?,?)";
		return jdbcTemplate.update(sql, new Object[]{
			map.get("user_id"),
			map.get("login_ip"),
			map.get("login_time")
		});
	}

}
