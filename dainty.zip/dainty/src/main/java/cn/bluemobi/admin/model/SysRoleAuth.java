package cn.bluemobi.admin.model;

import java.io.Serializable;

/***
 * 角色权限关系
 * @author hug
 *
 */
public class SysRoleAuth implements Serializable{

	private Long authId; //权限ID
	private Long roleId; //角色ID
	private Integer checkType; //选中类型 0 半选  1 选中
	private String authName; //权限名称

	public Long getAuthId() {
		return authId;
	}

	public void setAuthId(Long authId) {
		this.authId = authId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public Integer getCheckType() {
		return checkType;
	}

	public void setCheckType(Integer checkType) {
		this.checkType = checkType;
	}

	public String getAuthName() {
		return authName;
	}

	public void setAuthName(String authName) {
		this.authName = authName;
	}

}