/**    
 * @Title: AgreementMapper.java  
 * @Package: cn.bluemobi.admin.dao.mybatis  
 * @Description: 用户协议数据库操作mapper类
 * @Author: huh
 * @Date: 2015年10月20日 上午9:45:50  
 * @Version V1.0    
 */

package cn.bluemobi.admin.dao.mybatis;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.Agreement;

/**
 * @ClassName: AgreementMapper
 * @Description: 用户协议数据库操作mapper
 * @author huh
 * @date 2015年10月20日 上午9:45:50
 * 
 */
public interface AgreementMapper {

	/**
	 * 
	 * @Description: 获取用户协议列表
	 * @param @param paramap
	 * @param @return
	 * @return
	 * @throws
	 */
	public List<Agreement> getAgreementsForPage(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 修改用户协议内容
	 * @param @param agreement
	 * @return
	 * @throws
	 */
	public void updateAgreement(Agreement agreement);

	/**
	 * 
	 * @Description: 新增用户协议
	 * @param @param agreement
	 * @return
	 * @throws
	 */
	public void addAgreement(Agreement agreement);

	/**
	 * 
	 * @Description: 删除用户协议
	 * @param @param id
	 * @return
	 * @throws
	 */
	public void deleteAgreement(String id);
	

	/**
	 * 
	 * @Description: 获取用户协议数量
	 * @param @param paramap
	 * @return
	 * @throws
	 */
	public long getAgreementsCount(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取用户协议
	 * @param paramap
	 * @return
	 * @throws
	 */
	public Agreement getAgreement(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 启用一个协议时，禁用其他协议
	 * @param version
	 * @throws
	 */
	public void updateAgreementState(Agreement agreement);

	/************************** APP *****************************/

}
