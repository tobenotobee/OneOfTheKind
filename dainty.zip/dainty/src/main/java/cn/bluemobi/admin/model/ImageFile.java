/**    
 * @Title: ImageFile.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月16日 上午11:38:02  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

import java.util.Date;

/**
 * @ClassName: ImageFile
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月16日 上午11:38:02
 * 
 */
public class ImageFile {

	private String refId;
	private String imgType;
	private String imgName;
	private String imgUrl;
	private String imgHttpUrl;
	private Integer imgSort;
	private Date createTime;

	public ImageFile() {
	}

	/**
	 * @Description: TODO desc
	 * @param @param refId
	 * @param @param imgType
	 * @param @param imgName
	 * @param @param imgUrl
	 * @param @param imgSort
	 * @return
	 * @throws
	 */
	public ImageFile(String refId, String imgType, String imgName, String imgUrl, Integer imgSort) {
		super();
		this.refId = refId;
		this.imgType = imgType;
		this.imgName = imgName;
		this.imgUrl = imgUrl;
		this.imgSort = imgSort;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getImgType() {
		return imgType;
	}

	public void setImgType(String imgType) {
		this.imgType = imgType;
	}

	public String getImgName() {
		return imgName;
	}

	public void setImgName(String imgName) {
		this.imgName = imgName;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getImgHttpUrl() {
		return imgHttpUrl;
	}

	public void setImgHttpUrl(String imgHttpUrl) {
		this.imgHttpUrl = imgHttpUrl;
	}

	public Integer getImgSort() {
		return imgSort;
	}

	public void setImgSort(Integer imgSort) {
		this.imgSort = imgSort;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

}
