package cn.bluemobi.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.LoginLogDao;
import cn.bluemobi.admin.dao.mybatis.LoginLogMapper;
import cn.bluemobi.admin.model.LoginLog;
import cn.bluemobi.admin.service.LoginLogService;

@Service
public class LoginLogServiceImpl implements LoginLogService {

	@Autowired
	private LoginLogDao loginLogDao;

	@Autowired
	private LoginLogMapper loginLogMapper;

	@Override
	public int insertLoginLog(Map<String, Object> map) {
		return loginLogDao.insertLoginLog(map);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.LoginLogService#getLoginLogForPage(java
	 * .util.Map)
	 */
	@Override
	public List<LoginLog> getLoginLogForPage(Map<String, Object> paramap) {
		return loginLogMapper.getLoginLogForPage(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.LoginLogService#getLoginLogCount(java.util
	 * .Map)
	 */
	@Override
	public long getLoginLogCount(Map<String, Object> paramap) {
		return loginLogMapper.getLoginLogCount(paramap);
	}

}
