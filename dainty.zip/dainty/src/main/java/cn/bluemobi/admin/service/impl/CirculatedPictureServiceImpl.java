/**    
 * @Title: CirculatedPictureServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description: 轮播图service接口实现类
 * @Author: huh
 * @Date: 2015年10月14日 上午9:46:29  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.CirculatedPictureMapper;
import cn.bluemobi.admin.model.CirculatedPicture;
import cn.bluemobi.admin.service.CirculatedPictureService;
import cn.bluemobi.admin.util.TimeHelper;

/**
 * @ClassName: CirculatedPictureServiceImpl
 * @Description: 轮播图service接口实现
 * @author huh
 * @date 2015年10月14日 上午9:46:29
 * 
 */
@Service
public class CirculatedPictureServiceImpl implements CirculatedPictureService {

	@Autowired
	private CirculatedPictureMapper circulatedPictureMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.CirculatedPictureService#
	 * insertCirculatedPicture(cn.bluemobi.admin.model.CirculatedPicture)
	 */
	@Override
	public void insertCirculatedPicture(CirculatedPicture circulatedPicture) {
		circulatedPictureMapper.insertCirculatedPicture(circulatedPicture);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.CirculatedPictureService#
	 * deleteCirculatedPicture(java.lang.String)
	 */
	@Override
	public void deleteCirculatedPicture(String id) {
		circulatedPictureMapper.deleteCirculatedPicture(id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.CirculatedPictureService#
	 * updateCirculatedPicture(cn.bluemobi.admin.model.CirculatedPicture)
	 */
	@Override
	public void updateCirculatedPicture(CirculatedPicture circulatedPicture) {
		circulatedPictureMapper.updateCirculatedPicture(circulatedPicture);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.CirculatedPictureService#
	 * getCirculatedPictureById(java.lang.String)
	 */
	@Override
	public CirculatedPicture getCirculatedPictureById(Map<String, Object> paramap) {
		return circulatedPictureMapper.getCirculatedPictureById(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.CirculatedPictureService#
	 * getCirculatedPictureByNameForPage(java.util.Map)
	 */
	@Override
	public List<CirculatedPicture> getCirculatedPictureByNameForPage(Map<String, Object> paramap) {
		return circulatedPictureMapper.getCirculatedPictureByNameForPage(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.CirculatedPictureService#
	 * getCirculatedPictureCount(java.util.Map)
	 */
	@Override
	public long getCirculatedPictureCount(Map<String, Object> paramap) {
		return circulatedPictureMapper.getCirculatedPictureCount(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.CirculatedPictureService#getNextSort()
	 */
	@Override
	public int getNextSort() {
		Integer sort = circulatedPictureMapper.getMaxSort();
		return (sort == null ? 0 : sort) + 1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.CirculatedPictureService#
	 * existCirculatedPictureBySort(int)
	 */
	@Override
	public boolean existCirculatedPictureBySort(int sort) {
		// 判断排序号是否存在，存在返回false，反之true
		return circulatedPictureMapper.getCirculatedPictureBySort(sort) > 0 ? false : true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.CirculatedPictureService#
	 * getCirculatedPictureList(java.util.Map)
	 */
	@Override
	public List<Map> getCirculatedPictureList(Map<String, Object> paramap) {
		return circulatedPictureMapper.getCirculatedPictureList(paramap);
	}

}
