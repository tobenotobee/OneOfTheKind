/**
 * 
 */
package cn.bluemobi.admin.model;

import java.util.Date;

/**
 * 
* @ClassName: Activity  
* @Description: TODO desc
* @author huh
* @date 2015年11月16日 下午5:30:36  
*
 */
public class Activity {
	private String id;

	private String actName;

	private String actCode;

	private String duration;

	private String enthusiastId;

	private String areaId;

	private String location;

	private Short maxJoined;

	private String characteristic1;

	private String characteristic2;

	private String characteristic3;

	private Short sort;

	private Byte state;

	private String intro;

	private String itineraryIntro;

	private String feeIntro;

	private String refoundIntro;

	private String creator;

	private Date createTime;

	private String lastModUser;

	private Date lastModTime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id == null ? null : id.trim();
	}

	public String getActName() {
		return actName;
	}

	public void setActName(String actName) {
		this.actName = actName == null ? null : actName.trim();
	}

	public String getActCode() {
		return actCode;
	}

	public void setActCode(String actCode) {
		this.actCode = actCode == null ? null : actCode.trim();
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration == null ? null : duration.trim();
	}

	public String getEnthusiastId() {
		return enthusiastId;
	}

	public void setEnthusiastId(String enthusiastId) {
		this.enthusiastId = enthusiastId == null ? null : enthusiastId.trim();
	}

	public String getAreaId() {
		return areaId;
	}

	public void setAreaId(String areaId) {
		this.areaId = areaId == null ? null : areaId.trim();
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location == null ? null : location.trim();
	}

	public Short getMaxJoined() {
		return maxJoined;
	}

	public void setMaxJoined(Short maxJoined) {
		this.maxJoined = maxJoined;
	}

	public String getCharacteristic1() {
		return characteristic1;
	}

	public void setCharacteristic1(String characteristic1) {
		this.characteristic1 = characteristic1 == null ? null : characteristic1.trim();
	}

	public String getCharacteristic2() {
		return characteristic2;
	}

	public void setCharacteristic2(String characteristic2) {
		this.characteristic2 = characteristic2 == null ? null : characteristic2.trim();
	}

	public String getCharacteristic3() {
		return characteristic3;
	}

	public void setCharacteristic3(String characteristic3) {
		this.characteristic3 = characteristic3 == null ? null : characteristic3.trim();
	}

	public Short getSort() {
		return sort;
	}

	public void setSort(Short sort) {
		this.sort = sort;
	}

	public Byte getState() {
		return state;
	}

	public void setState(Byte state) {
		this.state = state;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator == null ? null : creator.trim();
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastModUser() {
		return lastModUser;
	}

	public void setLastModUser(String lastModUser) {
		this.lastModUser = lastModUser == null ? null : lastModUser.trim();
	}

	public Date getLastModTime() {
		return lastModTime;
	}

	public void setLastModTime(Date lastModTime) {
		this.lastModTime = lastModTime;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public String getItineraryIntro() {
		return itineraryIntro;
	}

	public void setItineraryIntro(String itineraryIntro) {
		this.itineraryIntro = itineraryIntro;
	}

	public String getFeeIntro() {
		return feeIntro;
	}

	public void setFeeIntro(String feeIntro) {
		this.feeIntro = feeIntro;
	}

	public String getRefoundIntro() {
		return refoundIntro;
	}

	public void setRefoundIntro(String refoundIntro) {
		this.refoundIntro = refoundIntro;
	}

}