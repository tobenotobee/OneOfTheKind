/**    
 * @Title: ActivityController.java  
 * @Package: cn.bluemobi.admin.controller  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月16日 下午5:45:42  
 * @Version V1.0    
 */

package cn.bluemobi.admin.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import cn.bluemobi.admin.service.ActivityService;

/**
 * @ClassName: ActivityController
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月16日 下午5:45:42
 * 
 */
@Controller
@RequestMapping(value = "/admin/activity")
public class ActivityController {

	@Autowired
	private ActivityService activityService;

	/**
	 * 
	 * @Description: 获取活动下拉列表
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getActivityComboboxList", method = RequestMethod.POST,
					produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getActivityComboboxList() {
		List<Map<String, String>> actList = activityService.getActivityForCombobox();
		return JSON.toJSONString(actList);
	}

}
