/**    
 * @Title: MemberDetailController.java  
 * @Package: cn.bluemobi.admin.controller  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月17日 下午8:14:01  
 * @Version V1.0    
 */

package cn.bluemobi.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.catalina.tribes.MembershipService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bluemobi.admin.model.Area;
import cn.bluemobi.admin.model.MemberDetail;
import cn.bluemobi.admin.service.MemberService;
import cn.bluemobi.admin.util.PageUtil;

import com.alibaba.fastjson.JSON;

/**
 * @ClassName: MemberDetailController
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月17日 下午8:14:01
 * 
 */
@Controller
@RequestMapping(value = "/admin/member")
public class MemberController {

	@Autowired
	private MemberService memberService;

	/**
	 * 
	 * @Description: 跳转到轮播图首页
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/jump2list", method = RequestMethod.GET)
	public String list() {
		return "member/memberList";
	}

	/**
	 * 
	 * @Description: 获取省份列表
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getMemberList", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getMemberList(@RequestParam("page") int pageNo, @RequestParam("rows") int pageSize) {
		Map<String, Object> paramap = PageUtil.getQueryMapForPage(pageNo, pageSize);
		Map<String, Object> resmap = new HashMap<String, Object>();

		List<MemberDetail> memberList = memberService.getMemberList(paramap);
		long totalcnt = memberService.getMembersCount(paramap);
		resmap.put("total", totalcnt);
		resmap.put("rows", memberList);
		return JSON.toJSONString(resmap);
	}

}
