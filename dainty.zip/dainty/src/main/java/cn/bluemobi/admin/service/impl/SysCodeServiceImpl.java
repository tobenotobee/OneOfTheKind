/**    
 * @Title: SysCodeServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description: 系统Code Service接口实现类
 * @Author: huh
 * @Date: 2015年10月14日 下午1:10:40  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.SysCodeMapper;
import cn.bluemobi.admin.model.SysCode;
import cn.bluemobi.admin.service.SysCodeService;

/**
 * @ClassName: SysCodeServiceImpl
 * @Description: 系统Code Service接口实现类
 * @author huh
 * @date 2015年10月14日 下午1:10:40
 * 
 */
@Service("sysCodeService")
public class SysCodeServiceImpl implements SysCodeService {

	@Autowired
	private SysCodeMapper sysCodeMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.SysCodeService#getSysCodeByCode(java.lang
	 * .String)
	 */
	@Override
	public List<SysCode> getSysCodeByCode(Map<String, String> paramap) {
		return sysCodeMapper.getSysCodeByCode(paramap);
	}

}
