/**    
 * @Title: SysCode.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: 系统Code类
 * @Author: huh
 * @Date: 2015年10月14日 下午12:04:00  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

/**
 * @ClassName: SysCode
 * @Description: 系统code
 * @author huh
 * @date 2015年10月14日 下午12:04:00
 * 
 */
public class SysCode {

	private Integer id;
	private String codeValue;
	private String codeLabel;
	private String code;
	private Integer sort;
	private Integer isUse;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCodeValue() {
		return codeValue;
	}

	public void setCodeValue(String codeValue) {
		this.codeValue = codeValue;
	}

	public String getCodeLabel() {
		return codeLabel;
	}

	public void setCodeLabel(String codeLabel) {
		this.codeLabel = codeLabel;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Integer getIsUse() {
		return isUse;
	}

	public void setIsUse(Integer isUse) {
		this.isUse = isUse;
	}

}
