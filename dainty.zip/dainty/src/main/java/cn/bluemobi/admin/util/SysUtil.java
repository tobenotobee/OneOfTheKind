package cn.bluemobi.admin.util;

import java.util.UUID;


/**
 * 系统工具类
 * @author zhangbing
 */
public class SysUtil {
	
	public static String GetUUID(){
		 String s = UUID.randomUUID().toString(); 
	     //去掉“-”符号 
	     return s.substring(0,8)+s.substring(9,13)+s.substring(14,18)+s.substring(19,23)+s.substring(24); 
	}
	
	public static void main(String[] args) {
		System.out.println(GetUUID());
	}
}

