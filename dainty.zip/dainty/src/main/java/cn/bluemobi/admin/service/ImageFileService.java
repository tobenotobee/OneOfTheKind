/**    
 * @Title: ImageFileService.java  
 * @Package: cn.bluemobi.admin.service  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月16日 上午11:57:03  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.ImageFile;

/**
 * @ClassName: ImageFileService
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月16日 上午11:57:03
 * 
 */
public interface ImageFileService {

	/**
	 * 
	 * @Description: 获取图片详情
	 * @param paramap
	 * @return
	 * @throws
	 */
	public List<ImageFile> getImageFile(Map<String, Object> paramap);// refId+imgType

	/**
	 * 
	 * @Description: 删除图片
	 * @param paramap
	 * @throws
	 */
	public void deleteImageFile(Map<String, Object> paramap);// refId+imgType

	/**
	 * 
	 * @Description: 修改图片
	 * @param paramap
	 * @throws
	 */
	public void updateImageFile(Map<String, Object> paramap);// refId+imgType+imgUrl

	/**
	 * 
	 * @Description: 新增图片
	 * @param imageFile
	 * @throws
	 */
	public void addImageFile(ImageFile imageFile);

}
