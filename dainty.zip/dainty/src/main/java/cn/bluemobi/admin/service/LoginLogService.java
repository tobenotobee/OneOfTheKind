package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.LoginLog;

/**
 * 登录日志
 * @author songss
 *
 */
public interface LoginLogService {
	
	/**
	 * 新增登录日志
	 * @param map
	 * @return
	 */
	int insertLoginLog(Map<String, Object> map);
	
	/**
	 * 
	* @Description: 获取登录日志列表 
	* @param @param paramap
	* @param @return    
	* @return   
	* @throws
	 */
	public List<LoginLog> getLoginLogForPage(Map<String, Object> paramap);
	
	/**
	 * 
	* @Description: 获取登录日志记录数 
	* @param @param paramap
	* @param @return    
	* @return   
	* @throws
	 */
	public long getLoginLogCount(Map<String, Object> paramap);
}