package cn.bluemobi.admin.dao.mybatis;

import cn.bluemobi.admin.model.Enthusiast;

public interface EnthusiastMapper {
    int deleteByPrimaryKey(String id);

    int insert(Enthusiast record);

    int insertSelective(Enthusiast record);

    Enthusiast selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Enthusiast record);

    int updateByPrimaryKeyWithBLOBs(Enthusiast record);

    int updateByPrimaryKey(Enthusiast record);
}