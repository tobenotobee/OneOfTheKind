/**    
 * @Title: SysCodeService.java  
 * @Package: cn.bluemobi.admin.service  
 * @Description: 系统Code Service接口类
 * @Author: huh
 * @Date: 2015年10月14日 下午1:10:01  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.SysCode;

/**
 * @ClassName: SysCodeService
 * @Description: 系统Code Service接口
 * @author huh
 * @date 2015年10月14日 下午1:10:01
 * 
 */
public interface SysCodeService {

	/**
	 * 
	 * @Description: 根据code，状态获取code列表
	 * @param @param code
	 * @param @return
	 * @return
	 * @throws
	 */
	public List<SysCode> getSysCodeByCode(Map<String, String> paramap);
}
