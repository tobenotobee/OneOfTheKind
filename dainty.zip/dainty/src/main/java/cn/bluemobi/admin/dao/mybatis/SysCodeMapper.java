/**    
 * @Title: SysCodeMapper.java  
 * @Package: cn.bluemobi.admin.dao.mybatis  
 * @Description: 系统Code dao Mapper类
 * @Author: huh
 * @Date: 2015年10月14日 下午1:00:32  
 * @Version V1.0    
 */

package cn.bluemobi.admin.dao.mybatis;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.SysCode;

/**
 * @ClassName: SysCodeMapper
 * @Description: 系统Code dao Mapper
 * @author huh
 * @date 2015年10月14日 下午1:00:32
 * 
 */
public interface SysCodeMapper {

	/**
	 * 
	 * @Description: 根据code，状态获取code列表
	 * @param @param code
	 * @param @return
	 * @return
	 * @throws
	 */
	public List<SysCode> getSysCodeByCode(Map<String, String> paramap);

}
