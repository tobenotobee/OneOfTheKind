package cn.bluemobi.admin.dao;

public interface TestDao {
	java.util.Collection<?> query();
}
