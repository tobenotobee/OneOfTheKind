/**    
 * @Title: TipServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月16日 下午6:34:24  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.TipMapper;
import cn.bluemobi.admin.model.Tip;
import cn.bluemobi.admin.service.TipService;

/**
 * @ClassName: TipServiceImpl
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月16日 下午6:34:24
 * 
 */
@Service("tipService")
public class TipServiceImpl implements TipService {

	@Autowired
	private TipMapper tipMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.TipService#getTipsForPage(java.util.Map)
	 */
	@Override
	public List<Tip> getTipsForPage(Map<String, Object> paramap) {
		return tipMapper.getTipsForPage(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.TipService#insertTip(cn.bluemobi.admin.
	 * model.Tip)
	 */
	@Override
	public void insertTip(Tip tip) {
		tipMapper.insertTip(tip);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.TipService#updateTip(cn.bluemobi.admin.
	 * model.Tip)
	 */
	@Override
	public void updateTip(Tip tip) {
		tipMapper.updateTip(tip);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.TipService#deleteTip(java.lang.String)
	 */
	@Override
	public void deleteTip(String id) {
		tipMapper.deleteTip(id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.TipService#getTipCombobox()
	 */
	@Override
	public List<Map<String, String>> getTipCombobox() {
		return tipMapper.getTipForCombobox();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.TipService#getTipList(java.util.Map)
	 */
	@Override
	public List<Map<String, Object>> getTipList(Map<String, Object> paramap) {
		return tipMapper.getTipList(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.TipService#getTip(java.lang.String)
	 */
	@Override
	public Map<String, Object> getTip(String id) {
		return tipMapper.getTip(id);
	}

}
