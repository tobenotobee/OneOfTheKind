package cn.bluemobi.admin.security;

import java.util.Collection;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.springframework.security.access.AccessDecisionManager;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;

/***
 * 访问决策管理器
 * @author hug
 *
 */
@Service
public class SysAccessDecisionManager implements AccessDecisionManager {

	//日志
	private static final Logger log = Logger.getLogger(SysAccessDecisionManager.class);
	
	@Override
	public void decide(Authentication authentication, Object object,
			Collection<ConfigAttribute> configAttributes) throws AccessDeniedException,
			InsufficientAuthenticationException {
		if(log.isDebugEnabled()){
			log.debug("【spring-security】SysAccessDecisionManager decide start");
		}
		if(configAttributes==null){
			if(log.isDebugEnabled()){
				log.debug("【spring-security】SysAccessDecisionManager decide end");
			}
			return;
		}
		if(log.isDebugEnabled()){
			log.debug("【spring-security】访问的URL:"+object);
		}
		
		Iterator<ConfigAttribute> iterator = configAttributes.iterator();
		while(iterator.hasNext()){
			ConfigAttribute ca = iterator.next();
			if(log.isDebugEnabled()){
				log.debug("【spring-security】ConfigAttribute Attribute : "+ca.getAttribute());
			}
			String needRole = ((SecurityConfig) ca).getAttribute();
			if(log.isDebugEnabled()){
				log.debug("【spring-security】need role : "+needRole);
			}
			for(GrantedAuthority ga :authentication.getAuthorities()){
				if(log.isDebugEnabled()){
					log.debug("【spring-security】 授权信息："+ga.getAuthority());
				}
				if(needRole.equals(ga.getAuthority())){
					if(log.isDebugEnabled()){
						log.debug("【spring-security】 访问合法.");
						log.debug("【spring-security】SysAccessDecisionManager decide end");
					}
					return;
				}
				
			}
		}	
		throw new AccessDeniedException("对不起，您没有访问权限！");

	}

	@Override
	public boolean supports(ConfigAttribute attribute) {
		
		return true;
		
	}

	@Override
	public boolean supports(Class<?> clazz) {
		
		return true;
		
	}

}
