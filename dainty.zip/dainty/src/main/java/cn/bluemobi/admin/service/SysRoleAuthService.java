package cn.bluemobi.admin.service;

import java.util.List;

import cn.bluemobi.admin.model.SysRoleAuth;
import cn.bluemobi.admin.vo.SysTreeJson;

/***
 * 角色权限关系service接口
 * @author hug
 *
 */
public interface SysRoleAuthService {

	/**
	 * 新增角色权限关系
	 * @param sysRoleAuth
	 * @return
	 */
	public void insertSysRoleAuth(SysRoleAuth sysRoleAuth);
	
	/**
	 * 批量新增角色权限关系
	 * @param sysRoleAuthList
	 * @return
	 */
	public void insertSysRoleAuthList(List<SysRoleAuth> sysRoleAuthList);
	
	/**
	 * 根据角色删除对应的权限关系信息
	 * @param roleId
	 * @return
	 */
	public void deleteByRoleId(long roleId);
	
	/**
	 * 根据authId、roleId获取其子权限角色关系
	 * @param roleId
	 * @param authId
	 * @return
	 */
	public List<SysRoleAuth> selectRoleAuth(long roleId,long authId);
	
	/**
	 * 角色设置权限jsonTree
	 * @param roleAuthList 角色权限集合
	 * @param roleId 当前角色ID
	 * @return
	 */
	public List<SysTreeJson> getAuthTreeJson(List<SysRoleAuth> roleAuthList,long roleId);
	
}
