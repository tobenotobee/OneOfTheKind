/**    
 * @Title: CityService.java  
 * @Package: cn.bluemobi.admin.service  
 * @Description: 城市service接口类
 * @Author: huh
 * @Date: 2015年11月17日 下午5:32:14  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service;

import java.util.List;

import cn.bluemobi.admin.model.City;

/**
 * @ClassName: CityService
 * @Description: 城市service接口
 * @author huh
 * @date 2015年11月17日 下午5:32:14
 * 
 */
public interface CityService {
	/**
	 * 
	 * @Description: 获取省份列表
	 * @return
	 * @throws
	 */
	public List<City> getProvinceList();

	/**
	 * 
	 * @Description:根据省份获取城市
	 * @param provinceId
	 * @return
	 * @throws
	 */
	public List<City> getCityListByProvince(String provinceId);
}
