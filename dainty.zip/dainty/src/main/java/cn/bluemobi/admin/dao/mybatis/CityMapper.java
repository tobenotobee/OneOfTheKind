/**    
 * @Title: CityMapper.java  
 * @Package: cn.bluemobi.admin.dao.mybatis  
 * @Description: 城市mapper类
 * @Author: huh
 * @Date: 2015年11月17日 下午5:21:04  
 * @Version V1.0    
 */

package cn.bluemobi.admin.dao.mybatis;

import java.util.List;

import cn.bluemobi.admin.model.City;

/**
 * @ClassName: CityMapper
 * @Description: 城市mapper
 * @author huh
 * @date 2015年11月17日 下午5:21:04
 * 
 */
public interface CityMapper {

	/**
	 * 
	 * @Description: 获取省份列表
	 * @return
	 * @throws
	 */
	public List<City> getProvinceList();

	/**
	 * 
	 * @Description:根据省份获取城市
	 * @param provinceId
	 * @return
	 * @throws
	 */
	public List<City> getCityListByProvince(String provinceId);
}
