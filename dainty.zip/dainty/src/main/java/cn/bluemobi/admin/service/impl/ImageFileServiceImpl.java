/**    
 * @Title: ImageFileServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月16日 上午11:58:21  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.ImageFileMapper;
import cn.bluemobi.admin.model.ImageFile;
import cn.bluemobi.admin.service.ImageFileService;

/**
 * @ClassName: ImageFileServiceImpl
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月16日 上午11:58:21
 * 
 */
@Service("imageFileService")
public class ImageFileServiceImpl implements ImageFileService {

	
	@Autowired
	private ImageFileMapper imageFileMapper;


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.ImageFileService#deleteImageFile(java.util
	 * .Map)
	 */
	@Override
	public void deleteImageFile(Map<String, Object> paramap) {
		imageFileMapper.deleteImageFile(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.ImageFileService#updateImageFile(java.util
	 * .Map)
	 */
	@Override
	public void updateImageFile(Map<String, Object> paramap) {
		imageFileMapper.updateImageFile(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.ImageFileService#addImageFile(cn.bluemobi
	 * .admin.model.ImageFile)
	 */
	@Override
	public void addImageFile(ImageFile imageFile) {
		imageFileMapper.addImageFile(imageFile);
	}

	/* (non-Javadoc)
	 * @see cn.bluemobi.admin.service.ImageFileService#getImageFile(java.util.Map)
	 */
	@Override
	public List<ImageFile> getImageFile(Map<String, Object> paramap) {
		return imageFileMapper.getImageFile(paramap);
	}

}
