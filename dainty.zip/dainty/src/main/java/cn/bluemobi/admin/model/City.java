/**    
 * @Title: City.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: 城市类
 * @Author: huh
 * @Date: 2015年11月17日 下午5:20:18  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

/**
 * @ClassName: City
 * @Description: 城市
 * @author huh
 * @date 2015年11月17日 下午5:20:18
 * 
 */
public class City {
	private String id;
	private Byte type;
	private String name;
	private String abbr;
	private String parentId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Byte getType() {
		return type;
	}

	public void setType(Byte type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAbbr() {
		return abbr;
	}

	public void setAbbr(String abbr) {
		this.abbr = abbr;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

}
