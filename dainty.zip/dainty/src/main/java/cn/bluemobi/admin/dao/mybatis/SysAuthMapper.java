package cn.bluemobi.admin.dao.mybatis;

import java.util.List;

import cn.bluemobi.admin.model.SysAuth;

/***
 * 用户权限数据访问Mapper
 * @author hug
 *
 */
public interface SysAuthMapper {

	/**
	 * 新增用户权限
	 * @param sysAuth
	 * @return
	 */
	public int insertSysAuth(SysAuth sysAuth);
	
	/**
	 * 修改用户权限
	 * @param sysAuth
	 * @return
	 */
	public int updateSysAuth(SysAuth sysAuth);
	
	/**
	 * 根据ID获取用户权限
	 * @param authId
	 * @return
	 */
	public SysAuth getSysAuth(long authId);
	
	/**
	 * 根据ID删除用户权限
	 * @param authId
	 * @return
	 */
	public int deleteSysAuth(String[] authIds);
	
	/**
	 * 查询所有权限信息
	 * @return
	 */
	public List<SysAuth> getAllSysAuth();
	
	/**
	 * 根据权限ID查询子权限
	 * @param authId
	 * @return
	 */
	public List<SysAuth> getChildSysAuth(long authId);
	
	/**
	 * 根据角色查询对应权限
	 * @param roleId
	 * @return
	 */
	public List<SysAuth> getAuthByRoleId(long roleId);
	
}
