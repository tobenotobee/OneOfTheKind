/**    
 * @Title: SysBaseCodeMapper.java  
 * @Package: cn.bluemobi.admin.dao.mybatis  
 * @Description: 系统编码mapper类
 * @Author: huh
 * @Date: 2015年10月16日 上午11:11:48  
 * @Version V1.0    
 */

package cn.bluemobi.admin.dao.mybatis;

import java.util.List;

import cn.bluemobi.admin.model.SysBaseCode;

/**
 * @ClassName: SysBaseCodeMapper
 * @Description: 系统编码mapper
 * @author huh
 * @date 2015年10月16日 上午11:11:48
 * 
 */
public interface SysBaseCodeMapper {

	/**
	 * 
	 * @Description: 获取所有字典类型
	 * @param @return
	 * @return
	 * @throws
	 */
	public List<SysBaseCode> getAllBaseCode();

}
