package cn.bluemobi.admin.controller;

import java.util.*;

import static cn.bluemobi.admin.constant.AdminConstant.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import cn.bluemobi.admin.model.SysAuth;
import cn.bluemobi.admin.service.SysAuthService;
import cn.bluemobi.admin.vo.SysAuthJson;

/***
 * 权限管理controller
 * @author hug
 *
 */
@Controller
@RequestMapping("/admin/sysAuth")
public class SysAuthController {
	
	@Autowired
	private SysAuthService sysAuthService;  //权限管理service
	
	/**
	 * 跳转权限管理页面
	 * @return
	 */
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public String authList(){
		
		return "sysAuth/authList";
		
	}
	
	/**
	 * 返回权限树json数据
	 * @return
	 */
	@RequestMapping(value="/authTree",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String authTree(String openNodeId){
		
		List<SysAuth> authList = sysAuthService.getChildSysAuth(SYS_AUTH_ROOT_ID);
		
		SysAuthJson authRoot = new SysAuthJson();
		authRoot.setAuthId(0L);
		authRoot.setAuthName("系统权限");
		authRoot.setIconCls("icon-key");
		authRoot.setState("open");
		if(authList!=null&&authList.size()>0){
			if(null!=openNodeId&&!"".equals(openNodeId)){
				
				String [] openIdArray = openNodeId.split(",");
				authRoot.setChildren(sysAuthService.getAllAuthJson(authList,openIdArray));
			}else{
				authRoot.setChildren(sysAuthService.getAllAuthJson(authList));
			}
			
		}
		
		String res = JSON.toJSONString(authRoot);
		//System.out.println(res);
		return res;
		
	}

	/**
	 * 新增权限信息
	 * @return
	 */
	@RequestMapping(value="/addAuth",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String addAuth(SysAuth sysAuth){
		
		Map<String,Object> resMap = new HashMap<String, Object>();
		try{
			
			sysAuthService.insertSysAuth(sysAuth);
			resMap.put("status", RETURN_STATUS_SUCCESS);
			
		}catch(Exception e){
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
		}
		//System.out.println(JSON.toJSONString(resMap));
		return JSON.toJSONString(resMap);
	}
	
	/**
	 * 修改权限
	 * @param sysAuth
	 * @return
	 */
	@RequestMapping(value="/updateAuth",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String updateAuth(SysAuth sysAuth){
		
		Map<String,Object> resMap = new HashMap<String, Object>();
		try {
			
			sysAuthService.updateSysAuth(sysAuth);
			resMap.put("status", RETURN_STATUS_SUCCESS);
			
		} catch (Exception e) {
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
		}
		
		return JSON.toJSONString(resMap);
		
	}
	
	/**
	 * 删除权限
	 * @return
	 */
	@RequestMapping(value="/deleteAuth",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String deleteAuth(String deleteIds){
		
		Map<String,Object> resMap = new HashMap<String, Object>();
		try {
			
			String [] deleArray = deleteIds.split(",");
			sysAuthService.deleteSysAuth(deleArray);
			resMap.put("status", RETURN_STATUS_SUCCESS);
			
		} catch (Exception e) {
			
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
			
		}
		
		return JSON.toJSONString(resMap);
		
	}
	
}
