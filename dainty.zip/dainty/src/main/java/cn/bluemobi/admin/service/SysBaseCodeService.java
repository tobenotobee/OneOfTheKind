/**    
 * @Title: SysBaseCodeService.java  
 * @Package: cn.bluemobi.admin.service  
 * @Description: 数据字典编码service接口类
 * @Author: huh
 * @Date: 2015年10月16日 上午11:18:21  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service;

import java.util.List;
import cn.bluemobi.admin.model.SysBaseCode;

/**
 * @ClassName: SysBaseCodeService
 * @Description: 数据字典编码service接口
 * @author huh
 * @date 2015年10月16日 上午11:18:21
 * 
 */
public interface SysBaseCodeService {

	/**
	 * 
	 * @Description: 获取所有字典类型
	 * @param @return
	 * @return
	 * @throws
	 */
	public List<SysBaseCode> getAllBaseCode();
}
