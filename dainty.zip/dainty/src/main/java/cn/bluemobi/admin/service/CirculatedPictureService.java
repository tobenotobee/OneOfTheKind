/**    
 * @Title: CirculatedPictureService.java  
 * @Package: cn.bluemobi.admin.service  
 * @Description: 轮播图service接口类
 * @Author: huh
 * @Date: 2015年10月14日 上午9:44:40  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;
import cn.bluemobi.admin.model.CirculatedPicture;

/**
 * @ClassName: CirculatedPictureService
 * @Description: 轮播图service接口
 * @author huh
 * @date 2015年10月14日 上午9:44:40
 * 
 */
public interface CirculatedPictureService {

	/**
	 * 
	 * @Description: 新增轮播图
	 * @param @param circulatedPicture
	 * @return
	 * @throws
	 */
	public void insertCirculatedPicture(CirculatedPicture circulatedPicture);

	/**
	 * 
	 * @Description: 删除轮播图
	 * @param @param id
	 * @return
	 * @throws
	 */
	public void deleteCirculatedPicture(String id);

	/**
	 * 更新轮播图信息
	 * 
	 * @Description: 更新轮播图信息
	 * @param @param circulatedPicture
	 * @return
	 * @throws
	 */
	public void updateCirculatedPicture(CirculatedPicture circulatedPicture);

	/**
	 * 
	 * @Description: 根据ID查找轮播图详细信息
	 * @param @param id
	 * @param @return
	 * @return
	 * @throws
	 */
	public CirculatedPicture getCirculatedPictureById(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 根据条件查询轮播图列表+分页
	 * @param @param paramap
	 * @param @return
	 * @return
	 * @throws
	 */
	public List<CirculatedPicture> getCirculatedPictureByNameForPage(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取满足条件的轮播图总记录数
	 * @param @param paramap
	 * @param @return
	 * @return
	 * @throws
	 */
	public long getCirculatedPictureCount(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取新增的排序号
	 * @param @return
	 * @return
	 * @throws
	 */
	public int getNextSort();

	/**
	 * 
	 * @Description: 判断sort记录是否存在
	 * @param @param sort
	 * @param @return
	 * @return
	 * @throws
	 */
	public boolean existCirculatedPictureBySort(int sort);
	
	
	/**************************APP *****************************/
	
	/**
	 * 
	* @Description: 获取轮播图信息
	* @param paramap
	* @return       
	* @throws
	 */
	public List<Map> getCirculatedPictureList(Map<String, Object> paramap);

}
