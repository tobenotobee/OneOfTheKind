/**    
 * @Title: CommentController.java  
 * @Package: cn.bluemobi.admin.controller  
 * @Description: 评价controller类
 * @Author: huh
 * @Date: 2015年10月20日 下午5:55:01  
 * @Version V1.0    
 */

package cn.bluemobi.admin.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import cn.bluemobi.admin.constant.AdminConstant;
import cn.bluemobi.admin.model.Comment;
import cn.bluemobi.admin.service.CommentService;
import cn.bluemobi.admin.util.PageUtil;

/**
 * @ClassName: CommentController
 * @Description: 评价controller
 * @author huh
 * @date 2015年10月20日 下午5:55:01
 * 
 */
@Controller
@RequestMapping(value = "/admin/comment")
public class CommentController {

	@Autowired
	private CommentService commentService; // 评论service

	/**
	 * 
	 * @Description: 跳转评价列表
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list() {
		return "comment/commentList";
	}

	/**
	 * 
	 * @Description: 获取评价列表
	 * @param pageNo
	 * @param pageSize
	 * @param name
	 * @param rating
	 * @param commentTime
	 * @param content
	 * @param type
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getCommentList", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getCommentList(@RequestParam("page") int pageNo,
					@RequestParam("rows") int pageSize, String name, String rating,
					Date commentTime, String content, String type) {
		//组装页面查询条件参数
		Map<String, Object> paramap = PageUtil.getQueryMapForPage(pageNo, pageSize);

		if (name != null && !"".equals(name))
			paramap.put("name", name);
		if (rating != null && Integer.parseInt(rating) != 0)
			paramap.put("rating", rating);
		if (commentTime != null && !"".equals(commentTime))
			paramap.put("commentTime", commentTime);
		if (content != null && !"".equals(content))
			paramap.put("content", content);
		paramap.put("type", type);

		Map<String, Object> resmap = new HashMap<String, Object>();
		List<Comment> cList = commentService.getCommentForPage(paramap);
		long totalcnt = commentService.getCommentCount(paramap);
		resmap.put("rows", cList);
		resmap.put("total", totalcnt);
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 屏蔽用户评论
	 * @param @param id
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/shieldComment", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public String shieldComment(String id) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			commentService.updateComment(id);
			resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}

}
