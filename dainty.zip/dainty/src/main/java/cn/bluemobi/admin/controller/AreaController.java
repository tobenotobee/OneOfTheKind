/**    
 * @Title: AreaController.java  
 * @Package: cn.bluemobi.admin.controller  
 * @Description: 地区controller类
 * @Author: huh
 * @Date: 2015年11月17日 下午4:59:40  
 * @Version V1.0    
 */

package cn.bluemobi.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import cn.bluemobi.admin.constant.AdminConstant;
import cn.bluemobi.admin.model.Area;
import cn.bluemobi.admin.model.City;
import cn.bluemobi.admin.model.SysUser;
import cn.bluemobi.admin.service.AreaService;
import cn.bluemobi.admin.service.CityService;
import cn.bluemobi.admin.util.PageUtil;

/**
 * @ClassName: AreaController
 * @Description: 地区controller
 * @author huh
 * @date 2015年11月17日 下午4:59:40
 * 
 */
@Controller
@RequestMapping(value = "/admin/area")
public class AreaController {

	@Autowired
	private AreaService areaService;  // 区域service

	@Autowired
	private CityService cityService;  // 城市service

	@Autowired
	private HttpServletRequest request;   // HttpServletRequest

	/**
	 * 
	 * @Description: 跳转到轮播图首页
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/jump2list", method = RequestMethod.GET)
	public String list() {
		return "area/areaList";
	}

	/**
	 * 
	 * @Description: 获取省份列表
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getAreaList", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getAreaList(@RequestParam("page") int pageNo, @RequestParam("rows") int pageSize,
					String areaName) {
		Map<String, Object> paramap = PageUtil.getQueryMapForPage(pageNo, pageSize);
		Map<String, Object> resmap = new HashMap<String, Object>();
		if (areaName != null && !"".equals(areaName)) {
			paramap.put("areaName", areaName);
		}
		List<Area> areaList = areaService.getAreasForPage(paramap);
		long totalcnt = areaService.getAreasCount(paramap);
		resmap.put("total", totalcnt);
		resmap.put("rows", areaList);
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 获取省份列表
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getProvinceList", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getProvinceList() {
		List<City> proList = cityService.getProvinceList();
		return JSON.toJSONString(proList);
	}

	/**
	 * 
	 * @Description: 获取城市列表
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getCityList", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getCityList(String id) {
		List<City> cityList = cityService.getCityListByProvince(id);
		return JSON.toJSONString(cityList);
	}

	/**
	 * 
	 * @Description: 删除地区
	 * @param id
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/deleteArea", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String deleteArea(String id) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			areaService.deleteArea(id);
			resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 添加地区
	 * @param id
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/addArea", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String addArea(Area area) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			// 从session中获取登录用户名称，用来查询用户信息
			SysUser sysUser = (SysUser) request.getSession().getAttribute("userBean");
			if (sysUser == null) {
				resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
				resmap.put("error", "操作用户不存在");
				return JSON.toJSONString(resmap);
			}
			area.setCreator(sysUser.getUserId());
			area.setSort(areaService.getMaxSort() + 1);
			areaService.addArea(area);
			resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}
}
