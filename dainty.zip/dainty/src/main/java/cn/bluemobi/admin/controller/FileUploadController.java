/** 
 * @包名   cn.bluemobi.bitgo.admin.controller 
 * @文件名 FileUploadController.java 
 * @作者   YanFeng.Wang 
 * @创建日期 2015年5月6日 
 * @修改日期 2015年11月17日
 * @版本 V 1.1 
 */
package cn.bluemobi.admin.controller;

import java.io.File;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.alibaba.fastjson.JSON;

import cn.bluemobi.admin.constant.AdminConstant;
import cn.bluemobi.admin.service.UploadFileService;

/**
 * @类名: FileUploadController
 * @描述: 上传图片处理类
 * @作者 YanFeng.Wang
 * @日期 2015年5月6日 下午1:31:32
 * 
 */
@Controller
@RequestMapping("/uploadFile")
public class FileUploadController {

	@Autowired
	private UploadFileService uploadFileService; // 文件上传service

	/**
	 * 
	 * @param fileType
	 * @author Huh
	 * @return
	 * @RequestParam("file") MultipartFile file,
	 * @throws Exception
	 *                 处理swfUpload上传控件图片
	 */
	@RequestMapping(value = "/preUploadImage", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String preUploadImage(@RequestParam("fileType") String fileType,
					HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			Map<String, MultipartFile> fileMap = multipartRequest.getFileMap();
			for (Map.Entry<String, MultipartFile> entity : fileMap.entrySet()) {
				MultipartFile mf = entity.getValue();
				String name = mf.getOriginalFilename();
				String fileName = name.substring(name.lastIndexOf('\\') + 1, name.length());// 文件名
				String subSuffix = fileName.substring(fileName.lastIndexOf('.'), fileName.length());
				String fileChangeName = UUID.randomUUID() + "-"
								+ DateFormatUtils.format(new Date(), "yyyyMMddHHmmss")
								+ subSuffix;
				String uploadDir = "";
				// 判断图片属于那个模块，是否为空,如果为空，保存为默认图片路径
				if (!fileType.equals("")) {
					uploadDir = "upload" + File.separatorChar + fileType + File.separatorChar;
				} else {
					uploadDir = "upload" + File.separatorChar + "defautImage" + File.separatorChar;
				}
				String filePathOrg = "";
				if ("tmp".equals(fileType)) {
					filePathOrg = uploadDir;
				} else {
					// 判断如果为临时时不拼接月日文件夹
					String autoCreatedDateDirByParttern = "yyyy" + File.separatorChar + "MM"
									+ File.separatorChar + "dd"
									+ File.separatorChar;

					String autoCreatedDateDir = DateFormatUtils.format(new java.util.Date(),
									autoCreatedDateDirByParttern);// 动态目录
					filePathOrg = uploadDir + autoCreatedDateDir;
				}
				String filePathReplace = filePathOrg.replace("\\", "/");
				try {
					uploadFileService.uploadFile(mf.getInputStream(), mf.getBytes(),
									filePathReplace, fileChangeName, 1);// 调用上传图片接口
					// 图片上传成功后 将图片信息插入数据库中
				} catch (Exception e) {
					e.printStackTrace();
				}

				resmap.put("url", uploadFileService.getFileHttpPath() + filePathReplace
								+ fileChangeName);
				resmap.put("filePath", filePathOrg);
				resmap.put("fileName", fileChangeName);
				resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}

	/**
	 * @param pageNo
	 * @param pageSize
	 * @param fileType
	 * @author YanFeng.Wang
	 * @return
	 * @RequestParam("file") MultipartFile file,
	 * @throws Exception
	 *                 处理swfUpload上传控件图片
	 */
	@RequestMapping(value = "/uploadSWFImage", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String uploadSWFImage(@RequestParam("fileType") String fileType,
					HttpServletRequest request, HttpServletResponse response) {
		try {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			Map<String, MultipartFile> fileMap = multipartRequest.getFileMap();
			for (Map.Entry<String, MultipartFile> entity : fileMap.entrySet()) {
				MultipartFile mf = entity.getValue();
				String name = mf.getOriginalFilename();
				String fileName = name.substring(name.lastIndexOf('\\') + 1, name.length());// 文件名
				String subSuffix = fileName.substring(fileName.lastIndexOf('.'), fileName.length());
				String fileChangeName = UUID.randomUUID() + "-"
								+ DateFormatUtils.format(new Date(), "yyyyMMddHHmmss")
								+ subSuffix;
				String uploadDir = "";
				String filePath = "";
				// 判断图片属于那个模块，是否为空,如果为空，保存为默认图片路径
				if (!fileType.equals("")) {
					uploadDir = "upload" + File.separatorChar + fileType + File.separatorChar;
				} else {
					uploadDir = "upload" + File.separatorChar + "defautImage" + File.separatorChar;
				}

				// 判断如果为国家区域时不拼接月日文件夹
				if ("startpage".equals(fileType)) {
					filePath = uploadDir;
				} else {
					String autoCreatedDateDirByParttern = "yyyy" + File.separatorChar + "MM"
									+ File.separatorChar + "dd"
									+ File.separatorChar;
					String autoCreatedDateDir = DateFormatUtils.format(new java.util.Date(),
									autoCreatedDateDirByParttern);// 动态目录
					filePath = uploadDir + autoCreatedDateDir;
				}

				try {
					uploadFileService.uploadFile(mf.getInputStream(), mf.getBytes(),
									filePath.replace("\\", "/"),
									fileChangeName.replace("\\", "/"), 1);// 调用上传图片接口
				} catch (Exception e) {
					e.printStackTrace();
				}
				response.setHeader("Content-type", "text/html;charset=UTF-8");
				response.setCharacterEncoding("UTF-8");
				PrintWriter pw = response.getWriter();
				String fielPath = (filePath + fileChangeName).replace("\\", "/");
				pw.write(uploadFileService.getFileHttpPath() + fielPath);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * @param pageNo
	 * @param pageSize
	 * @param fileType
	 * @author YanFeng.Wang
	 * @return @RequestParam("file") MultipartFile file,
	 * @throws Exception
	 *                 处理富文本图片
	 */
	@RequestMapping(value = "/uploadKingImage", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String uploadKingImage(@RequestParam("fileType") String fileType,
					HttpServletRequest request, HttpServletResponse response) {
		try {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			Map<String, MultipartFile> fileMap = multipartRequest.getFileMap();
			for (Map.Entry<String, MultipartFile> entity : fileMap.entrySet()) {
				MultipartFile mf = entity.getValue();
				String name = mf.getOriginalFilename();
				String fileName = name.substring(name.lastIndexOf('\\') + 1, name.length());// 文件名
				String subSuffix = fileName.substring(fileName.lastIndexOf('.'), fileName.length());
				String fileChangeName = UUID.randomUUID() + "-"
								+ DateFormatUtils.format(new Date(), "yyyyMMddHHmmss")
								+ subSuffix;
				String uploadDir = "";
				// 判断图片属于那个模块，是否为空,如果为空，保存为默认图片路径
				if (!fileType.equals("")) {
					uploadDir = "upload" + File.separatorChar + fileType + File.separatorChar;
				} else {
					uploadDir = "upload" + File.separatorChar + "defautImage" + File.separatorChar;
				}
				String autoCreatedDateDirByParttern = "yyyy" + File.separatorChar + "MM"
								+ File.separatorChar + "dd" + File.separatorChar;
				String autoCreatedDateDir = DateFormatUtils.format(new java.util.Date(),
								autoCreatedDateDirByParttern);// 动态目录
				String filePath = uploadDir + autoCreatedDateDir;
				JSONObject json = new JSONObject();
				response.setHeader("Content-type", "text/html;charset=UTF-8");
				response.setCharacterEncoding("UTF-8");

				try {
					uploadFileService.uploadFile(mf.getBytes(), filePath.replace("\\", "/"),
									fileChangeName.replace("\\", "/"));// 调用上传图片接口
				} catch (Exception e) {
					e.printStackTrace();
					json.put("error", 1);
					json.put("message", "上传错误");
					response.getWriter().print(json);
				} finally {
					json.put("error", 0);
					json.put("httpurl", uploadFileService.getFileHttpPath());
					json.put("url",
									"${httpurl}"
													+ filePath.replace("\\",
																	"/")
													+ fileChangeName.replace("\\",
																	"/"));
					response.getWriter().print(json);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
