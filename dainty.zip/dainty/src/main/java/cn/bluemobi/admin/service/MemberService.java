/**    
 * @Title: MemberService.java  
 * @Package: cn.bluemobi.admin.service  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月17日 下午8:16:19  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.MemberDetail;

/**
 * @ClassName: MemberService
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月17日 下午8:16:19
 * 
 */
public interface MemberService {

	/**
	 * 
	 * @Description: 获取会员列表+分页
	 * @param paramap
	 * @return
	 * @throws
	 */
	public List<MemberDetail> getMemberList(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取会员总记录数
	 * @param paramap
	 * @return
	 * @throws
	 */
	public long getMembersCount(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 删除会员
	 * @param id
	 * @throws
	 */
	public void deleteMemberDetail(String id);

}
