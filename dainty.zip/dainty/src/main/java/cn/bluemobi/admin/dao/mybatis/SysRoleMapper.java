package cn.bluemobi.admin.dao.mybatis;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.SysRole;

/***
 * 用户角色数据访问Mapper
 * @author hug
 *
 */
public interface SysRoleMapper {

	/**
	 * 新增用户角色
	 * @param sysRole
	 * @return
	 */
	public int insertSysRole(SysRole sysRole);
	
	/**
	 * 修改用户角色
	 * @param sysRole
	 * @return
	 */
	public int updateSysRole(SysRole sysRole);
	
	/**
	 * 根据角色ID获得角色信息
	 * @param roleId
	 * @return
	 */
	public SysRole getSysRole(long roleId);
	
	/**
	 * 根据角色ID删除角色信息
	 * @param roleId
	 * @return
	 */
	public int deleteSysRole(long roleId);
	
	/**
	 * 分页查询角色信息
	 * @param paramap
	 * @return
	 */
	public List<SysRole> getSysRoleForPage(Map<String,Object> paramap);
	
	/**
	 * 分页查询角色信息记录数统计
	 * @param paramap
	 * @return
	 */
	public long getSysRoleCount(Map<String,Object> paramap);
	
	/**
	 * 得到所有角色信息
	 * @return
	 */
	public List<SysRole> getAllRole();
	
}
