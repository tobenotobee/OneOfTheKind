/**    
 * @Title: Agreement.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: 用户协议实体类
 * @Author: huh
 * @Date: 2015年10月20日 上午9:42:11  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

import java.util.Date;

import cn.bluemobi.admin.constant.AdminConstant;

/**
 * @ClassName: Agreement
 * @Description: 用户协议实体
 * @author huh
 * @date 2015年10月20日 上午9:42:11
 * 
 */
public class Agreement {

	private String id;
	private String agrName;
	private String agrContext;
	private Integer isUse;
	private String isUseStr;
	private String creater;
	private Date createTime;
	private String lastUpdater;
	private Date lastUpdateTime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAgrName() {
		return agrName;
	}

	public void setAgrName(String agrName) {
		this.agrName = agrName;
	}

	public String getAgrContext() {
		return agrContext;
	}

	public void setAgrContext(String agrContext) {
		this.agrContext = agrContext;
	}

	public Integer getIsUse() {
		return isUse;
	}

	public void setIsUse(Integer isUse) {
		this.isUse = isUse;
	}

	public String getIsUseStr() {
		if (isUse == AdminConstant.STATUS_ENABLE)
			return "启用";
		else
			return "禁用";

	}

	public void setIsUseStr(String isUseStr) {
		this.isUseStr = isUseStr;
	}

	public String getCreater() {
		return creater;
	}

	public void setCreater(String creater) {
		this.creater = creater;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastUpdater() {
		return lastUpdater;
	}

	public void setLastUpdater(String lastUpdater) {
		this.lastUpdater = lastUpdater;
	}

	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}

	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

}
