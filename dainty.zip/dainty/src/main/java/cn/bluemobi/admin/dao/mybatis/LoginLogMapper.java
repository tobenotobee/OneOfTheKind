/**    
* @Title: LoginLogMapper.java  
* @Package: cn.bluemobi.admin.dao.mybatis  
* @Description: 登录日志mapper类
* @Author: huh
* @Date: 2015年10月20日 下午4:41:56  
* @Version V1.0    
*/



package cn.bluemobi.admin.dao.mybatis;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.LoginLog;

/**  
 * @ClassName: LoginLogMapper  
 * @Description: 登录日志mapper
 * @author huh
 * @date 2015年10月20日 下午4:41:56  
 *    
 */
public interface LoginLogMapper {
	
	/**
	 * 
	* @Description: 获取登录日志列表
	* @param @param paramap
	* @param @return    
	* @return   
	* @throws
	 */
	public List<LoginLog> getLoginLogForPage(Map<String, Object> paramap);
	
	/**
	 * 
	* @Description: 获取登录日志记录数
	* @param @param paramap
	* @param @return    
	* @return   
	* @throws
	 */
	public  long getLoginLogCount(Map<String, Object> paramap);

}
