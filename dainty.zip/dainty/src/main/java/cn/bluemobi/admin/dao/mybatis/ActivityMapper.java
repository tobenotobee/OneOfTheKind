package cn.bluemobi.admin.dao.mybatis;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.Activity;

/**
 * 
 * @ClassName: ActivityMapper
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月16日 下午5:32:31
 *
 */
public interface ActivityMapper {

	/**
	 * 
	 * @Description: 获取活动列表+分页
	 * @param paramap
	 * @return
	 * @throws
	 */
	public List<Activity> getActivitysForPage(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取活动总记录数
	 * @param paramap
	 * @return
	 * @throws
	 */
	public long getActivitysCount(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 修改活动
	 * @param activity
	 * @throws
	 */
	public void updateActivity(Activity activity);

	/**
	 * 
	 * @Description: 获取所有活动下拉列表
	 * @return
	 * @throws
	 */
	public List<Map<String, String>> getActivityForCombobox();

}