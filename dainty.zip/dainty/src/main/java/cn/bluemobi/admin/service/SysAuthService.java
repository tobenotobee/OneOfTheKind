package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.SysAuth;
import cn.bluemobi.admin.vo.SysAuthJson;

/***
 * 用户权限管理service
 * @author hug
 *
 */
public interface SysAuthService {
	
	/**
	 * 新增用户权限
	 * @param sysAuth
	 * @return
	 */
	public void insertSysAuth(SysAuth sysAuth);
	
	/**
	 * 修改用户权限
	 * @param sysAuth
	 * @return
	 */
	public void updateSysAuth(SysAuth sysAuth);
	
	/**
	 * 根据ID查询用户权限
	 * @param authId
	 * @return
	 */
	public SysAuth getSysAuth(long authId);
	
	/**
	 * 根据ID删除用户权限
	 * @param authId
	 * @return
	 */
	public void deleteSysAuth(String[] authIds);
	
	/**
	 * 查询所有权限信息
	 * @return
	 */
	public List<SysAuth> getAllSysAuth();
	
	/**
	 * 根据权限ID查询子权限
	 * @param authId
	 * @return
	 */
	public List<SysAuth> getChildSysAuth(long authId);
	
	/**
	 * 构建权限树
	 * @param authId
	 * @return
	 */
	public List<SysAuthJson> getAllAuthJson(List<SysAuth> authList);
	
	/**
	 * 构建权限树
	 * @param authList
	 * @param openIdArray
	 * @return
	 */
	public List<SysAuthJson> getAllAuthJson(List<SysAuth> authList,String [] openIdArray);
	
	/**
	 * 构建权限树
	 * @param authList
	 * @return
	 */
	public List<Map<String,Object>> getAllAuthJsonMap(List<SysAuth> authList);
	
	/**
	 * 根据角色查询对应权限
	 * @param roleId
	 * @return
	 */
	public List<SysAuth> getAuthByRoleId(long roleId);
	
}
