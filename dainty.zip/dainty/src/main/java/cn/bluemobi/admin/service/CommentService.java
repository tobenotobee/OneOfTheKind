/**    
 * @Title: CommentService.java  
 * @Package: cn.bluemobi.admin.service  
 * @Description: 评价Service接口类
 * @Author: huh
 * @Date: 2015年10月20日 下午4:52:01  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.Comment;

/**
 * @ClassName: CommentService
 * @Description: 评价Service接口
 * @author huh
 * @date 2015年10月20日 下午4:52:01
 * 
 */
public interface CommentService {

	/**
	 * 
	 * @Description: 获取评价列表
	 * @param @param paramap
	 * @param @return
	 * @return
	 * @throws
	 */
	public List<Comment> getCommentForPage(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取评价记录数
	 * @param @param paramap
	 * @param @return
	 * @return
	 * @throws
	 */
	public long getCommentCount(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 屏蔽评论
	 * @param @param id
	 * @return
	 * @throws
	 */
	public void updateComment(String id);
}
