/**    
 * @Title: ImageFileMapper.java  
 * @Package: cn.bluemobi.admin.dao.mybatis  
 * @Description: 图片mapper 类
 * @Author: huh
 * @Date: 2015年11月16日 上午11:40:21  
 * @Version V1.0    
 */

package cn.bluemobi.admin.dao.mybatis;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.ImageFile;

/**
 * @ClassName: ImageFileMapper
 * @Description: 图片mapper
 * @author huh
 * @date 2015年11月16日 上午11:40:21
 * 
 */
public interface ImageFileMapper {

	/**
	 * 
	 * @Description: 获取图片详情
	 * @param paramap
	 * @return
	 * @throws
	 */
	public List<ImageFile> getImageFile(Map<String, Object> paramap);// refId+imgType

	/**
	 * 
	 * @Description: 删除图片
	 * @param paramap
	 * @throws
	 */
	public void deleteImageFile(Map<String, Object> paramap);// refId+imgType

	/**
	 * 
	 * @Description: 修改图片
	 * @param paramap
	 * @throws
	 */
	public void updateImageFile(Map<String, Object> paramap);// refId+imgType+imgUrl

	/**
	 * 
	 * @Description: 新增图片
	 * @param imageFile
	 * @throws
	 */
	public void addImageFile(ImageFile imageFile);

}
