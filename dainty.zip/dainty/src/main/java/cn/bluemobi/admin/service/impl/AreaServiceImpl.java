/**    
 * @Title: AreaServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description:地区service接口实现类
 * @Author: huh
 * @Date: 2015年11月17日 下午5:15:12  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.AreaMapper;
import cn.bluemobi.admin.model.Area;
import cn.bluemobi.admin.service.AreaService;

/**
 * @ClassName: AreaServiceImpl
 * @Description: 地区service接口实现
 * @author huh
 * @date 2015年11月17日 下午5:15:12
 * 
 */
@Service("areaService")
public class AreaServiceImpl implements AreaService {

	@Autowired
	private AreaMapper areaMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.AreaService#insertArea(cn.bluemobi.admin
	 * .model.Area)
	 */
	@Override
	public void addArea(Area area) {
		areaMapper.insertArea(area);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.AreaService#getAreasForPage(java.util.Map)
	 */
	@Override
	public List<Area> getAreasForPage(Map<String, Object> paramap) {
		return areaMapper.getAreasForPage(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.AreaService#getAreasCount(java.util.Map)
	 */
	@Override
	public long getAreasCount(Map<String, Object> paramap) {
		return areaMapper.getAreasCount(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.AreaService#deleteArea(java.lang.String)
	 */
	@Override
	public void deleteArea(String id) {
		areaMapper.deleteArea(id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see cn.bluemobi.admin.service.AreaService#getMaxSort()
	 */
	@Override
	public Integer getMaxSort() {
		return areaMapper.getMaxSort();
	}

}
