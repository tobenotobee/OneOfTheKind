package cn.bluemobi.admin.dao.impl;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.TestDao;
import cn.bluemobi.admin.service.TestService;

@Service
public class TestDaoImpl implements TestDao{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public Collection<?> query() {
		String sqlStr = "select * from t_sys_user";
		java.util.Collection<?> list = jdbcTemplate.queryForList(sqlStr);
        return list;
	}

}
