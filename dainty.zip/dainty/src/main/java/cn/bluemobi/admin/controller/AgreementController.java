/**    
 * @Title: AgreementController.java  
 * @Package: cn.bluemobi.admin.controller  
 * @Description: 用户协议controller类
 * @Author: huh
 * @Date: 2015年10月20日 下午2:51:14  
 * @Version V1.0    
 */

package cn.bluemobi.admin.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import cn.bluemobi.admin.constant.AdminConstant;
import cn.bluemobi.admin.model.Agreement;
import cn.bluemobi.admin.model.SysUser;
import cn.bluemobi.admin.service.AgreementService;
import cn.bluemobi.admin.util.PageUtil;

/**
 * @ClassName: AgreementController
 * @Description: 用户协议controller
 * @author huh
 * @date 2015年10月20日 下午2:51:14
 * 
 */
@Controller
@RequestMapping(value = "/admin/agreement")
public class AgreementController {

	@Autowired
	private AgreementService agreementService; // 用户协议service

	@Autowired
	private HttpServletRequest request; // request

	/**
	 * 
	 * @Description: 跳转到列表页面
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list() {
		return "agreement/agreementList";
	}

	/**
	 * 
	 * @Description: 获取协议列表
	 * @param @param pageNo
	 * @param @param pageSize
	 * @param @param agrName
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getAgreementList", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getAgreementList(@RequestParam("page") int pageNo,
					@RequestParam("rows") int pageSize, String agrName) {
		//组装页面查询条件参数
		Map<String, Object> paramap = PageUtil.getQueryMapForPage(pageNo, pageSize);
		
		if (agrName != null && !"".equals(agrName))
			paramap.put("agrName", agrName);
		Map<String, Object> resmap = new HashMap<String, Object>();
		List<Agreement> agrList = agreementService.getAgreementsForPage(paramap);
		long totalcnt = agreementService.getAgreementsCount(paramap);
		resmap.put("rows", agrList);
		resmap.put("total", totalcnt);
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 添加协议
	 * @param @param agreement
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/addAgreement", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String addAgreement(Agreement agreement) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			// 从session中获取登录用户名称，用来查询用户信息
			SysUser sysUser = (SysUser) request.getSession().getAttribute("userBean");
			if (sysUser == null) {
				resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
				resmap.put("error", "操作用户不存在");
				return JSON.toJSONString(resmap);
			}
			agreement.setCreater(sysUser.getUserId());
			agreementService.addAgreement(agreement);
			resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 修改协议
	 * @param @param agreement
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/updateAgreement", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String updateAgreement(Agreement agreement) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			// 从session中获取登录用户名称，用来查询用户信息
			SysUser sysUser = (SysUser) request.getSession().getAttribute("userBean");
			if (sysUser == null) {
				resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
				resmap.put("error", "操作用户不存在");
				return JSON.toJSONString(resmap);
			}
			agreement.setLastUpdater(sysUser.getUserId());
			agreementService.updateAgreement(agreement);
			resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}

	/**
	 * 
	 * @Description: 删除协议
	 * @param @param id
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/deleteAgreement", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String deleteAgreement(String id) {
		Map<String, Object> resmap = new HashMap<String, Object>();
		try {
			agreementService.deleteAgreement(id);
			resmap.put("status", AdminConstant.RETURN_STATUS_SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			resmap.put("status", AdminConstant.RETURN_STATUS_FAIL);
			resmap.put("error", e.getMessage());
		}
		return JSON.toJSONString(resmap);
	}
}
