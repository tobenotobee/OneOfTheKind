/**    
 * @Title: CommentServiceImpl.java  
 * @Package: cn.bluemobi.admin.service.impl  
 * @Description: 评价Service接口实现类
 * @Author: huh
 * @Date: 2015年10月20日 下午4:52:28  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.CommentMapper;
import cn.bluemobi.admin.model.Comment;
import cn.bluemobi.admin.service.CommentService;

/**
 * @ClassName: CommentServiceImpl
 * @Description: 评价Service接口实现
 * @author huh
 * @date 2015年10月20日 下午4:52:28
 * 
 */
@Service("commentService")
public class CommentServiceImpl implements CommentService {

	@Autowired
	private CommentMapper commentMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.CommentService#getCommentForPage(java.util
	 * .Map)
	 */
	@Override
	public List<Comment> getCommentForPage(Map<String, Object> paramap) {
		return commentMapper.getCommentForPage(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.CommentService#getCommentCount(java.util
	 * .Map)
	 */
	@Override
	public long getCommentCount(Map<String, Object> paramap) {
		return commentMapper.getCommentCount(paramap);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.admin.service.CommentService#updateComment(java.lang.
	 * String)
	 */
	@Override
	public void updateComment(String id) {
		commentMapper.updateComment(id);
	}

}
