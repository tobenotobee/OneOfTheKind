package cn.bluemobi.admin.util;

import java.util.HashMap;
import java.util.Map;

/***
 * 分页工具类
 * @author hug
 *
 */
public class PageUtil {

	/**
	 * 构建分页map
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public static Map<String,Object> getQueryMapForPage(int pageNo,int pageSize){
		
		if(pageNo<=0){
			pageNo = 1;
		}
		if(pageSize<=0){
			pageSize = 10;
		}
		int startNo = (pageNo-1)*pageSize;
		Map<String,Object> paramap = new HashMap<String,Object>();
		paramap.put("startNo", startNo);
		paramap.put("pageSize", pageSize);
		
		return paramap;
	}
	
}
