/**    
 * @Title: LoginUserMapper.java  
 * @Package: cn.bluemobi.admin.dao.mybatis  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月17日 下午7:41:52  
 * @Version V1.0    
 */

package cn.bluemobi.admin.dao.mybatis;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.LoginUser;

/**
 * @ClassName: LoginUserMapper
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月17日 下午7:41:52
 * 
 */
public interface LoginUserMapper {

	/**
	 * 
	 * @Description: 获取会员列表+分页
	 * @param paramap
	 * @return
	 * @throws
	 */
	public List<LoginUser> getLoginUserList(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取会员总记录数
	 * @param paramap
	 * @return
	 * @throws
	 */
	public long getLoginUserCount(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 删除会员
	 * @param id
	 * @throws
	 */
	public void deleteLoginUser(String id);

	/**
	 * 
	 * @Description: 获取登录帐号信息
	 * @param id
	 * @return
	 * @throws
	 */
	public LoginUser getLoginUserById(String id);

}
