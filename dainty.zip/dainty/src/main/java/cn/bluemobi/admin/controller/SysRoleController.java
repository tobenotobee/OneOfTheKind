package cn.bluemobi.admin.controller;

import static cn.bluemobi.admin.constant.AdminConstant.RETURN_STATUS_FAIL;
import static cn.bluemobi.admin.constant.AdminConstant.RETURN_STATUS_SUCCESS;
import static cn.bluemobi.admin.constant.AdminConstant.SYS_AUTH_ROOT_ID;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.bluemobi.admin.model.SysRole;
import cn.bluemobi.admin.model.SysRoleAuth;
import cn.bluemobi.admin.service.SysRoleAuthService;
import cn.bluemobi.admin.service.SysRoleService;
import cn.bluemobi.admin.util.PageUtil;
import cn.bluemobi.admin.vo.SysTreeJson;

import com.alibaba.fastjson.JSON;

/***
 * 
 * 角色管理controller
 * @author hug
 *
 */
@Controller
@RequestMapping("/admin/sysRole")
public class SysRoleController {

	@Autowired
	private SysRoleService sysRoleService;  //角色管理service
	
	@Autowired
	private SysRoleAuthService sysRoleAuthService;  //角色权限关系service
	
	/**
	 * 跳转角色管理页面
	 * @return
	 */
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public String roleList(){
		
		return "sysRole/roleList";
	}
	
	/**
	 * 分页查询角色信息
	 * @param pageNo
	 * @param pageSize
	 * @param roleName
	 * @return
	 */
	@RequestMapping(value="/getRoleList",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String getRoleList(@RequestParam("page")int pageNo,
			@RequestParam("rows")int pageSize,String roleName){
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		Map<String,Object> paramap = PageUtil.getQueryMapForPage(pageNo, pageSize);
		if(null!=roleName&&!"".equals(roleName)){
			
			paramap.put("roleName", roleName);
			
		}

		List<SysRole> roleList = sysRoleService.getSysRoleForPage(paramap);
		long totalCount = sysRoleService.getSysRoleCount(paramap);
		if(roleList==null){
			resMap.put("total", 0);
			resMap.put("rows", new ArrayList<SysRole>());
		}else{
			resMap.put("total", totalCount);
			resMap.put("rows", roleList);
		}
		
		String res = JSON.toJSONString(resMap);
		
		return res;
		
	}
	
	/**
	 * 新增角色信息
	 * @return
	 */
	@RequestMapping(value="/addRole",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String addRole(SysRole sysRole){
		
		Map<String,Object> resMap = new HashMap<String, Object>();
		try {
			
			sysRoleService.insertSysRole(sysRole);
			resMap.put("status", RETURN_STATUS_SUCCESS);
			
		} catch (Exception e) {
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
		}
		
		return JSON.toJSONString(resMap);
		
	}
	
	/**
	 * 修改角色信息
	 * @return
	 */
	@RequestMapping(value="/updateRole",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String updateRole(SysRole sysRole){
		
		Map<String,Object> resMap = new HashMap<String, Object>();
		try {
			
			sysRoleService.updateSysRole(sysRole);
			resMap.put("status", RETURN_STATUS_SUCCESS);
			
		} catch (Exception e) {
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
		}
		
		return JSON.toJSONString(resMap);
		
	}
	
	/**
	 * 删除角色信息
	 * @param roleId
	 * @return
	 */
	@RequestMapping(value="/deleteRole",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String deleteRole(long roleId){
		
		Map<String,Object> resMap = new HashMap<String, Object>();
		try {
			if(roleId != 14){
				sysRoleService.deleteSysRole(roleId);
				resMap.put("status", RETURN_STATUS_SUCCESS);
			}else{
				resMap.put("status", RETURN_STATUS_FAIL);
				resMap.put("error", "不允许删除此角色！");
			}
		} catch (Exception e) {
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
		}
		
		return JSON.toJSONString(resMap);
		
	}
	
	/**
	 * 根据角色ID构建权限树
	 * @return
	 */
	@RequestMapping(value="/getRoleAuth",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String getRoleAuth(long roleId){
		
		List<SysRoleAuth> roleAuthList = sysRoleAuthService.selectRoleAuth(roleId,SYS_AUTH_ROOT_ID);
		List<SysTreeJson> authTree = sysRoleAuthService.getAuthTreeJson(roleAuthList, roleId);
		String res = JSON.toJSONString(authTree);
		//System.out.println(res);
		return res;
		
	}
	
	/**
	 * 设置角色权限
	 * @return
	 */
	@RequestMapping(value="/setRoleAuth",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String setRoleAuth(long roleId,String checkIds,String indeIds){
		
		Map<String,Object> resMap = new HashMap<String, Object>();
		try {
			
			sysRoleService.setRoleAuth(roleId, checkIds,indeIds);
			resMap.put("status", RETURN_STATUS_SUCCESS);
			
		} catch (Exception e) {
			e.printStackTrace();
			resMap.put("status", RETURN_STATUS_FAIL);
			resMap.put("error", e.getMessage());
		}
		
		return JSON.toJSONString(resMap);
	}
	
	/**
	 * 获取所有角色信息
	 * @return
	 */
	@RequestMapping(value="/getAllRole",method=RequestMethod.POST,produces="text/plain;charset=UTF-8")
	public @ResponseBody String getAllRole(){
		
		List<SysRole> roleList = sysRoleService.getAllRole();
		if(roleList==null){
			roleList = new ArrayList<SysRole>();
		}
		return JSON.toJSONString(roleList);
	}
	
}
