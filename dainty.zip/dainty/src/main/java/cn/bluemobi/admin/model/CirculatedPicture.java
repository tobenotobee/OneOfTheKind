/**    
 * @Title: CirculatedPicture.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: 轮播图实体类
 * @Author: huh
 * @Date: 2015年10月14日 上午9:36:05  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

import java.util.Date;

import cn.bluemobi.admin.constant.AdminConstant;
import cn.bluemobi.admin.util.CalendarUtil;

/**
 * @ClassName: CirculatedPicture
 * @Description: 轮播图实体
 * @author huh
 * @date 2015年10月14日 上午9:36:05
 * 
 */
public class CirculatedPicture {

	private String id;
	private String title;
	private Integer sort;
	private Integer state;
	private String stateStr;
	private Integer type;
	private String typeStr;
	private String refId;
	private String remark;
	private String creator;
	private String creatorStr;
	private Date createTime;
	private String createTimeStr;
	private String lastModUser;
	private Date lastModTime;
	private String imgUrl;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getStateStr() {
		if (state == null)
			return "";
		if (state == AdminConstant.STATUS_ENABLE)
			return "开启";
		else
			return "关闭";
	}

	public void setStateStr(String stateStr) {
		this.stateStr = stateStr;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getTypeStr() {
		return typeStr;
	}

	public void setTypeStr(String typeStr) {
		this.typeStr = typeStr;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastModUser() {
		return lastModUser;
	}

	public void setLastModUser(String lastModUser) {
		this.lastModUser = lastModUser;
	}

	public Date getLastModTime() {
		return lastModTime;
	}

	public void setLastModTime(Date lastModTime) {
		this.lastModTime = lastModTime;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getCreateTimeStr() {
		if (createTime != null)
			return CalendarUtil.formatDate(createTime);
		else
			return "";
	}

	public String getCreatorStr() {
		return creatorStr;
	}

	public void setCreatorStr(String creatorStr) {
		this.creatorStr = creatorStr;
	}

}
