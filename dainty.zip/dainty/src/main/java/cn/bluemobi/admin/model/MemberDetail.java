/**    
 * @Title: MemberDetail.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月17日 下午7:30:20  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

import java.util.Date;

import cn.bluemobi.admin.util.CalendarUtil;

/**
 * @ClassName: MemberDetail
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月17日 下午7:30:20
 * 
 */
public class MemberDetail {

	private String id;
	private String loginId;
	private String nickName;
	private Byte gender;
	private String cityId;
	private String contactNumber;
	private Date lastModTime;
	private String loginName;
	private Byte loginType;
	private String tpName;
	private Date registeredTime;
	private Date lastActiveTime;
	private String registeredTimeStr;
	private Integer state;
	private String stateStr;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public Byte getGender() {
		return gender;
	}

	public void setGender(Byte gender) {
		this.gender = gender;
	}

	public String getCityId() {
		return cityId;
	}

	public void setCityId(String cityId) {
		this.cityId = cityId;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Date getLastModTime() {
		return lastModTime;
	}

	public void setLastModTime(Date lastModTime) {
		this.lastModTime = lastModTime;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public Byte getLoginType() {
		return loginType;
	}

	public void setLoginType(Byte loginType) {
		this.loginType = loginType;
	}

	public String getTpName() {
		return tpName;
	}

	public void setTpName(String tpName) {
		this.tpName = tpName;
	}

	public Date getRegisteredTime() {
		return registeredTime;
	}

	public void setRegisteredTime(Date registeredTime) {
		this.registeredTime = registeredTime;
	}

	public Date getLastActiveTime() {
		return lastActiveTime;
	}

	public void setLastActiveTime(Date lastActiveTime) {
		this.lastActiveTime = lastActiveTime;
	}

	public String getRegisteredTimeStr() {
		if (registeredTime != null)
			return CalendarUtil.formatDate(registeredTime);
		else
			return registeredTimeStr;
	}

	public void setRegisteredTimeStr(String registeredTimeStr) {
		this.registeredTimeStr = registeredTimeStr;
	}

	public Integer getState() {
		return state;
	}

	public String getStateStr() {
		return stateStr;
	}

}
