package cn.bluemobi.admin.vo;

import java.util.List;

/***
 * 权限json对象vo
 * @author hug
 *
 */
public class SysAuthJson {

	private Long authId;   //权限ID
	
	private String authName;  //权限名称
	
	private String authType;  //权限类型
	
	private String authResource;  //权限url
	
	private String state;  //节点是否展开
	
	private String iconCls; //节点图标
	
	private Integer sort;  //排序
	
	private List<SysAuthJson> children;  //子权限集合

	public Long getAuthId() {
		return authId;
	}

	public void setAuthId(Long authId) {
		this.authId = authId;
	}

	public String getAuthName() {
		return authName;
	}

	public void setAuthName(String authName) {
		this.authName = authName;
	}

	public String getAuthType() {
		return authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public String getAuthResource() {
		return authResource;
	}

	public void setAuthResource(String authResource) {
		this.authResource = authResource;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	public String getIconCls() {
		return iconCls;
	}

	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}

	public List<SysAuthJson> getChildren() {
		return children;
	}

	public void setChildren(List<SysAuthJson> children) {
		this.children = children;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}
	
	
}
