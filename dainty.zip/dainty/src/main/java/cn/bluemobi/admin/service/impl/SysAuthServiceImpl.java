package cn.bluemobi.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.admin.dao.mybatis.SysAuthMapper;
import cn.bluemobi.admin.model.SysAuth;
import cn.bluemobi.admin.service.SysAuthService;
import cn.bluemobi.admin.vo.SysAuthJson;

/***
 * 用户权限管理服务实现
 * @author hug
 *
 */
@Service
public class SysAuthServiceImpl implements SysAuthService {

	@Autowired
	private SysAuthMapper sysAuthMapper;  //权限数据访问mapper
	
	@Override
	public void insertSysAuth(SysAuth sysAuth) {
		
		sysAuthMapper.insertSysAuth(sysAuth);
		
	}

	@Override
	public void updateSysAuth(SysAuth sysAuth) {
		
		sysAuthMapper.updateSysAuth(sysAuth);
		
	}

	@Override
	public SysAuth getSysAuth(long authId) {
		
		return sysAuthMapper.getSysAuth(authId);
		
	}

	@Override
	public void deleteSysAuth(String[] authIds) {
		
		sysAuthMapper.deleteSysAuth(authIds);
		
	}

	@Override
	public List<SysAuth> getAllSysAuth() {
		
		return sysAuthMapper.getAllSysAuth();
		
	}

	@Override
	public List<SysAuth> getChildSysAuth(long authId) {
		
		return sysAuthMapper.getChildSysAuth(authId);
		
	}
	
	@Override
	public List<SysAuthJson> getAllAuthJson(List<SysAuth> authList){
		
		
		List<SysAuthJson> authJsonList = null;
		if(authList!=null){
			authJsonList = new ArrayList<SysAuthJson>();
			for (SysAuth sysAuth : authList) {
				
				SysAuthJson  authJson = new SysAuthJson();
				authJson.setAuthId(sysAuth.getAuthId());
				authJson.setAuthName(sysAuth.getAuthName());
				authJson.setAuthResource(sysAuth.getAuthResource());
				authJson.setAuthType(sysAuth.getAuthType());
				authJson.setSort(sysAuth.getSort());
				List<SysAuth> childAuthList = getChildSysAuth(sysAuth.getAuthId());
				if(childAuthList!=null&&childAuthList.size()>0){
					authJson.setChildren(getAllAuthJson(childAuthList));
					authJson.setState("closed");
				}
				
				authJsonList.add(authJson);
				
			}
			
		}
		
		return authJsonList;
		
	}

	@Override
	public List<SysAuthJson> getAllAuthJson(List<SysAuth> authList,String [] openIdArray){
		
		
		List<SysAuthJson> authJsonList = null;
		if(authList!=null){
			authJsonList = new ArrayList<SysAuthJson>();
			for (SysAuth sysAuth : authList) {
				
				SysAuthJson  authJson = new SysAuthJson();
				authJson.setAuthId(sysAuth.getAuthId());
				authJson.setAuthName(sysAuth.getAuthName());
				authJson.setAuthResource(sysAuth.getAuthResource());
				authJson.setAuthType(sysAuth.getAuthType());
				authJson.setSort(sysAuth.getSort());
				List<SysAuth> childAuthList = getChildSysAuth(sysAuth.getAuthId());
				if(childAuthList!=null&&childAuthList.size()>0){
					authJson.setChildren(getAllAuthJson(childAuthList,openIdArray));
					authJson.setState("closed");
				}
				for (String openId : openIdArray) {
					
					if(sysAuth.getAuthId()==Long.parseLong(openId)){
						authJson.setState("open");
						break;
					}
					
				}
				
				authJsonList.add(authJson);
				
			}
			
		}
		
		return authJsonList;
		
	}
	
	@Override
	public List<Map<String,Object>> getAllAuthJsonMap(List<SysAuth> authList){
		
		List<Map<String,Object>> mapList = new ArrayList<Map<String,Object>>();
		
		if(authList!=null){
			
			for (SysAuth sysAuth : authList) {
				
				Map<String,Object> treeData = new HashMap<String, Object>();
				treeData.put("authId",sysAuth.getAuthId());
				treeData.put("authName", sysAuth.getAuthName());
				treeData.put("authResource", sysAuth.getAuthResource());
				treeData.put("authType", sysAuth.getAuthType());
				
				List<SysAuth> childAuthList = getChildSysAuth(sysAuth.getAuthId());
				if(childAuthList!=null&&childAuthList.size()>0){
					treeData.put("state", "closed");
					treeData.put("children", getAllAuthJson(childAuthList));
					
				}
				mapList.add(treeData);
			}
			
		}
		
		return mapList;
	}

	@Override
	public List<SysAuth> getAuthByRoleId(long roleId) {
		return sysAuthMapper.getAuthByRoleId(roleId);
	}
	
}
