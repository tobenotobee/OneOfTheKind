package cn.bluemobi.admin.constant;

/***
 * 后台管理常量类
 * 
 * @author hug
 *
 */
public class AdminConstant {

	public final static int RETURN_STATUS_FAIL = 0;  // 请求返回状态失败

	public final static int RETURN_STATUS_SUCCESS = 1; // 请求返回状态成功

	public final static long SYS_AUTH_ROOT_ID = 0;  // 权限rootID

	public final static int TREE_CHECK_TYPE_INDETERMINATE = 0;  // 树节点选中类型，半选

	public final static int TREE_CHECK_TYPE_CHECKED = 1;  // 树节点选中类型，选中

	public final static String SYS_SECURITY_ROLE_PREIFX = "ROLE_";  // 系统角色前缀

	public final static int SYS_USER_ENABLE_YES = 0;  // 用户可用

	public final static int SYS_USER_ENABLE_NO = 1;  // 用户禁用

	public final static int SYS_USER_ROLE_IS_ADMIN = 1;  // 超级用户

	/************************ 系统管理 end ******************************/

	public final static int STATUS_ENABLE = 1; // 启用标识

	// 图片文件夹名称
	public final static String IMGFILE__CIRCULATED_PICTURE_DIR = "circulatedPicture";
	
	public final static String IMGTYPE__CIRCULATED_PICTURE = "CP";

}
