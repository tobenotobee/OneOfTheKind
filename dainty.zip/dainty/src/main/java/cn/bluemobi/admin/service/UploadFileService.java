/**    
 * @Title: UploadFileService.java  
 * @Package: cn.bluemobi.admin.service
 * @Description: 文件上传service接口类
 * @Author: huh
 * @Date: 2015年10月9日 下午4:07:16  
 * @Version V1.0    
 */
package cn.bluemobi.admin.service;

import java.io.File;
import java.io.InputStream;
import java.util.List;

/**
 * 
 * @ClassName: UploadFileService
 * @Description: 文件上传service接口
 * @author huh
 * @date 2015年10月9日 下午4:25:46
 *
 */
public interface UploadFileService {
	/**
	 * 得到文件保存路径
	 * 
	 * @return
	 */
	public String getFileSavePath();

	/**
	 * 得到文件http路径
	 * 
	 * @return
	 */
	public String getFileHttpPath();

	/**
	 * 上传文件
	 * 
	 * @param file
	 *                文件字节流
	 * @param filePath
	 *                文件的分类路径
	 * @param fileName
	 *                文件名，包括文件类型后缀
	 * @return
	 */
	public void uploadFile(byte[] file, String filePath, String fileName) throws Exception;

	/**
	 * 上传文件
	 * 
	 * @param file
	 * @param filePath
	 * @param fileName
	 * @throws Exception
	 */
	public void uploadFile(File file, String filePath, String fileName) throws Exception;

	/**
	 * 上传文件 带缩一张略图
	 * 
	 * @param fileInputStream
	 * @param file
	 * @param filePath
	 * @param fileName
	 * @throws Exception
	 */
	public void uploadFile(InputStream fileInputStream, byte[] file, String filePath, String fileName, int fileCount)
					throws Exception;

	/**
	 * 删除指定图片
	 * 
	 * @param filePaths
	 *                图片相对路径数组
	 */
	public void deleteUploadFile(String[] filePaths);

	/**
	 * 删除指定图片
	 * 
	 * @param filePaths
	 *                图片相对路径数组
	 */
	public void deleteUploadFile(List<String> filePaths);

}
