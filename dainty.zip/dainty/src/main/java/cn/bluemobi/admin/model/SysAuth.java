package cn.bluemobi.admin.model;

import java.io.Serializable;

/***
 * 用户权限信息实体
 * @author hug
 *
 */

public class SysAuth implements Serializable{

	private Long authId;  //权限ID
	private String authName;  //权限名称
	private Long parentId;  //上级权限ID
	private String authType; //权限类型 ：menu function
	private String authResource; //权限url
	private Integer sort;  //权限排序字段

	public Long getAuthId() {
		return authId;
	}

	public void setAuthId(Long authId) {
		this.authId = authId;
	}

	public String getAuthName() {
		return authName;
	}

	public void setAuthName(String authName) {
		this.authName = authName;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public String getAuthType() {
		return authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public String getAuthResource() {
		return authResource;
	}

	public void setAuthResource(String authResource) {
		this.authResource = authResource;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	
}