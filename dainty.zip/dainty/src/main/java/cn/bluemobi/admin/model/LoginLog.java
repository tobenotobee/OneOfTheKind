/**    
 * @Title: LoginLog.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: 后台用户登录日志类
 * @Author: huh
 * @Date: 2015年10月20日 下午4:16:34  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

import java.util.Date;

import cn.bluemobi.admin.util.CalendarUtil;

/**
 * @ClassName: LoginLog
 * @Description: 后台用户登录日志
 * @author huh
 * @date 2015年10月20日 下午4:16:34
 * 
 */
public class LoginLog {

	private String id;
	private String userName;
	private Date loginTime;
	private String loginTimeStr;
	private String loginIp;
	private String deptName;
	private String roleName;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(Date loginTime) {
		this.loginTime = loginTime;
	}

	public String getLoginTimeStr() {
		if (loginTime == null)
			return "";
		else
			return CalendarUtil.formatDate(loginTime);

	}

	public void setLoginTimeStr(String loginTimeStr) {
		this.loginTimeStr = loginTimeStr;
	}

	public String getLoginIp() {
		return loginIp;
	}

	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

}
