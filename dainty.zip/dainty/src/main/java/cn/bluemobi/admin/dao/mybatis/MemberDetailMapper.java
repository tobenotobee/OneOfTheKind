/**    
 * @Title: MemberDetailMapper.java  
 * @Package: cn.bluemobi.admin.dao.mybatis  
 * @Description: TODO desc
 * @Author: huh
 * @Date: 2015年11月17日 下午7:34:18  
 * @Version V1.0    
 */

package cn.bluemobi.admin.dao.mybatis;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.MemberDetail;

/**
 * @ClassName: MemberDetailMapper
 * @Description: TODO desc
 * @author huh
 * @date 2015年11月17日 下午7:34:18
 * 
 */
public interface MemberDetailMapper {

	/**
	 * 
	 * @Description: 获取会员列表+分页
	 * @param paramap
	 * @return
	 * @throws
	 */
	public List<MemberDetail> getMemberList(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取会员总记录数
	 * @param paramap
	 * @return
	 * @throws
	 */
	public long getMembersCount(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 删除会员
	 * @param id
	 * @throws
	 */
	public void deleteMemberDetail(String id);

}
