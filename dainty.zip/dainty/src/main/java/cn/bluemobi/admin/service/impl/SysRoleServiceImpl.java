package cn.bluemobi.admin.service.impl;

import static cn.bluemobi.admin.constant.AdminConstant.SYS_SECURITY_ROLE_PREIFX;
import static cn.bluemobi.admin.constant.AdminConstant.TREE_CHECK_TYPE_CHECKED;
import static cn.bluemobi.admin.constant.AdminConstant.TREE_CHECK_TYPE_INDETERMINATE;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.bluemobi.admin.dao.mybatis.SysRoleAuthMapper;
import cn.bluemobi.admin.dao.mybatis.SysRoleMapper;
import cn.bluemobi.admin.dao.mybatis.SysUserMapper;
import cn.bluemobi.admin.model.SysRole;
import cn.bluemobi.admin.model.SysRoleAuth;
import cn.bluemobi.admin.security.SecurityMetadataSourceService;
import cn.bluemobi.admin.service.SysRoleService;

/***
 * 角色信息管理服务实现
 * @author hug
 *
 */
@Service
public class SysRoleServiceImpl implements SysRoleService {

	@Autowired
	private SysRoleMapper sysRoleMapper; //角色信息数据访问
	
	@Autowired
	private SysRoleAuthMapper sysRoleAuthMapper;  //角色权限关系数据访问
	
	@Autowired
	private SysUserMapper sysUserMapper;  //用户数据访问
	
	@Autowired
	private SecurityMetadataSourceService securityMetadataSourceService;
	
	@Override
	public void insertSysRole(SysRole sysRole) {
		String roleCode =UUID.randomUUID().toString();
		roleCode = roleCode.replaceAll("-","");
		sysRole.setRoleCode(SYS_SECURITY_ROLE_PREIFX+roleCode.toUpperCase());
		sysRoleMapper.insertSysRole(sysRole);
	}

	@Override
	public void updateSysRole(SysRole sysRole) {
		sysRoleMapper.updateSysRole(sysRole);
	}

	@Override
	public SysRole getSysRole(long roleId) {
		return sysRoleMapper.getSysRole(roleId);
	}

	@Override
	@Transactional
	public void deleteSysRole(long roleId) {
		
		sysRoleMapper.deleteSysRole(roleId);
		sysRoleAuthMapper.deleteByRoleId(roleId);
		sysUserMapper.updateSysUserRoleToNull(roleId);
		
	}

	@Override
	public List<SysRole> getSysRoleForPage(Map<String, Object> paramap) {
		return sysRoleMapper.getSysRoleForPage(paramap);
	}

	@Override
	public long getSysRoleCount(Map<String, Object> paramap) {
		return sysRoleMapper.getSysRoleCount(paramap);
	}
	
	@Override
	@Transactional
	public void setRoleAuth(long roleId,String checkIds,String indeIds){
		
		sysRoleAuthMapper.deleteByRoleId(roleId);
		if(indeIds!=null&&!"".equals(indeIds)){
		
			String [] authIdArray = indeIds.split(",");
			if(authIdArray!=null&&authIdArray.length>0){
				List<SysRoleAuth> sysRoleAuthList = new ArrayList<SysRoleAuth>();
				for (String authIdStr : authIdArray) {
					SysRoleAuth roleAuth = new SysRoleAuth();
					roleAuth.setRoleId(roleId);
					roleAuth.setAuthId(Long.parseLong(authIdStr));
					roleAuth.setCheckType(TREE_CHECK_TYPE_INDETERMINATE);
					sysRoleAuthList.add(roleAuth);
				}
				
				sysRoleAuthMapper.insertSysRoleAuthList(sysRoleAuthList);
			}
		}
		if(checkIds!=null&&!"".equals(checkIds)){
			
			String [] authIdArray = checkIds.split(",");
			if(authIdArray!=null&&authIdArray.length>0){
				List<SysRoleAuth> sysRoleAuthList = new ArrayList<SysRoleAuth>();
				for (String authIdStr : authIdArray) {
					SysRoleAuth roleAuth = new SysRoleAuth();
					roleAuth.setRoleId(roleId);
					roleAuth.setAuthId(Long.parseLong(authIdStr));
					roleAuth.setCheckType(TREE_CHECK_TYPE_CHECKED);
					sysRoleAuthList.add(roleAuth);
				}
				sysRoleAuthMapper.insertSysRoleAuthList(sysRoleAuthList);
			}
		}
		
		securityMetadataSourceService.loadRoleAuthInfo(); //更新系统角色权限列表
		
	}

	@Override
	public List<SysRole> getAllRole() {
		return sysRoleMapper.getAllRole();
	}

}
