package cn.bluemobi.admin.dao.mybatis;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.SysRoleAuth;

/***
 * 角色权限关系Mapper
 * @author hug
 *
 */
public interface SysRoleAuthMapper {

	/**
	 * 新增角色权限关系
	 * @param sysRoleAuth
	 * @return
	 */
	public int insertSysRoleAuth(SysRoleAuth sysRoleAuth);
	
	/**
	 * 批量新增角色权限关系
	 * @param sysRoleAuthList
	 * @return
	 */
	public int insertSysRoleAuthList(List<SysRoleAuth> sysRoleAuthList);
	
	/**
	 * 根据角色删除对应的权限关系信息
	 * @param roleId
	 * @return
	 */
	public int deleteByRoleId(long roleId);
	
	/**
	 * 根据角色获取权限
	 * @param paramap
	 * @return
	 */
	public List<SysRoleAuth> selectRoleAuth(Map<String,Object> paramap);
}
