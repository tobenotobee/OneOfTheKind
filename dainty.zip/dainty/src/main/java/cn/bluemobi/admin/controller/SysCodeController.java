/**    
 * @Title: SysCodeController.java  
 * @Package: cn.bluemobi.admin.controller  
 * @Description: 获取系统code类
 * @Author: huh
 * @Date: 2015年10月14日 下午1:11:39  
 * @Version V1.0    
 */

package cn.bluemobi.admin.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;

import cn.bluemobi.admin.constant.AdminConstant;
import cn.bluemobi.admin.model.SysCode;
import cn.bluemobi.admin.service.SysCodeService;

/**
 * @ClassName: SysCodeController
 * @Description: 获取系统code
 * @author huh
 * @date 2015年10月14日 下午1:11:39
 * 
 */
@Controller
@RequestMapping(value = "/admin/sysCode")
public class SysCodeController {

	@Autowired
	private SysCodeService sysCodeService;// 系统编码service

	@Autowired
	private HttpServletRequest request; // request 用来获取application

	/**
	 * 
	 * @Description: 根据code获取编码列表
	 * @param @param code
	 * @param @return
	 * @return
	 * @throws
	 */
	@RequestMapping(value = "/getSysCode", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public @ResponseBody String getSysCode(String code) {
		/**
		 * Map<String, String> paramap = new HashMap<String, String>();
		 * paramap.put("status",
		 * String.valueOf(AdminConstant.STATUS_ENABLE)); List<SysCode>
		 * codeList = sysCodeService.getSysCodeByCode(paramap); if
		 * (codeList == null || codeList.size() < 1) { return
		 * "{\"status\":" + AdminConstant.RETURN_STATUS_FAIL +
		 * ",\"error\":\"加载列表信息错误\"}"; }
		 */
		ServletContext servletContext = request.getSession().getServletContext();
		List<SysCode> codeList = (List<SysCode>) servletContext.getAttribute(code);
		if (codeList == null || codeList.size() < 1) {
			return "{\"status\":" + AdminConstant.RETURN_STATUS_FAIL + ",\"error\":\"加载列表信息错误\"}";
		}
		return JSON.toJSONString(codeList);
	}
}
