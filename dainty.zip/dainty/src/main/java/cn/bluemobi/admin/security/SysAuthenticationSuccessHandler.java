package cn.bluemobi.admin.security;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;

import cn.bluemobi.admin.model.SysUser;
import cn.bluemobi.admin.service.LoginLogService;
import cn.bluemobi.admin.service.SysUserService;
import cn.bluemobi.admin.util.IpAddressUtil;

/***
 * 自定义认证成功后的操作类
 * @author hug
 *
 */
public class SysAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {
	
	@Autowired
	private SysUserService sysUserService;  //后台用户信息管理service
	@Autowired
	private LoginLogService loginLogService;  //日志service
	
	@Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
            Authentication authentication) throws ServletException, IOException {
		Object user = authentication.getPrincipal();
		String userName = ((UserDetails)user).getUsername();
		SysUser sysUser = new SysUser();
		sysUser.setUserName(userName);
		sysUser.setLastLoginDate(new Date());
		sysUserService.updateSysUserByUserName(sysUser);
		//登录成功后用户信息存储在session中
		SysUser sessonSysUser = sysUserService.getSysUserByName(userName);
		request.getSession().setAttribute("userBean", sessonSysUser);
		//存储在数据库日志中
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("user_id", sessonSysUser.getUserId());
		map.put("login_ip",IpAddressUtil.getIpAddr(request));
		map.put("login_time",sessonSysUser.getLastLoginDate());
		loginLogService.insertLoginLog(map);
		super.onAuthenticationSuccess(request, response, authentication);
	}
}
