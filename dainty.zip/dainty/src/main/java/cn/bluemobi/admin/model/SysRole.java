package cn.bluemobi.admin.model;

import java.io.Serializable;
/***
 * 用户角色实体
 * @author hug
 *
 */
public class SysRole implements Serializable{

	private Long roleId;  //角色ID
	private String roleName;  //角色名称
	private String roleDesc;  //角色描述
	private String roleCode;  //角色编码
	private Integer isAdmin;  //是否是超级用户

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public Integer getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Integer isAdmin) {
		this.isAdmin = isAdmin;
	}

}