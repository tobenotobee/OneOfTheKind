/**    
 * @Title: AreaService.java  
 * @Package: cn.bluemobi.admin.service  
 * @Description: 区域service接口类
 * @Author: huh
 * @Date: 2015年11月17日 下午5:14:41  
 * @Version V1.0    
 */

package cn.bluemobi.admin.service;

import java.util.List;
import java.util.Map;

import cn.bluemobi.admin.model.Area;

/**
 * @ClassName: AreaService
 * @Description: 区域service接口类
 * @author huh
 * @date 2015年11月17日 下午5:14:41
 * 
 */
public interface AreaService {

	/**
	 * 
	 * @Description: 新增区域
	 * @param area
	 * @throws
	 */
	public void addArea(Area area);

	/**
	 * 
	 * @Description:获取区域列表+分页
	 * @param paramap
	 * @return
	 * @throws
	 */
	public List<Area> getAreasForPage(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 获取区域总记录数
	 * @param paramap
	 * @return
	 * @throws
	 */
	public long getAreasCount(Map<String, Object> paramap);

	/**
	 * 
	 * @Description: 删除区域
	 * @param id
	 * @throws
	 */
	public void deleteArea(String id);

	/**
	 * 
	 * @Description: 获取当前最大排序号
	 * @return
	 * @throws
	 */
	public Integer getMaxSort();
}
