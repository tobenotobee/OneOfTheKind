package cn.bluemobi.admin.vo;

import java.util.List;

/**
 * easyUI tree组件的json数据vo
 * @author hug
 *
 */
public class SysTreeJson {

	private Long id;  //树节点ID
	
	private String text; //树节点名称
	
	private String state;  //树节点是否展开
	
	private Boolean checked; //树节点是否被选中
	
	private List<SysTreeJson> children; //子节点集合

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Boolean getChecked() {
		return checked;
	}

	public void setChecked(Boolean checked) {
		this.checked = checked;
	}

	public List<SysTreeJson> getChildren() {
		return children;
	}

	public void setChildren(List<SysTreeJson> children) {
		this.children = children;
	}
	
}
