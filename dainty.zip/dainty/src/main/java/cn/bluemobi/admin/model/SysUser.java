package cn.bluemobi.admin.model;

import static cn.bluemobi.admin.constant.AdminConstant.SYS_USER_ENABLE_YES;

import java.io.Serializable;
import java.util.Date;

import cn.bluemobi.admin.util.CalendarUtil;

/***
 * 系统用户信息实体
 * @author hug
 *
 */
public class SysUser implements Serializable{

	private String userId; //用户主键ID
	private String userName; //用户登陆名
	private String password; //密码
	private String realName; //真实姓名
	private Integer status;  //状态是否禁用  1 禁用 0 可用
	private Long roleId;  //用户所属角色ID
	private Date lastLoginDate;  //最后一次登陆时间
	private Date createDate; //用户注册时间
	
	private String roleCode;  //角色编码
	private String roleName;  //角色名称
	private String statusStr;
	private String lastLoginDateStr;
	private Integer isAdmin;
	private String phone;//手机号码
	
	private String sellerStatus;//商户状态（用于商户管理）

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public Date getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(Date lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getStatusStr() {
		if(this.status==null){
			return statusStr;
		}
		if(this.status==SYS_USER_ENABLE_YES){
			return "可用";
		}else{
			return "禁用";
		}
		
	}

	public void setStatusStr(String statusStr) {
		this.statusStr = statusStr;
	}

	public String getLastLoginDateStr() {
		if(this.lastLoginDate==null){
			return lastLoginDateStr;
		}
		return CalendarUtil.formatDate(lastLoginDate);
	}

	public void setLastLoginDateStr(String lastLoginDateStr) {
		this.lastLoginDateStr = lastLoginDateStr;
	}

	public Integer getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Integer isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getSellerStatus() {
		return sellerStatus;
	}

	public void setSellerStatus(String sellerStatus) {
		this.sellerStatus = sellerStatus;
	}
	
}