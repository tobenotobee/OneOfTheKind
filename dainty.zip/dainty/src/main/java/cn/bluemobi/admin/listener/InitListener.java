/**    
 * @Title: InitListener.java  
 * @Package: cn.bluemobi.admin.listener  
 * @Description: 容器启动加载数据类
 * @Author: huh
 * @Date: 2015年10月16日 上午10:48:35  
 * @Version V1.0    
 */

package cn.bluemobi.admin.listener;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import cn.bluemobi.admin.constant.AdminConstant;
import cn.bluemobi.admin.model.SysBaseCode;
import cn.bluemobi.admin.model.SysCode;
import cn.bluemobi.admin.service.SysBaseCodeService;
import cn.bluemobi.admin.service.SysCodeService;

/**
 * @ClassName: InitListener
 * @Description: 容器启动加载数据
 * @author huh
 * @date 2015年10月16日 上午10:48:35
 * 
 */
public class InitListener extends ContextLoaderListener {

	@Autowired
	private SysBaseCodeService sysBaseCodeService;

	@Autowired
	private SysCodeService sysCodeService;

	@Override
	public void contextInitialized(ServletContextEvent event) {
		System.out.println("*************** Init Dictionary Servlet started ***************");
		try {

			ServletContext application = event.getServletContext();
			WebApplicationContext context = WebApplicationContextUtils
							.getWebApplicationContext(application);
			sysBaseCodeService = (SysBaseCodeService) context.getBean("sysBaseCodeService");
			sysCodeService = (SysCodeService) context.getBean("sysCodeService");

			Map<String, String> paramap = new HashMap<String, String>();
			paramap.put("status", AdminConstant.STATUS_ENABLE + "");
			List<SysBaseCode> baseCodeList = sysBaseCodeService.getAllBaseCode();
			for (SysBaseCode sbc : baseCodeList) {
				System.out.println(sbc.getCode());
				paramap.put("code", sbc.getCode());
				List<SysCode> codeList = sysCodeService.getSysCodeByCode(paramap);
				application.setAttribute(sbc.getCode(), codeList);
			}
			System.out.println("*************** Init Dictionary Servlet ended ***************");

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("*************** Init Dictionary Servlet bombed ***************");
		}
	}

	@Override
	public void contextDestroyed(ServletContextEvent event) {
		super.contextDestroyed(event);
	}

}
