/**    
 * @Title: Area.java  
 * @Package: cn.bluemobi.admin.model  
 * @Description: 区域类
 * @Author: huh
 * @Date: 2015年11月17日 下午5:11:06  
 * @Version V1.0    
 */

package cn.bluemobi.admin.model;

import java.util.Date;

import cn.bluemobi.admin.util.CalendarUtil;

/**
 * @ClassName: Area
 * @Description: 区域
 * @author huh
 * @date 2015年11月17日 下午5:11:06
 * 
 */
public class Area {

	private String id;
	private String areaName;
	private String abbr;
	private Integer sort;
	private String creator;
	private Date createTime;
	private String createTimeStr;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public String getAbbr() {
		return abbr;
	}

	public void setAbbr(String abbr) {
		this.abbr = abbr;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreateTimeStr() {
		if (createTime != null)
			return CalendarUtil.formatDate(createTime);
		else
			return createTimeStr;
	}

}
