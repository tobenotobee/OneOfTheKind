/**    
 * @Title: DesEncrypter.java  
 * @Package: cn.bluemobi.site.interceptor  
 * @Description: 文件加密类
 * @Author: huh
 * @Date: 2015年10月26日 下午4:53:24  
 * @Version V1.0    
 */

package cn.bluemobi.site.interceptor;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

/**
 * 
 * @ClassName: DesEncrypter
 * @Description: 文件加密
 * @author huh
 * @date 2015年10月27日 下午3:35:23
 *
 */
public class DesEncrypter {

	Cipher ecipher;
	Cipher dcipher;

	// 8-byte Salt
	byte[] salt = {

	(byte) 0xA9, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x35, (byte) 0xE3, (byte) 0x03

	};

	// Iteration count
	int iterationCount = 19;

	/**
	 * Creates a new DesEncrypter object.
	 *
	 * @param passPhrase
	 *                DOCUMENT ME!
	 *
	 * @throws InvalidKeySpecException
	 *                 DOCUMENT ME!
	 * @throws NoSuchAlgorithmException
	 *                 DOCUMENT ME!
	 * @throws NoSuchPaddingException
	 *                 DOCUMENT ME!
	 * @throws InvalidKeyException
	 *                 DOCUMENT ME!
	 * @throws InvalidAlgorithmParameterException
	 *                 DOCUMENT ME!
	 */
	public DesEncrypter(String passPhrase) throws InvalidKeySpecException, NoSuchAlgorithmException,
					NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException {

		// Create the key
		KeySpec keySpec = new PBEKeySpec(passPhrase.toCharArray(), salt, iterationCount);
		SecretKey key = SecretKeyFactory.getInstance("PBEWithMD5AndDES").generateSecret(keySpec);
		ecipher = Cipher.getInstance(key.getAlgorithm());
		dcipher = Cipher.getInstance(key.getAlgorithm());

		// Prepare the parameter to the ciphers
		AlgorithmParameterSpec paramSpec = new PBEParameterSpec(salt, iterationCount);

		// Create the ciphers
		ecipher.init(Cipher.ENCRYPT_MODE, key, paramSpec);
		dcipher.init(Cipher.DECRYPT_MODE, key, paramSpec);

	}

	private DesEncrypter() {

	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param str
	 *                DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 *
	 * @throws UnsupportedEncodingException
	 *                 DOCUMENT ME!
	 * @throws IllegalStateException
	 *                 DOCUMENT ME!
	 * @throws IllegalBlockSizeException
	 *                 DOCUMENT ME!
	 * @throws BadPaddingException
	 *                 DOCUMENT ME!
	 */
	public String encrypt(String str) throws UnsupportedEncodingException, IllegalStateException,
					IllegalBlockSizeException, BadPaddingException {

		// Encode the string into bytes using utf-8
		byte[] utf8 = str.getBytes("UTF8");

		// Encrypt
		byte[] enc = ecipher.doFinal(utf8);

		// Encode bytes to base64 to get a string
		return this.parseByte2HexStr(enc);

	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param str
	 *                DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 *
	 * @throws IOException
	 *                 DOCUMENT ME!
	 * @throws IllegalStateException
	 *                 DOCUMENT ME!
	 * @throws IllegalBlockSizeException
	 *                 DOCUMENT ME!
	 * @throws BadPaddingException
	 *                 DOCUMENT ME!
	 */
	public String decrypt(String str) throws IOException, IllegalStateException, IllegalBlockSizeException,
					BadPaddingException {

		// Decode base64 to get bytes
		byte[] dec = parseHexStr2Byte(str);

		// Decrypt
		byte[] utf8 = dcipher.doFinal(dec);

		// Decode using utf-8
		return new String(utf8, "UTF8");

	}

	/**
	 * 将二进制转换成16进制
	 * 
	 * @method parseByte2HexStr
	 * @param buf
	 * @return
	 * @throws
	 * @since v1.0
	 */
	public static String parseByte2HexStr(byte buf[]) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < buf.length; i++) {
			String hex = Integer.toHexString(buf[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			sb.append(hex.toUpperCase());
		}
		return sb.toString();
	}

	/**
	 * 将16进制转换为二进制
	 * 
	 * @method parseHexStr2Byte
	 * @param hexStr
	 * @return
	 * @throws
	 * @since v1.0
	 */
	public static byte[] parseHexStr2Byte(String hexStr) {
		if (hexStr.length() < 1)
			return null;
		byte[] result = new byte[hexStr.length() / 2];
		for (int i = 0; i < hexStr.length() / 2; i++) {
			int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
			int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
			result[i] = (byte) (high * 16 + low);
		}
		return result;
	}

	public static void main(String[] args) {
		try {
			DesEncrypter des = new DesEncrypter("weichao");
			String xx = des.encrypt("123456");
			// System.out.println(xx);

			DesEncrypter dess = new DesEncrypter("ec94bf933e090d16bd62b0e97a793b726975a191");

			// System.out.println(dess.decrypt(URLDecoder.decode("knKCj5ZEigsBO82xSd%2Fwak7apww9FO%2FCIGcAf%2FvKNu8%3D",
			// "UTF-8")));
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (InvalidKeySpecException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			e.printStackTrace();
		} catch (BadPaddingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}