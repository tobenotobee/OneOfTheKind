/**    
 * @Title: MemberToken.java  
 * @Package: cn.bluemobi.site.model  
 * @Description: laibatour令牌器token表的对应的Java映射类
 * @Author: huh
 * @Date: 2015年10月27日 上午10:21:11  
 * @Version V1.0    
 */

package cn.bluemobi.site.model;

/**
 * @ClassName: MemberToken
 * @Description: laibatour令牌器token表的对应的Java映射
 * @author huh
 * @date 2015年10月27日 上午10:21:11
 * 
 */
public class MemberToken {

	private String id;
	private String tokenKey;
	private String userId;
	private String loginPhoneType;
	private String aesKey;
	private String rsaPub;
	private String rsaPri;
	private String rsaCreateTime;

	/**
	 * @Description: 构造函数
	 * @param @param tokenKey
	 * @param @param userId
	 * @return
	 * @throws
	 */
	public MemberToken(String tokenKey, String userId) {
		this.tokenKey = tokenKey;
		this.userId = userId;
	}

	/**
	 * @Description: 构造函数
	 * @param @param id
	 * @param @param tokenKey
	 * @param @param userId
	 * @param @param loginPhoneType
	 * @param @param aesKey
	 * @param @param rsaPub
	 * @param @param rsaPri
	 * @param @param rsaCreateTime
	 * @return
	 * @throws
	 */
	public MemberToken(String id, String tokenKey, String userId, String loginPhoneType, String aesKey,
					String rsaPub, String rsaPri, String rsaCreateTime) {
		this.id = id;
		this.tokenKey = tokenKey;
		this.userId = userId;
		this.loginPhoneType = loginPhoneType;
		this.aesKey = aesKey;
		this.rsaPub = rsaPub;
		this.rsaPri = rsaPri;
		this.rsaCreateTime = rsaCreateTime;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTokenKey() {
		return tokenKey;
	}

	public void setTokenKey(String tokenKey) {
		this.tokenKey = tokenKey;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getLoginPhoneType() {
		return loginPhoneType;
	}

	public void setLoginPhoneType(String loginPhoneType) {
		this.loginPhoneType = loginPhoneType;
	}

	public String getAesKey() {
		return aesKey;
	}

	public void setAesKey(String aesKey) {
		this.aesKey = aesKey;
	}

	public String getRsaPub() {
		return rsaPub;
	}

	public void setRsaPub(String rsaPub) {
		this.rsaPub = rsaPub;
	}

	public String getRsaPri() {
		return rsaPri;
	}

	public void setRsaPri(String rsaPri) {
		this.rsaPri = rsaPri;
	}

	public String getRsaCreateTime() {
		return rsaCreateTime;
	}

	public void setRsaCreateTime(String rsaCreateTime) {
		this.rsaCreateTime = rsaCreateTime;
	}

}
