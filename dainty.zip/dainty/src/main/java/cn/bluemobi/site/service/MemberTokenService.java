/**    
 * @Title: MemberTokenService.java  
 * @Package: cn.bluemobi.site.service  
 * @Description: laibatour令牌service接口类
 * @Author: huh
 * @Date: 2015年10月27日 上午10:18:03  
 * @Version V1.0    
 */

package cn.bluemobi.site.service;

import cn.bluemobi.site.model.MemberToken;

/**
 * @ClassName: MemberTokenService
 * @Description: laibatour令牌service接口
 * @author huh
 * @date 2015年10月27日 上午10:18:03
 * 
 */
public interface MemberTokenService {

	/**
	 * 
	 * @Description: 验证这个登录用户是否有效
	 * @param memberToken
	 * @return
	 * @throws
	 */
	public Integer getMemberToken(MemberToken memberToken);

	/**
	 * 
	 * @Description: 在数据库中新插入一条指定的求比特令牌器token记录
	 * @param memberToken
	 * @return
	 * @throws
	 */
	public void insertMemberToken(MemberToken memberToken);

	/**
	 * 
	 * @Description: 在数据库中修改此条求比特令牌器token记录
	 * @param memberToken
	 * @return
	 * @throws
	 */
	public void updateMemberToken(MemberToken memberToken);

}
