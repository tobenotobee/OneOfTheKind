/**    
 * @Title: AppRequestInterceptor.java  
 * @Package: cn.bluemobi.site.interceptor  
 * @Description: APP请求后台拦截器类
 * @Author: huh
 * @Date: 2015年10月27日 上午11:09:09  
 * @Version V1.0    
 */

package cn.bluemobi.site.interceptor;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import cn.bluemobi.site.model.MemberToken;
import cn.bluemobi.site.service.MemberTokenService;
import cn.bluemobi.site.vo.AppData;

/**
 * @ClassName: AppRequestInterceptor
 * @Description: APP请求后台拦截器
 * @author huh
 * @date 2015年10月27日 上午11:09:09
 * 
 */
public class AppRequestInterceptor implements HandlerInterceptor {

	@Autowired
	private MemberTokenService memberTokenService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.HandlerInterceptor#preHandle(javax
	 * .servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		response.setHeader("Content-Type", "application/json; charset=utf-8");// 统一字符编码防止乱码
		try {
			String pjson = request.getParameter("p");
			JSONObject json = JSON.parseObject(pjson);
			String userId = json.getString("memberId");
			String tokeyKey = json.getString("appToken");

			// 判断传入参数是否有值
			if (userId == null || "".equals(userId) || tokeyKey == null || "".equals(tokeyKey)) {
				AppData data = new AppData();
				data.setMsg("会话过期，请注销重新登录。");
				data.setStatus(AppData.RETURN_FAIL);
				response.getWriter().write(JSON.toJSONString(data));
			} else {

				DesEncrypter des = new DesEncrypter("ec94bf933e090d16bd62b0e97a793b726975a191");
				// 加密appCode
				String appCode = des.decrypt(tokeyKey);
				if (appCode != null && appCode.charAt(5) == '9' && appCode.charAt(6) == '2'
								&& appCode.charAt(12) == '4') {
					// 验证是不是当前用户在操作
					if (memberTokenService.getMemberToken(new MemberToken(tokeyKey, userId)) == 0) {
						try {
							String url = request.getRequestURL().toString();
							if (url != null && url.indexOf("deleteAppToken") != -1) {
								return true;
							} else {
								AppData data = new AppData();
								data.setMsg("会话过期，请注销重新登录。");
								data.setStatus(AppData.RETURN_FAIL);
								response.getWriter().write(JSON.toJSONString(data));
							}

						} catch (IOException e) {
							e.printStackTrace();
							return false;
						}
						return false;
					} else {
						return true;
					}
				}
			}
		} catch (InvalidKeyException | InvalidKeySpecException | NoSuchAlgorithmException
						| NoSuchPaddingException | InvalidAlgorithmParameterException e1) {
			e1.printStackTrace();
			try {
				AppData data = new AppData();
				data.setMsg("会话过期，请注销重新登录。");
				data.setStatus(AppData.RETURN_FAIL);
				response.getWriter().write(JSON.toJSONString(data));
			} catch (IOException e) {
				e.printStackTrace();
			}
			return false;
		} catch (IllegalStateException e1) {
			e1.printStackTrace();
			try {
				AppData data = new AppData();
				data.setMsg("会话过期，请注销重新登录。");
				data.setStatus(AppData.RETURN_FAIL);
				response.getWriter().write(JSON.toJSONString(data));
			} catch (IOException e) {
				e.printStackTrace();
			}
			return false;
		} catch (IllegalBlockSizeException e1) {
			e1.printStackTrace();
			try {
				AppData data = new AppData();
				data.setMsg("会话过期，请注销重新登录。");
				data.setStatus(AppData.RETURN_FAIL);
				response.getWriter().write(JSON.toJSONString(data));
			} catch (IOException e) {
				e.printStackTrace();
			}
			return false;
		} catch (BadPaddingException e1) {
			e1.printStackTrace();
			try {
				AppData data = new AppData();
				data.setMsg("会话过期，请注销重新登录。");
				data.setStatus(AppData.RETURN_FAIL);
				response.getWriter().write(JSON.toJSONString(data));
			} catch (IOException e) {
				e.printStackTrace();
			}
			return false;
		} catch (IOException e1) {
			e1.printStackTrace();
			try {
				AppData data = new AppData();
				data.setMsg("会话过期，请注销重新登录。");
				data.setStatus(AppData.RETURN_FAIL);
				response.getWriter().write(JSON.toJSONString(data));
			} catch (IOException e) {
				e.printStackTrace();
			}
			return false;
		}

		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.HandlerInterceptor#postHandle(javax
	 * .servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse, java.lang.Object,
	 * org.springframework.web.servlet.ModelAndView)
	 */
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
					ModelAndView modelAndView) throws Exception {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.HandlerInterceptor#afterCompletion
	 * (javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse, java.lang.Object,
	 * java.lang.Exception)
	 */
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
					Exception ex) throws Exception {

	}

}
