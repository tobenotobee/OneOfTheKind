/**    
 * @Title: MemberTokenServiceImpl.java  
 * @Package: cn.bluemobi.site.service.impl  
 * @Description: 用户token mapper类
 * @Author: huh
 * @Date: 2015年10月27日 上午10:30:57  
 * @Version V1.0    
 */

package cn.bluemobi.site.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.bluemobi.site.dao.mybatis.MemberTokenMapper;
import cn.bluemobi.site.model.MemberToken;
import cn.bluemobi.site.service.MemberTokenService;

/**
 * @ClassName: MemberTokenServiceImpl
 * @Description: 用户token mapper
 * @author huh
 * @date 2015年10月27日 上午10:30:57
 * 
 */
@Service("memberTokenService")
public class MemberTokenServiceImpl implements MemberTokenService {

	@Autowired
	private MemberTokenMapper memberTokenMapper;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.site.service.MemberTokenService#getMemberToken(cn.bluemobi
	 * . site.model.MemberToken)
	 */
	@Override
	public Integer getMemberToken(MemberToken memberToken) {
		return memberTokenMapper.getMemberToken(memberToken);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.site.service.MemberTokenService#insertMemberToken(cn.
	 * bluemobi .site.model.MemberToken)
	 */
	@Override
	public void insertMemberToken(MemberToken memberToken) {
		memberTokenMapper.insertMemberToken(memberToken);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cn.bluemobi.site.service.MemberTokenService#updateMemberToken(cn.
	 * bluemobi .site.model.MemberToken)
	 */
	@Override
	public void updateMemberToken(MemberToken memberToken) {
		memberTokenMapper.updateMemberToken(memberToken);
	}

}
