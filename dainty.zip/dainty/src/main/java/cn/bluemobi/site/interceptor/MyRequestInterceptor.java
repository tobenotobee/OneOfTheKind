/**    
 * @Title: MyRequestInterceptor.java  
 * @Package: cn.bluemobi.site.interceptor  
 * @Description: APP请求后台拦截器类
 * @Author: huh
 * @Date: 2015年10月27日 上午11:09:09  
 * @Version V1.0    
 */

package cn.bluemobi.site.interceptor;

import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

/**
 * @ClassName: MyRequestInterceptor
 * @Description: APP请求后台拦截器
 * @author huh
 * @date 2015年10月27日 上午11:09:09
 * 
 */
public class MyRequestInterceptor implements HandlerInterceptor {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.HandlerInterceptor#preHandle(javax
	 * .servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		System.out.print("请求方式：" + request.getMethod() + " | ");
		System.out.print("Remote Host：" + request.getRemoteHost() + " | ");
		System.out.print("请求URL："+request.getRequestURL()+" | ");
		System.out.print("Protocol：" + request.getProtocol() + " | ");
		if ("POST".equals(request.getMethod())) {
			Map<String, String[]> pmap = request.getParameterMap();
			Iterator<String> it = pmap.keySet().iterator();
			System.out.print("Parameters 【 ");
			while (it.hasNext()) {
				String key = it.next();
				String[] value = (String[]) pmap.get(key);
				System.out.print("key=" + key);
				for (int i = 0; i < value.length; i++) {
					System.out.print(" value" + (i + 1) + "=" + value[i]);
				}
			}
			System.out.print(" 】| ");
		} else {
			System.out.print(request.getQueryString() + " | ");
		}
		System.out.println("Type:" + request.getHeader("User-Agent") + " | ");

		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.HandlerInterceptor#postHandle(javax
	 * .servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse, java.lang.Object,
	 * org.springframework.web.servlet.ModelAndView)
	 */
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
					ModelAndView modelAndView) throws Exception {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.HandlerInterceptor#afterCompletion
	 * (javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse, java.lang.Object,
	 * java.lang.Exception)
	 */
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
					Exception ex) throws Exception {
	}

}
