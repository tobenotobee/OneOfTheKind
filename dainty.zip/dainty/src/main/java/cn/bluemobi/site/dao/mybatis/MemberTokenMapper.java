/**    
、 * @Title: MemberTokenMapper.java  
 * @Package: cn.bluemobi.site.dao.mybatis
 * @Description: 用户token mapper类
 * @Author: huh
 * @Date: 2015年10月27日 上午10:41:38  
 * @Version V1.0    
 */

package cn.bluemobi.site.dao.mybatis;

import cn.bluemobi.site.model.MemberToken;

/**
 * @ClassName: MemberTokenMapper
 * @Description: 用户token mapper
 * @author huh
 * @date 2015年10月27日 上午10:41:38
 * 
 */
public interface MemberTokenMapper {

	/**
	 * 
	 * @Description: 验证这个登录用户是否有效
	 * @param memberToken
	 * @return
	 * @throws
	 */
	public Integer getMemberToken(MemberToken memberToken);

	/**
	 * 
	 * @Description: 检查是否存在用户的token记录
	 * @return
	 * @throws
	 */
	public Integer getMemberTokenByUserID(String userId);

	/**
	 * 
	 * @Description: 在数据库中新插入一条指定的求比特令牌器token记录
	 * @param memberToken
	 * @return
	 * @throws
	 */
	public void insertMemberToken(MemberToken memberToken);

	/**
	 * 
	 * @Description: 在数据库中修改此条求比特令牌器token记录
	 * @param memberToken
	 * @return
	 * @throws
	 */
	public void updateMemberToken(MemberToken memberToken);

}
